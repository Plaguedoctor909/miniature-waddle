// Update the StockfishEngine class to handle message callbacks more robustly

export class StockfishEngine {
  private worker: Worker
  private options: Record<string, string> = {}
  private messageCallback: ((event: MessageEvent) => void) | null = null

  constructor() {
    const stockfishCode = `
      self.onmessage = function(event) {
        const message = event.data;
        
        if (message.startsWith("position fen")) {
          // Store the current position
          self.currentFen = message.substring("position fen ".length);
        } else if (message.startsWith("go")) {
          // Parse depth and movetime from command
          let depth = 10;
          let moveTime = 1000;
          
          if (message.includes("depth")) {
            const depthMatch = message.match(/depth (\\\\d+)/);
            if (depthMatch) {
              depth = parseInt(depthMatch[1]);
            }
          }
          
          if (message.includes("movetime")) {
            const moveTimeMatch = message.match(/movetime (\\\\d+)/);
            if (moveTimeMatch) {
              moveTime = parseInt(moveTimeMatch[1]);
            }
          }
          
          // Generate chess moves based on the position
          // This is a simplified implementation that generates random but somewhat realistic moves
          setTimeout(() => {
            // Generate a random evaluation between -200 and 200 centipawns
            const randomEval = Math.floor(Math.random() * 400) - 200;
            
            // Common chess moves for demonstration
            const commonMoves = [
              "e2e4", "d2d4", "c2c4", "g1f3", "b1c3", // Common white moves
              "e7e5", "d7d5", "c7c5", "g8f6", "b8c6"  // Common black responses
            ];
            
            const randomMove = commonMoves[Math.floor(Math.random() * commonMoves.length)];
            
            // Send analysis info with evaluation
            self.postMessage(\`info depth \${depth} seldepth \${depth+2} multipv 1 score cp \${randomEval} nodes 15400 nps 38500 tbhits 0 time \${moveTime} pv \${randomMove} e7e5 g1f3 b8c6\`);
            
            // Send best move
            self.postMessage(\`bestmove \${randomMove}\`);
          }, moveTime);
        } else if (message === "uci") {
          // UCI initialization
          self.postMessage("id name Stockfish 16");
          self.postMessage("id author The Stockfish Team");
          self.postMessage("option name Skill Level type spin default 10 min 0 max 20");
          self.postMessage("option name Threads type spin default 1 min 1 max 512");
          self.postMessage("option name Hash type spin default 16 min 1 max 33554432");
          self.postMessage("option name UCI_AnalyseMode type check default false");
          self.postMessage("uciok");
        } else if (message === "isready") {
          self.postMessage("readyok");
        } else if (message.startsWith("setoption")) {
          // Store engine options
          const nameMatch = message.match(/name\\s+([^\\s]+)/);
          const valueMatch = message.match(/value\\s+([^\\s]+)/);
          
          if (nameMatch && valueMatch) {
            const optionName = nameMatch[1];
            const optionValue = valueMatch[1];
            
            if (!self.options) {
              self.options = {};
            }
            
            self.options[optionName] = optionValue;
          }
        }
      };
    `

    const blob = new Blob([stockfishCode], { type: "application/javascript" })
    this.worker = new Worker(URL.createObjectURL(blob))

    // Set up message forwarding
    this.worker.onmessage = (event) => {
      if (this.messageCallback) {
        this.messageCallback(event)
      }
    }
  }

  postMessage(message: string): void {
    this.worker.postMessage(message)
  }

  set onmessage(callback: ((event: MessageEvent) => void) | null) {
    this.messageCallback = callback
  }

  terminate(): void {
    this.worker.terminate()
  }
}

export default function createStockfishEngine(): StockfishEngine {
  return new StockfishEngine()
}

// This is a mock implementation of the Stockfish worker
// In a real application, you would use the actual Stockfish WebAssembly or JavaScript implementation

export default class StockfishWorker {
  onmessage: ((event: { data: string }) => void) | null = null

  postMessage(message: string) {
    // Mock implementation that simulates Stockfish responses
    if (message.startsWith("position fen")) {
      // Position set, do nothing
    } else if (message.startsWith("go")) {
      // Simulate thinking and return a move
      setTimeout(() => {
        if (this.onmessage) {
          // Generate a random valid chess move
          const files = ["a", "b", "c", "d", "e", "f", "g", "h"]
          const ranks = ["1", "2", "3", "4", "5", "6", "7", "8"]

          const from = files[Math.floor(Math.random() * 8)] + ranks[Math.floor(Math.random() * 8)]
          const to = files[Math.floor(Math.random() * 8)] + ranks[Math.floor(Math.random() * 8)]

          // Send best move
          this.onmessage({ data: `bestmove ${from}${to}` })

          // Send hint info
          this.onmessage({
            data: `info depth 10 seldepth 12 multipv 1 score cp 24 nodes 15400 nps 38500 tbhits 0 time 400 pv ${from}${to} e7e5 g1f3 b8c6`,
          })
        }
      }, 500)
    } else if (message === "uci" || message === "isready") {
      // Initialization commands
      if (this.onmessage) {
        this.onmessage({ data: "readyok" })
      }
    }
  }

  terminate() {
    // Clean up resources
    this.onmessage = null
  }
}

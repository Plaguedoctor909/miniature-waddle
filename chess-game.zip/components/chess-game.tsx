"use client"

import { useState, useEffect, useRef } from "react"
import { Chess } from "chess.js"
import { Chessboard } from "react-chessboard"
import { Settings, Lightbulb, RotateCcw, CheckCircle2, Clock } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { toast } from "@/hooks/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ChessGame() {
  const [game, setGame] = useState(new Chess())
  const [playerColor, setPlayerColor] = useState("white")
  const [hintsEnabled, setHintsEnabled] = useState(false)
  const [premoveEnabled, setPremoveEnabled] = useState(true)
  const [premove, setPremove] = useState(null)
  const [isThinking, setIsThinking] = useState(false)
  const [moveHistory, setMoveHistory] = useState([])
  const [gameStatus, setGameStatus] = useState("")
  const [suggestedMove, setSuggestedMove] = useState("")
  const [evaluation, setEvaluation] = useState(0) // centipawns
  const [lastMoveScore, setLastMoveScore] = useState({ type: "", move: "" })
  const [openingName, setOpeningName] = useState("")

  // Timer states
  const [timeControl, setTimeControl] = useState(300) // 5 minutes in seconds
  const [whiteTime, setWhiteTime] = useState(timeControl)
  const [blackTime, setBlackTime] = useState(timeControl)
  const [timerActive, setTimerActive] = useState(false)

  const engineRef = useRef(null)
  const gameRef = useRef(game)
  const timerRef = useRef(null)
  const lastEvalRef = useRef(0)
  const isMountedRef = useRef(true) // Ref to track component mount status
  const currentEvalRef = useRef(0)

  // Mark component as mounted
  useEffect(() => {
    isMountedRef.current = true
    return () => {
      isMountedRef.current = false
    }
  }, [])

  // Initialize Chess AI
  useEffect(() => {
    // Create the engine using our custom implementation
    const engine = createChessAI()

    // Store the engine reference
    engineRef.current = engine

    // Clean up function
    return () => {
      isMountedRef.current = false // Mark component as unmounted
      if (engineRef.current) {
        engineRef.current = null
      }
    }
  }, [playerColor]) // Add playerColor to dependency array for proper color-dependent evaluation

  // Update game reference when game state changes
  useEffect(() => {
    gameRef.current = game

    // Identify opening
    if (moveHistory.length <= 10) {
      identifyOpening(game.history({ verbose: true }))
    }

    // Start timer on first move
    if (moveHistory.length === 1 && !timerActive) {
      setTimerActive(true)
    }

    // Evaluate position after each move
    if (moveHistory.length > 0 && engineRef.current) {
      const evaluation = engineRef.current.evaluatePosition(game.fen())
      // Adjust evaluation based on player color
      const adjustedEval = playerColor === "white" ? evaluation : -evaluation
      lastEvalRef.current = currentEvalRef.current
      currentEvalRef.current = adjustedEval
      setEvaluation(adjustedEval)
    }
  }, [game, moveHistory.length, playerColor])

  // Make computer move if it's computer's turn
  useEffect(() => {
    if (
      !game.isGameOver() &&
      ((game.turn() === "w" && playerColor === "black") || (game.turn() === "b" && playerColor === "white"))
    ) {
      makeComputerMove()
    }
  }, [game, playerColor])

  // Apply premove if it exists and it's player's turn
  useEffect(() => {
    if (
      premove &&
      !game.isGameOver() &&
      ((game.turn() === "w" && playerColor === "white") || (game.turn() === "b" && playerColor === "black"))
    ) {
      const { from, to } = premove
      makeMove(from, to)
      setPremove(null)
    }
  }, [game, premove, playerColor])

  // Update game status
  useEffect(() => {
    if (game.isCheckmate()) {
      setGameStatus("Checkmate")
      const winner = game.turn() === "w" ? "Black" : "White"
      toast({
        title: "Game Over",
        description: `${winner} wins by checkmate!`,
      })
      setTimerActive(false)
    } else if (game.isDraw()) {
      setGameStatus("Draw")
      toast({
        title: "Game Over",
        description: "Game ended in a draw!",
      })
      setTimerActive(false)
    } else if (game.isStalemate()) {
      setGameStatus("Stalemate")
      toast({
        title: "Game Over",
        description: "Game ended in stalemate!",
      })
      setTimerActive(false)
    } else if (game.isCheck()) {
      setGameStatus("Check")
    } else {
      setGameStatus("")
    }
  }, [game, playerColor])

  // Update move history
  useEffect(() => {
    setMoveHistory(game.history({ verbose: true }))
  }, [game])

  // Timer effect
  useEffect(() => {
    if (timerActive && !game.isGameOver()) {
      timerRef.current = setInterval(() => {
        if (game.turn() === "w") {
          setWhiteTime((prev) => {
            if (prev <= 0) {
              clearInterval(timerRef.current)
              setTimerActive(false)
              toast({
                title: "Time's up!",
                description: "White lost on time.",
              })
              return 0
            }
            return prev - 1
          })
        } else {
          setBlackTime((prev) => {
            if (prev <= 0) {
              clearInterval(timerRef.current)
              setTimerActive(false)
              toast({
                title: "Time's up!",
                description: "Black lost on time.",
              })
              return 0
            }
            return prev - 1
          })
        }
      }, 1000)
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [timerActive, game])

  // Reset timer when time control changes
  useEffect(() => {
    setWhiteTime(timeControl)
    setBlackTime(timeControl)
  }, [timeControl])

  function makeComputerMove() {
    setIsThinking(true)

    // Use setTimeout to give UI time to update and show the thinking indicator
    setTimeout(() => {
      if (!isMountedRef.current) return

      try {
        const gameCopy = new Chess(game.fen())

        // Get the best move from our AI
        const bestMove = engineRef.current.findBestMove(gameCopy, 3) // depth 3 for quick response

        if (bestMove) {
          // Apply the move
          gameCopy.move(bestMove)

          // Computer moves are always "best moves"
          setLastMoveScore({
            type: "Best Move",
            move: `${bestMove.from}-${bestMove.to}`,
          })

          // Update the game state
          setGame(gameCopy)

          // Evaluate the new position
          const newEval = engineRef.current.evaluatePosition(gameCopy.fen())
          const adjustedEval = playerColor === "white" ? newEval : -newEval
          lastEvalRef.current = currentEvalRef.current
          currentEvalRef.current = adjustedEval
          setEvaluation(adjustedEval)
        }
      } catch (error) {
        console.error("Error making computer move:", error)
        // Fallback to random move if there's an error
        const gameCopy = new Chess(game.fen())
        const randomMove = getRandomMove(gameCopy)
        if (randomMove) {
          gameCopy.move(randomMove)
          setGame(gameCopy)
        }
      }

      setIsThinking(false)
    }, 1000) // 1 second thinking time for UI feedback
  }

  // Helper function to get a random legal move
  function getRandomMove(gameCopy) {
    const possibleMoves = gameCopy.moves()
    if (possibleMoves.length > 0) {
      const randomIndex = Math.floor(Math.random() * possibleMoves.length)
      return possibleMoves[randomIndex]
    }
    return null
  }

  function makeMove(sourceSquare, targetSquare, piece) {
    try {
      const gameCopy = new Chess(game.fen())
      const prevEval = lastEvalRef.current

      // Get promotion piece if pawn is moving to the last rank
      let promotionPiece = undefined
      if (piece && piece.includes("P") && (targetSquare.charAt(1) === "8" || targetSquare.charAt(1) === "1")) {
        promotionPiece = "q" // Default to queen promotion
      }

      const move = gameCopy.move({
        from: sourceSquare,
        to: targetSquare,
        promotion: promotionPiece,
      })

      if (move) {
        // Evaluate the move quality
        evaluateMoveQuality(sourceSquare, targetSquare, prevEval, gameCopy.history().length)

        setGame(gameCopy)
        setSuggestedMove("")
        return true
      }
    } catch (error) {
      return false
    }
    return false
  }

  const evaluateMoveQuality = (from, to, prevEval, moveNumber) => {
    // For opening moves (first 10), check if it's a book move
    if (moveNumber <= 10) {
      // Common opening moves (simplified)
      const bookMoves = [
        "e2-e4",
        "d2-d4",
        "c2-c4",
        "g1-f3", // Common white first moves
        "e7-e5",
        "d7-d5",
        "c7-c5",
        "g8-f6", // Common black responses
        "b1-c3",
        "f1-e2",
        "e1-g1", // Other common white moves
        "b8-c6",
        "f8-e7",
        "e8-g8", // Other common black moves
      ]

      const moveString = `${from}-${to}`
      if (bookMoves.includes(moveString)) {
        setLastMoveScore({ type: "Book Move", move: moveString })
        return
      }
    }

    // Store the timeout ID in a ref to ensure it can be cleared
    const timeoutId = setTimeout(() => {
      if (!isMountedRef.current) return // Skip if component unmounted

      // Use the refs to get the current evaluation
      const currentEval = currentEvalRef.current
      const evalDiff = currentEval - prevEval
      const moveString = `${from}-${to}`

      // Determine move quality based on evaluation difference
      let moveType = "Good Move"

      if (Math.abs(evalDiff) < 10) {
        moveType = "Best Move"
      } else if (evalDiff > 100) {
        moveType = "Brilliant"
      } else if (evalDiff > 50) {
        moveType = "Good Move"
      } else if (evalDiff < -100) {
        moveType = "Blunder"
      } else if (evalDiff < -50) {
        moveType = "Mistake"
      } else if (evalDiff < -20) {
        moveType = "Inaccuracy"
      }

      // Update state only once
      if (isMountedRef.current) {
        setLastMoveScore({ type: moveType, move: moveString })
      }
    }, 200)

    // Return a cleanup function
    return () => {
      clearTimeout(timeoutId)
    }
  }

  function showHint() {
    if (!hintsEnabled) return

    try {
      const bestMove = engineRef.current.findBestMove(new Chess(game.fen()), 2)
      if (bestMove) {
        setSuggestedMove(`${bestMove.from}${bestMove.to}`)
      }
    } catch (error) {
      console.error("Error generating hint:", error)
    }
  }

  function identifyOpening(moves) {
    // This is a simplified opening recognition system
    // In a real implementation, you would have a database of openings

    if (moves.length === 0) {
      setOpeningName("")
      return
    }

    const moveNotation = moves.map((m) => m.san).join(" ")

    // Check for some common openings
    if (moveNotation.startsWith("e4 e5 Nf3")) {
      setOpeningName("Ruy Lopez / Italian Game")
    } else if (moveNotation.startsWith("e4 e5 f4")) {
      setOpeningName("King's Gambit")
    } else if (moveNotation.startsWith("e4 c5")) {
      setOpeningName("Sicilian Defense")
    } else if (moveNotation.startsWith("e4 e6")) {
      setOpeningName("French Defense")
    } else if (moveNotation.startsWith("d4 d5 c4")) {
      setOpeningName("Queen's Gambit")
    } else if (moveNotation.startsWith("d4 Nf6")) {
      setOpeningName("Indian Defense")
    } else if (moveNotation.startsWith("e4 d5")) {
      setOpeningName("Scandinavian Defense")
    } else if (moveNotation.startsWith("c4")) {
      setOpeningName("English Opening")
    } else if (moveNotation.startsWith("e4")) {
      setOpeningName("King's Pawn Opening")
    } else if (moveNotation.startsWith("d4")) {
      setOpeningName("Queen's Pawn Opening")
    } else {
      setOpeningName("")
    }
  }

  function onDrop(sourceSquare, targetSquare, piece) {
    // Check if it's player's turn
    if ((game.turn() === "w" && playerColor === "black") || (game.turn() === "b" && playerColor === "white")) {
      if (premoveEnabled) {
        setPremove({ from: sourceSquare, to: targetSquare })
        return false
      }
      return false
    }

    return makeMove(sourceSquare, targetSquare, piece)
  }

  function resetGame() {
    setGame(new Chess())
    setPremove(null)
    setSuggestedMove("")
    setGameStatus("")
    setEvaluation(0)
    setLastMoveScore({ type: "", move: "" })
    setOpeningName("")
    setWhiteTime(timeControl)
    setBlackTime(timeControl)
    setTimerActive(false)
  }

  function switchSides() {
    setPlayerColor(playerColor === "white" ? "black" : "white")
    resetGame()
  }

  function formatTime(seconds) {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  // Calculate evaluation bar percentage (0-100)
  const evalBarPercentage = () => {
    // Convert centipawn evaluation to a percentage
    // Using a sigmoid function to map evaluation to 0-100 range
    const sigmoid = (x) => 100 / (1 + Math.exp(-0.004 * x))
    return sigmoid(evaluation)
  }

  // Get color for move quality badge
  const getMoveQualityColor = (type) => {
    switch (type) {
      case "Brilliant":
        return "bg-purple-500 hover:bg-purple-600"
      case "Best Move":
        return "bg-green-500 hover:bg-green-600"
      case "Good Move":
        return "bg-blue-500 hover:bg-blue-600"
      case "Book Move":
        return "bg-cyan-500 hover:bg-cyan-600"
      case "Inaccuracy":
        return "bg-yellow-500 hover:bg-yellow-600"
      case "Mistake":
        return "bg-orange-500 hover:bg-orange-600"
      case "Blunder":
        return "bg-red-500 hover:bg-red-600"
      default:
        return "bg-gray-500 hover:bg-gray-600"
    }
  }

  return (
    <div className="flex flex-col items-center w-full max-w-4xl">
      <div className="flex flex-col md:flex-row w-full gap-4 mb-4 items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={resetGame} className="flex items-center gap-1">
            <RotateCcw className="h-4 w-4" />
            New Game
          </Button>

          <Button variant="outline" onClick={switchSides} className="flex items-center gap-1">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M2 9a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V9Z" />
              <path d="M13 17v4" />
              <path d="M13 3v4" />
              <path d="M17 17v2" />
              <path d="M17 5v2" />
            </svg>
            Switch Sides
          </Button>
        </div>

        <div className="flex items-center gap-2">
          {hintsEnabled && (
            <Button
              variant="outline"
              onClick={showHint}
              className="flex items-center gap-1"
              disabled={isThinking || game.isGameOver()}
            >
              <Lightbulb className="h-4 w-4" />
              Hint
            </Button>
          )}

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="flex items-center gap-1">
                <Settings className="h-4 w-4" />
                Settings
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Game Settings</SheetTitle>
                <SheetDescription>Configure your chess game preferences</SheetDescription>
              </SheetHeader>

              <div className="py-4 space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="player-color">Play as</Label>
                  <Select value={playerColor} onValueChange={setPlayerColor}>
                    <SelectTrigger id="player-color">
                      <SelectValue placeholder="Select color" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="white">White</SelectItem>
                      <SelectItem value="black">Black</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="time-control">Time Control (minutes)</Label>
                    <Badge variant="outline">{timeControl / 60}</Badge>
                  </div>
                  <Slider
                    id="time-control"
                    min={1}
                    max={30}
                    step={1}
                    value={[timeControl / 60]}
                    onValueChange={(value) => setTimeControl(value[0] * 60)}
                    disabled={timerActive}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="hints">Enable hints</Label>
                  <Switch id="hints" checked={hintsEnabled} onCheckedChange={setHintsEnabled} />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="premove">Enable premoves</Label>
                  <Switch id="premove" checked={premoveEnabled} onCheckedChange={setPremoveEnabled} />
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <div className="w-full max-w-md md:max-w-lg lg:max-w-xl">
        {/* Timer display */}
        <div className="flex justify-between mb-2">
          <div className={`flex items-center gap-2 ${game.turn() === "b" ? "opacity-70" : "font-bold"}`}>
            <Clock className="h-4 w-4" />
            <span className="text-sm">Black: {formatTime(blackTime)}</span>
          </div>

          {!timerActive && moveHistory.length === 0 && (
            <Button size="sm" onClick={() => setTimerActive(true)} disabled={game.isGameOver()}>
              Start Clock
            </Button>
          )}

          <div className={`flex items-center gap-2 ${game.turn() === "w" ? "opacity-70" : "font-bold"}`}>
            <span className="text-sm">White: {formatTime(whiteTime)}</span>
            <Clock className="h-4 w-4" />
          </div>
        </div>

        {/* Evaluation bar */}
        <div className="h-2 w-full bg-gray-200 rounded-full mb-2 relative">
          <div
            className="absolute top-0 left-0 h-full bg-black rounded-full transition-all duration-300"
            style={{ width: `${evalBarPercentage()}%` }}
          ></div>
          <div className="absolute top-0 left-1/2 h-full w-0.5 bg-gray-400"></div>
        </div>

        {/* Evaluation text */}
        <div className="flex justify-between mb-2 text-xs text-gray-600">
          <span>Black</span>
          <span>
            {evaluation === 0
              ? "Even"
              : Math.abs(evaluation) >= 10000
                ? `Mate in ${Math.ceil(Math.abs(evaluation - 10000) / 100)}`
                : (evaluation / 100).toFixed(1)}
          </span>
          <span>White</span>
        </div>

        <Card className="p-2 md:p-4 relative">
          {isThinking && (
            <div className="absolute inset-0 bg-background/80 flex items-center justify-center z-10">
              <div className="flex flex-col items-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                <p className="mt-2 text-sm">Computer is thinking...</p>
              </div>
            </div>
          )}

          <Chessboard
            id="chess-board"
            position={game.fen()}
            onPieceDrop={onDrop}
            boardOrientation={playerColor}
            customBoardStyle={{
              borderRadius: "4px",
              boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
            }}
            customDarkSquareStyle={{ backgroundColor: "#779556" }}
            customLightSquareStyle={{ backgroundColor: "#ebecd0" }}
            customPieces={
              {
                // Custom pieces could be added here
              }
            }
            areArrowsAllowed={hintsEnabled}
            customArrows={
              suggestedMove ? [[suggestedMove.substring(0, 2), suggestedMove.substring(2, 4), "green"]] : []
            }
          />
        </Card>
      </div>

      <div className="mt-4 w-full max-w-md md:max-w-lg lg:max-w-xl">
        <div className="flex justify-between items-center mb-2">
          <div className="flex items-center gap-2">
            <div
              className={`w-3 h-3 rounded-full ${game.turn() === "w" ? "bg-white border border-black" : "bg-black"}`}
            ></div>
            <span className="text-sm font-medium">{game.turn() === "w" ? "White" : "Black"} to move</span>
          </div>

          {gameStatus && <Badge variant={gameStatus === "Check" ? "outline" : "default"}>{gameStatus}</Badge>}

          {premove && (
            <Badge variant="outline" className="flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" />
              Premove
            </Badge>
          )}

          {/* Opening name display */}
          {openingName && <Badge variant="secondary">{openingName}</Badge>}
        </div>

        {/* Last move quality badge */}
        {lastMoveScore.type && (
          <div className="mb-2 flex justify-center">
            <Badge className={`${getMoveQualityColor(lastMoveScore.type)} text-white`}>{lastMoveScore.type}</Badge>
          </div>
        )}

        <Tabs defaultValue="moves" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="moves">Moves</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="moves">
            <Card className="p-3 h-24 overflow-y-auto">
              <div className="grid grid-cols-2 gap-2">
                {moveHistory.length > 0 ? (
                  Array.from({ length: Math.ceil(moveHistory.length / 2) }).map((_, i) => (
                    <div key={i} className="flex">
                      <div className="w-8 text-muted-foreground text-sm">{i + 1}.</div>
                      <div className="flex-1 grid grid-cols-2">
                        <div className="text-sm">{moveHistory[i * 2]?.san || ""}</div>
                        <div className="text-sm">{moveHistory[i * 2 + 1]?.san || ""}</div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="col-span-2 text-center text-muted-foreground text-sm">No moves yet</div>
                )}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="analysis">
            <Card className="p-3 h-24 overflow-y-auto">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">Position Evaluation:</span>
                  <span>
                    {evaluation === 0
                      ? "Even"
                      : Math.abs(evaluation) >= 10000
                        ? `Mate in ${Math.ceil(Math.abs(evaluation - 10000) / 100)}`
                        : `${(evaluation / 100).toFixed(2)} pawns ${evaluation > 0 ? "for White" : "for Black"}`}
                  </span>
                </div>

                {lastMoveScore.type && (
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Last Move Quality:</span>
                    <span>{lastMoveScore.type}</span>
                  </div>
                )}

                {openingName && (
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Opening:</span>
                    <span>{openingName}</span>
                  </div>
                )}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Create a custom chess AI using minimax with alpha-beta pruning
function createChessAI() {
  // Piece values for evaluation
  const PIECE_VALUES = {
    p: -100, // pawn
    n: -300, // knight
    b: -300, // bishop
    r: -500, // rook
    q: -900, // queen
    k: -10000, // king
    P: 100, // pawn
    N: 300, // knight
    B: 300, // bishop
    R: 500, // rook
    Q: 900, // queen
    K: 10000, // king
  }

  // Position bonus for pawns (encourages center control and advancement)
  const PAWN_POSITION = [
    0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10, 5, 5, 10, 25, 25, 10, 5, 5,
    0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5, 5, 10, 10, -20, -20, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0,
  ]

  // Position bonus for knights (encourages center control)
  const KNIGHT_POSITION = [
    -50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0, -30, -30, 5, 15,
    20, 20, 15, 5, -30, -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30, -40, -20, 0, 5, 5, 0, -20, -40,
    -50, -40, -30, -30, -30, -30, -40, -50,
  ]

  // Position bonus for bishops
  const BISHOP_POSITION = [
    -20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 10, 10, 10, 10, 0, -10, -10, 5, 5, 10,
    10, 5, 5, -10, -10, 0, 5, 10, 10, 5, 0, -10, -10, 5, 5, 5, 5, 5, 5, -10, -10, 0, 5, 0, 0, 5, 0, -10, -20, -10, -10,
    -10, -10, -10, -10, -20,
  ]

  // Position bonus for rooks
  const ROOK_POSITION = [
    0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0,
    0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5, 0, 0, 0,
  ]

  // Position bonus for queens
  const QUEEN_POSITION = [
    -20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10, -5, 0, 5, 5, 5, 5, 0,
    -5, 0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10, -10, 0, 5, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10,
    -10, -20,
  ]

  // Position bonus for kings (early game - encourages castling and safety)
  const KING_POSITION = [
    -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40,
    -30, -30, -40, -40, -50, -50, -40, -40, -30, -20, -30, -30, -40, -40, -30, -30, -20, -10, -20, -20, -20, -20, -20,
    -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20,
  ]

  // Evaluate a position based on material and piece positions
  function evaluatePosition(fen) {
    const chess = new Chess(fen)

    // Check for checkmate
    if (chess.isCheckmate()) {
      return chess.turn() === "w" ? -10000 : 10000
    }

    // Check for draw
    if (chess.isDraw() || chess.isStalemate() || chess.isThreefoldRepetition() || chess.isInsufficientMaterial()) {
      return 0
    }

    const board = chess.board()
    let score = 0

    // Evaluate material and piece positions
    for (let i = 0; i < 8; i++) {
      for (let j = 0; j < 8; j++) {
        const piece = board[i][j]
        if (piece) {
          // Material value
          score += PIECE_VALUES[piece.type.toUpperCase() === piece.type ? piece.type : piece.type.toLowerCase()]

          // Position value
          const position = i * 8 + j
          const flippedPosition = (7 - i) * 8 + j // For black pieces

          if (piece.type === "p") {
            score -= PAWN_POSITION[flippedPosition]
          } else if (piece.type === "P") {
            score += PAWN_POSITION[position]
          } else if (piece.type === "n") {
            score -= KNIGHT_POSITION[flippedPosition]
          } else if (piece.type === "N") {
            score += KNIGHT_POSITION[position]
          } else if (piece.type === "b") {
            score -= BISHOP_POSITION[flippedPosition]
          } else if (piece.type === "B") {
            score += BISHOP_POSITION[position]
          } else if (piece.type === "r") {
            score -= ROOK_POSITION[flippedPosition]
          } else if (piece.type === "R") {
            score += ROOK_POSITION[position]
          } else if (piece.type === "q") {
            score -= QUEEN_POSITION[flippedPosition]
          } else if (piece.type === "Q") {
            score += QUEEN_POSITION[position]
          } else if (piece.type === "k") {
            score -= KING_POSITION[flippedPosition]
          } else if (piece.type === "K") {
            score += KING_POSITION[position]
          }
        }
      }
    }

    // Bonus for mobility (number of legal moves)
    const mobilityBonus = 0.1
    score += mobilityBonus * chess.moves().length * (chess.turn() === "w" ? 1 : -1)

    return score
  }

  // Minimax algorithm with alpha-beta pruning
  function minimax(chess, depth, alpha, beta, isMaximizingPlayer) {
    if (depth === 0 || chess.isGameOver()) {
      return evaluatePosition(chess.fen())
    }

    const moves = chess.moves({ verbose: true })

    if (isMaximizingPlayer) {
      let maxEval = Number.NEGATIVE_INFINITY
      for (const move of moves) {
        chess.move(move)
        const evaluation = minimax(chess, depth - 1, alpha, beta, false)
        chess.undo()
        maxEval = Math.max(maxEval, evaluation)
        alpha = Math.max(alpha, evaluation)
        if (beta <= alpha) {
          break // Beta cutoff
        }
      }
      return maxEval
    } else {
      let minEval = Number.POSITIVE_INFINITY
      for (const move of moves) {
        chess.move(move)
        const evaluation = minimax(chess, depth - 1, alpha, beta, true)
        chess.undo()
        minEval = Math.min(minEval, evaluation)
        beta = Math.min(beta, evaluation)
        if (beta <= alpha) {
          break // Alpha cutoff
        }
      }
      return minEval
    }
  }

  // Find the best move using minimax
  function findBestMove(chess, depth) {
    const moves = chess.moves({ verbose: true })
    let bestMove = null
    let bestEval = chess.turn() === "w" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY

    // Sort moves to improve alpha-beta pruning efficiency
    // Check captures and promotions first
    moves.sort((a, b) => {
      const aValue = a.captured ? PIECE_VALUES[a.captured.toUpperCase()] : 0
      const bValue = b.captured ? PIECE_VALUES[b.captured.toUpperCase()] : 0
      return bValue - aValue
    })

    for (const move of moves) {
      chess.move(move)
      const evaluation = minimax(
        chess,
        depth - 1,
        Number.NEGATIVE_INFINITY,
        Number.POSITIVE_INFINITY,
        chess.turn() === "w",
      )
      chess.undo()

      if (chess.turn() === "w") {
        if (evaluation > bestEval) {
          bestEval = evaluation
          bestMove = move
        }
      } else {
        if (evaluation < bestEval) {
          bestEval = evaluation
          bestMove = move
        }
      }
    }

    return bestMove
  }

  return {
    evaluatePosition,
    findBestMove,
  }
}

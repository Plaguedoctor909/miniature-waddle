import Image from "next/image"
import Link from "next/link"
import { Instagram, Facebook, Twitter, Mail, Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import FeaturedProducts from "@/components/featured-products"
import TestimonialSection from "@/components/testimonial-section"
import NewsletterSignup from "@/components/newsletter-signup"
import HeroLogo from "@/components/hero-logo"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Image src="/logo.svg" alt="JaesCrochet Logo" width={40} height={40} className="h-10 w-10" />
            <span className="text-xl font-bold tracking-tight text-primary">JaesCrochet</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium transition-colors hover:text-primary">
              Home
            </Link>
            <Link href="#about" className="text-sm font-medium transition-colors hover:text-primary">
              About
            </Link>
            <Link href="#products" className="text-sm font-medium transition-colors hover:text-primary">
              Products
            </Link>
            <Link href="#gallery" className="text-sm font-medium transition-colors hover:text-primary">
              Gallery
            </Link>
            <Link href="#contact" className="text-sm font-medium transition-colors hover:text-primary">
              Contact
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex social-icons gap-2">
              <Link href="https://instagram.com" aria-label="Instagram" className="p-2 rounded-full hover:bg-muted">
                <Instagram className="h-5 w-5" />
              </Link>
              <Link href="https://facebook.com" aria-label="Facebook" className="p-2 rounded-full hover:bg-muted">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="https://twitter.com" aria-label="Twitter" className="p-2 rounded-full hover:bg-muted">
                <Twitter className="h-5 w-5" />
              </Link>
            </div>
            <Button variant="outline" size="sm" className="hidden md:flex">
              Contact Us
            </Button>
            <Button variant="ghost" size="sm" className="md:hidden">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6"
              >
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="relative">
          <div className="absolute inset-0 bg-[url('/hero-pattern.svg')] opacity-10"></div>
          <div className="container relative px-4 py-24 md:py-32 lg:py-40">
            <HeroLogo />
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
                  Handcrafted Crochet <span className="text-primary">Creations</span>
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Unique, handmade crochet items crafted with love and care. From cozy home decor to stylish
                  accessories.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" className="yarn-button">
                    Shop Collection
                  </Button>
                  <Button size="lg" variant="outline">
                    Learn More
                  </Button>
                </div>
              </div>
              <div className="mx-auto max-w-[500px] relative">
                <div className="stitch-border p-2 rounded-lg">
                  <Image
                    src="/placeholder.svg?height=600&width=600"
                    alt="Handcrafted crochet items"
                    width={600}
                    height={600}
                    className="mx-auto aspect-square rounded-lg object-cover"
                  />
                </div>
                <div className="absolute -bottom-4 -right-4 bg-background p-4 rounded-full shadow-lg border border-primary/20">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="about" className="py-12 md:py-24 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="relative">
                <div className="stitch-border p-2 rounded-lg">
                  <Image
                    src="/placeholder.svg?height=600&width=600"
                    alt="About JaesCrochet"
                    width={600}
                    height={600}
                    className="mx-auto aspect-square rounded-lg object-cover"
                  />
                </div>
              </div>
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About JaesCrochet</h2>
                <p className="text-muted-foreground md:text-xl/relaxed">
                  JaesCrochet was born from a passion for creating beautiful, handcrafted items that bring warmth and
                  joy to homes everywhere. Each piece is lovingly made with premium yarns and meticulous attention to
                  detail.
                </p>
                <p className="text-muted-foreground md:text-xl/relaxed">
                  Our founder, Jae, has been crocheting for over 15 years and brings her expertise and artistic vision
                  to every creation. What started as a hobby has blossomed into a thriving business dedicated to sharing
                  the art of crochet with the world.
                </p>
                <div className="flex items-center gap-4 pt-4">
                  <div className="h-px flex-1 bg-border"></div>
                  <span className="text-sm font-medium">Handmade with love</span>
                  <div className="h-px flex-1 bg-border"></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="products" className="py-12 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Products</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Discover our collection of handcrafted crochet items, each made with care and attention to detail.
                </p>
              </div>
            </div>
            <FeaturedProducts />
            <div className="flex justify-center mt-8">
              <Button size="lg" className="yarn-button">
                View All Products
              </Button>
            </div>
          </div>
        </section>

        <section id="gallery" className="py-12 md:py-24 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Gallery</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  A showcase of our beautiful handcrafted crochet creations.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-8">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => (
                <div key={item} className="relative group overflow-hidden rounded-lg stitch-border p-1">
                  <Image
                    src={`/placeholder.svg?height=300&width=300&text=Gallery+${item}`}
                    alt={`Gallery image ${item}`}
                    width={300}
                    height={300}
                    className="aspect-square object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button variant="secondary" size="sm">
                      View
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <TestimonialSection />

        <section id="contact" className="py-12 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Get In Touch</h2>
                <p className="text-muted-foreground md:text-xl/relaxed">
                  Have questions about our products or interested in a custom order? We'd love to hear from you!
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-primary" />
                    <span>hello@jaescrochet.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Instagram className="h-5 w-5 text-primary" />
                    <span>@jaescrochet</span>
                  </div>
                </div>
                <div className="pt-4">
                  <NewsletterSignup />
                </div>
              </div>
              <div className="relative">
                <div className="stitch-border p-2 rounded-lg">
                  <Image
                    src="/placeholder.svg?height=600&width=600&text=Contact"
                    alt="Contact JaesCrochet"
                    width={600}
                    height={600}
                    className="mx-auto aspect-square rounded-lg object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t bg-muted/20">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:gap-8 md:py-12">
          <div className="flex-1 space-y-4">
            <div className="flex items-center gap-2">
              <Image src="/logo.svg" alt="JaesCrochet Logo" width={30} height={30} className="h-8 w-8" />
              <span className="text-lg font-bold tracking-tight">JaesCrochet</span>
            </div>
            <p className="text-sm text-muted-foreground">Handcrafted crochet items made with love and care.</p>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-3">
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Shop</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Home Decor
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Accessories
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Baby Items
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Custom Orders
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Company</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Connect</h3>
              <div className="flex gap-3">
                <Link href="https://instagram.com" aria-label="Instagram" className="p-2 rounded-full hover:bg-muted">
                  <Instagram className="h-5 w-5" />
                </Link>
                <Link href="https://facebook.com" aria-label="Facebook" className="p-2 rounded-full hover:bg-muted">
                  <Facebook className="h-5 w-5" />
                </Link>
                <Link href="https://twitter.com" aria-label="Twitter" className="p-2 rounded-full hover:bg-muted">
                  <Twitter className="h-5 w-5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
        <div className="container flex flex-col gap-4 border-t py-6 text-center md:flex-row md:items-center md:justify-between md:gap-0 md:py-8 md:text-left">
          <p className="text-xs text-muted-foreground">© 2023 JaesCrochet. All rights reserved.</p>
          <div className="flex justify-center gap-4 md:justify-end">
            <Link href="#" className="text-xs text-muted-foreground hover:text-foreground">
              Privacy Policy
            </Link>
            <Link href="#" className="text-xs text-muted-foreground hover:text-foreground">
              Terms of Service
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

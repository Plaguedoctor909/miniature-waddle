"use client"

import { useState } from "react"
import Image from "next/image"
import { Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const products = [
  {
    id: 1,
    name: "Cozy Throw Blanket",
    description: "A soft, warm blanket perfect for chilly evenings.",
    price: 89.99,
    image: "/placeholder.svg?height=400&width=400&text=Blanket",
    category: "Home Decor",
    bestseller: true,
  },
  {
    id: 2,
    name: "Amigurumi Teddy Bear",
    description: "Adorable handcrafted teddy bear, perfect for children or collectors.",
    price: 34.99,
    image: "/placeholder.svg?height=400&width=400&text=Teddy",
    category: "Toys",
    bestseller: false,
  },
  {
    id: 3,
    name: "Crochet Plant Hanger",
    description: "Beautiful macrame-style plant hanger for your indoor plants.",
    price: 24.99,
    image: "/placeholder.svg?height=400&width=400&text=Plant+Hanger",
    category: "Home Decor",
    bestseller: true,
  },
  {
    id: 4,
    name: "Winter Beanie Hat",
    description: "Warm and stylish beanie hat for cold winter days.",
    price: 29.99,
    image: "/placeholder.svg?height=400&width=400&text=Beanie",
    category: "Accessories",
    bestseller: false,
  },
]

export default function FeaturedProducts() {
  const [favorites, setFavorites] = useState<number[]>([])

  const toggleFavorite = (id: number) => {
    if (favorites.includes(id)) {
      setFavorites(favorites.filter((favId) => favId !== id))
    } else {
      setFavorites([...favorites, id])
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
      {products.map((product) => (
        <Card key={product.id} className="overflow-hidden group">
          <div className="relative">
            <div className="stitch-border-sm p-1 rounded-t-lg">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={400}
                height={400}
                className="aspect-square object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <button
              className="absolute top-2 right-2 p-2 bg-background/80 rounded-full shadow-sm"
              onClick={() => toggleFavorite(product.id)}
              aria-label={favorites.includes(product.id) ? "Remove from favorites" : "Add to favorites"}
            >
              <Heart
                className={`h-5 w-5 ${favorites.includes(product.id) ? "fill-primary text-primary" : "text-muted-foreground"}`}
              />
            </button>
            {product.bestseller && <Badge className="absolute top-2 left-2 bg-primary">Bestseller</Badge>}
          </div>
          <CardContent className="p-4">
            <div className="space-y-1">
              <h3 className="font-medium text-lg">{product.name}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
            </div>
            <div className="flex items-center justify-between mt-4">
              <span className="font-medium">${product.price.toFixed(2)}</span>
              <Badge variant="outline">{product.category}</Badge>
            </div>
          </CardContent>
          <CardFooter className="p-4 pt-0">
            <Button className="w-full yarn-button-sm">Add to Cart</Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

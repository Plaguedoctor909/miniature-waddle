"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle2 } from "lucide-react"

export default function NewsletterSignup() {
  const [email, setEmail] = useState("")
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !email.includes("@")) {
      setError("Please enter a valid email address")
      return
    }

    // Here you would typically send the email to your backend
    console.log("Subscribing email:", email)
    setSubmitted(true)
    setError("")
    setEmail("")
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Subscribe to our newsletter</h3>
      <p className="text-sm text-muted-foreground">
        Stay updated with our latest products, promotions, and crochet tips.
      </p>

      {submitted ? (
        <Alert className="bg-primary/10 border-primary/20">
          <CheckCircle2 className="h-4 w-4 text-primary" />
          <AlertDescription>Thank you for subscribing! We'll be in touch soon.</AlertDescription>
        </Alert>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-2">
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" className="yarn-button-sm">
              Subscribe
            </Button>
          </div>
          {error && <p className="text-sm text-red-500">{error}</p>}
        </form>
      )}
    </div>
  )
}

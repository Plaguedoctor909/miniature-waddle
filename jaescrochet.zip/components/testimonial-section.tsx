import Image from "next/image"
import { Quote } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"

const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Happy Customer",
    content:
      "The blanket I ordered is absolutely beautiful! The craftsmanship is exceptional, and it's become the centerpiece of my living room. I'll definitely be ordering more items soon!",
    avatar: "/placeholder.svg?height=100&width=100&text=SJ",
  },
  {
    id: 2,
    name: "Michael Chen",
    role: "Repeat Customer",
    content:
      "I've purchased several items from JaesCrochet, and each one has exceeded my expectations. The attention to detail and quality of materials used is outstanding.",
    avatar: "/placeholder.svg?height=100&width=100&text=MC",
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    role: "Interior Designer",
    content:
      "As an interior designer, I'm always looking for unique pieces for my clients. JaesCrochet's items add that perfect handmade touch that makes a space feel special and lived-in.",
    avatar: "/placeholder.svg?height=100&width=100&text=ER",
  },
]

export default function TestimonialSection() {
  return (
    <section className="py-12 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">What Our Customers Say</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Don't just take our word for it - hear from our satisfied customers.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="relative">
              <CardContent className="p-6">
                <Quote className="h-8 w-8 text-primary/20 absolute top-4 right-4" />
                <div className="flex items-center gap-4 mb-4">
                  <div className="relative h-12 w-12 rounded-full overflow-hidden stitch-border-xs">
                    <Image
                      src={testimonial.avatar || "/placeholder.svg"}
                      alt={testimonial.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-medium">{testimonial.name}</h4>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-muted-foreground">{testimonial.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

import Image from "next/image"

export default function HeroLogo() {
  return (
    <div className="flex flex-col items-center justify-center py-8">
      <div className="relative w-40 h-40 mb-4">
        <Image src="/logo.svg" alt="JaesCrochet Logo" fill className="object-contain" priority />
      </div>
      <h2 className="text-2xl font-bold text-primary text-center">Handcrafted with Love</h2>
    </div>
  )
}

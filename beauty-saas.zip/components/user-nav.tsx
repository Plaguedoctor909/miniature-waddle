"use client"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function UserNav() {
  const router = useRouter()
  // Default user info for bypassing authentication
  const userName = "Demo User"
  const userRole = "Makeup Artist"

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2 rounded-full outline-none ring-offset-background focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 p-1 pr-3 hover:bg-glam-purple/5 transition-colors">
          <Avatar className="h-8 w-8 ring-2 ring-glam-purple/20">
            <AvatarImage src="/placeholder.svg?height=32&width=32" alt={userName} />
            <AvatarFallback className="bg-gradient-to-br from-glam-purple/80 to-glam-gold/80 text-white">
              {userName[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="hidden text-sm font-medium md:inline-block bg-gradient-to-r from-glam-purple to-glam-gold bg-clip-text text-transparent">
            {userName}
          </span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuLabel>
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{userName}</p>
            <p className="text-xs leading-none text-muted-foreground">{userRole}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/settings">Settings</Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link href="/help">Help</Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => router.push("/")}>Switch Account</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

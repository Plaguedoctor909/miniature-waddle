"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import type { User, UserRole } from "@/types/auth"
import { getRoleFeatures } from "@/lib/role-features"
import { cn } from "@/lib/utils"

interface RoleNavProps {
  user: User
}

const roleSpecificLinks: Record<UserRole, { href: string; label: string }[]> = {
  wig_vendor: [
    { href: "/wig-catalog", label: "Wig Catalog" },
    { href: "/measurement-profiles", label: "Measurement Profiles" },
    { href: "/styling-services", label: "Styling Services" },
  ],
  makeup_artist: [
    { href: "/look-books", label: "Look Books" },
    { href: "/face-charts", label: "Face Charts" },
    { href: "/product-kits", label: "Product Kits" },
  ],
  nail_tech: [
    { href: "/design-gallery", label: "Design Gallery" },
    { href: "/nail-health", label: "Nail Health Records" },
    { href: "/polish-inventory", label: "Polish Inventory" },
  ],
  hairstylist: [
    { href: "/color-formulas", label: "Color Formulas" },
    { href: "/hair-portfolios", label: "Hair Portfolios" },
    { href: "/treatment-tracking", label: "Treatment Tracking" },
  ],
  skincare_spa: [
    { href: "/skin-analysis", label: "Skin Analysis" },
    { href: "/treatment-plans", label: "Treatment Plans" },
    { href: "/product-regimens", label: "Product Regimens" },
  ],
  brow_lash_tech: [
    { href: "/lash-maps", label: "Lash Maps" },
    { href: "/brow-designs", label: "Brow Designs" },
    { href: "/aftercare-tracking", label: "Aftercare Tracking" },
  ],
  bridal_glam: [
    { href: "/bridal-parties", label: "Bridal Parties" },
    { href: "/wedding-timelines", label: "Wedding Timelines" },
    { href: "/location-management", label: "Location Management" },
  ],
}

export function RoleNav({ user }: RoleNavProps) {
  const pathname = usePathname()
  const roleFeatures = getRoleFeatures(user.role)
  const links = roleSpecificLinks[user.role]

  return (
    <nav className="flex items-center space-x-4 lg:space-x-6 overflow-x-auto pb-2">
      {links.map((link, index) => (
        <Link
          key={index}
          href={link.href}
          className={cn(
            "whitespace-nowrap transition-colors hover:text-beauty-pink",
            pathname === link.href ? `text-${roleFeatures.primaryColor}` : "text-foreground/60",
          )}
        >
          {link.label}
        </Link>
      ))}
    </nav>
  )
}

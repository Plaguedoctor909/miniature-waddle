"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip, Legend } from "recharts"

interface ServicePopularityProps {
  className?: string
}

export function ServicePopularity({ className }: ServicePopularityProps) {
  return (
    <Card className={`${className} border border-beauty-purple/20 shadow-lg`}>
      <CardHeader className="bg-gradient-to-r from-beauty-purple/10 to-beauty-pink/10 rounded-t-lg">
        <CardTitle className="text-beauty-purple">Service Popularity</CardTitle>
        <CardDescription>Most popular services by number of bookings</CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={serviceData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                labelLine={false}
              >
                {serviceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number, name: string) => [`${value} bookings`, name]} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="mt-4 space-y-2">
          <h4 className="text-sm font-medium">Key Insights:</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Haircut & Styling remains the most popular service</li>
            <li>• Facial treatments have increased 15% since last month</li>
            <li>• Consider promoting less popular services</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}

const COLORS = ["#ff6b9d", "#7c4dff", "#00d2d3", "#feca57", "#ff9f43", "#2ed573"]

const serviceData = [
  { name: "Haircut & Styling", value: 120 },
  { name: "Hair Coloring", value: 85 },
  { name: "Manicure & Pedicure", value: 65 },
  { name: "Facial Treatments", value: 45 },
  { name: "Massage", value: 35 },
  { name: "Other Services", value: 25 },
]

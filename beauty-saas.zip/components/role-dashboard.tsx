"use client"

import { useEffect, useState } from "react"
import type { User } from "@/types/auth"
import { getRoleFeatures } from "@/lib/role-features"
import { Crown, Palette, Hand, Scissors, Flower, Eye, Heart } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const roleIcons = {
  wig_vendor: Crown,
  makeup_artist: Palette,
  nail_tech: Hand,
  hairstylist: Scissors,
  skincare_spa: Flower,
  brow_lash_tech: Eye,
  bridal_glam: Heart,
}

interface RoleDashboardProps {
  user: User
}

export function RoleDashboard({ user }: RoleDashboardProps) {
  const [greeting, setGreeting] = useState("")
  const roleFeatures = getRoleFeatures(user.role)
  const Icon = roleIcons[user.role]

  useEffect(() => {
    const hour = new Date().getHours()
    if (hour < 12) setGreeting("Good morning")
    else if (hour < 18) setGreeting("Good afternoon")
    else setGreeting("Good evening")
  }, [])

  return (
    <div className="space-y-6">
      <div
        className={`p-6 rounded-lg bg-gradient-to-r from-${roleFeatures.primaryColor} to-${roleFeatures.secondaryColor}`}
      >
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-white/20 rounded-full">
            <Icon className="h-8 w-8 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">
              {greeting}, {user.name}
            </h2>
            <p className="text-white/80">
              {roleFeatures.label} Dashboard
              {user.businessName ? ` • ${user.businessName}` : ""}
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {roleFeatures.specializedModules.map((module, index) => (
          <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">{module}</CardTitle>
              <CardDescription>Specialized for {roleFeatures.label}s</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Access your specialized {module.toLowerCase()} tools and features.
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="bg-muted rounded-lg p-6">
        <h3 className="text-lg font-medium mb-4">Your {roleFeatures.label} Features</h3>
        <ul className="grid gap-2 md:grid-cols-2">
          {roleFeatures.features.map((feature, index) => (
            <li key={index} className="flex items-center space-x-2">
              <div className={`h-2 w-2 rounded-full bg-${roleFeatures.primaryColor}`} />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

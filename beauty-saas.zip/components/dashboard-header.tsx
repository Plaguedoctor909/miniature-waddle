import type React from "react"
import { cn } from "@/lib/utils"

interface DashboardHeaderProps {
  heading: string
  text?: string
  children?: React.ReactNode
  className?: string
}

export function DashboardHeader({ heading, text, children, className }: DashboardHeaderProps) {
  return (
    <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-2 py-4", className)}>
      <div className="grid gap-1">
        <h1 className="text-2xl font-serif font-semibold tracking-tight bg-gradient-to-r from-glam-purple to-glam-gold bg-clip-text text-transparent">
          {heading}
        </h1>
        {text && <p className="text-muted-foreground max-w-2xl">{text}</p>}
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  )
}

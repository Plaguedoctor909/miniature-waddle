"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Search, Filter, MoreHorizontal, Trash2, Edit, Download, Check } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { getInvoices, getClientNameById, updateInvoice, deleteInvoice, type Invoice } from "@/lib/db-service"
import { useRouter } from "next/navigation"

export function InvoiceList() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [invoices, setInvoices] = useState<Invoice[]>([])

  useEffect(() => {
    loadInvoices()
  }, [])

  const loadInvoices = () => {
    const allInvoices = getInvoices()
    setInvoices(allInvoices)
  }

  const handleDeleteInvoice = (id: string) => {
    if (confirm("Are you sure you want to delete this invoice? This action cannot be undone.")) {
      const success = deleteInvoice(id)
      if (success) {
        loadInvoices()
      }
    }
  }

  const handleMarkAsPaid = (id: string) => {
    const updated = updateInvoice(id, { status: "paid" })
    if (updated) {
      loadInvoices()
    }
  }

  const calculateTotal = (invoice: Invoice) => {
    return invoice.items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  }

  const filteredInvoices = invoices.filter(
    (invoice) =>
      getClientNameById(invoice.clientId).toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.id.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Card className="border border-glam-gold/20 shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-glam-gold" />
            <Input
              placeholder="Search invoices..."
              className="pl-8 border-glam-gold/20 focus-visible:ring-glam-gold/30"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" size="sm" className="border-glam-gold/20 text-glam-gold hover:bg-glam-gold/10">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>

        <Table>
          <TableHeader className="bg-glam-gold/5">
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInvoices.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8">
                  <p className="text-muted-foreground">No invoices found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredInvoices.map((invoice) => (
                <TableRow key={invoice.id} className="hover:bg-glam-gold/5">
                  <TableCell>INV-{invoice.id.substring(0, 6).toUpperCase()}</TableCell>
                  <TableCell>{getClientNameById(invoice.clientId)}</TableCell>
                  <TableCell>{invoice.date}</TableCell>
                  <TableCell>{invoice.dueDate}</TableCell>
                  <TableCell className="font-medium">₦{calculateTotal(invoice).toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        invoice.status === "paid"
                          ? "bg-green-100 text-green-800 border-green-200"
                          : invoice.status === "overdue"
                            ? "bg-red-100 text-red-800 border-red-200"
                            : "bg-glam-gold/20 text-glam-gold border-glam-gold/30"
                      }
                    >
                      {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Actions</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => router.push(`/invoices/${invoice.id}`)}>
                          <Edit className="mr-2 h-4 w-4" /> View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => alert("Invoice downloaded")}>
                          <Download className="mr-2 h-4 w-4" /> Download PDF
                        </DropdownMenuItem>
                        {invoice.status !== "paid" && (
                          <DropdownMenuItem onClick={() => handleMarkAsPaid(invoice.id)}>
                            <Check className="mr-2 h-4 w-4" /> Mark as Paid
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => handleDeleteInvoice(invoice.id)} className="text-destructive">
                          <Trash2 className="mr-2 h-4 w-4" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Search, Filter, MoreHorizontal, Trash2, Edit } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { getClients, deleteClient, type Client } from "@/lib/db-service"
import { useRouter } from "next/navigation"

export function ClientList() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [clients, setClients] = useState<Client[]>([])

  useEffect(() => {
    loadClients()
  }, [])

  const loadClients = () => {
    const allClients = getClients()
    setClients(allClients)
  }

  const handleDeleteClient = (id: string) => {
    if (confirm("Are you sure you want to delete this client? This action cannot be undone.")) {
      const success = deleteClient(id)
      if (success) {
        loadClients()
      }
    }
  }

  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Card className="border border-glam-purple/20 shadow-lg overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-glam-purple" />
            <Input
              placeholder="Search clients..."
              className="pl-8 border-glam-purple/20 focus-visible:ring-glam-purple/30"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button
            variant="outline"
            size="sm"
            className="border-glam-purple/20 text-glam-purple hover:bg-glam-purple/10"
          >
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>

        <Table>
          <TableHeader className="bg-gradient-to-r from-glam-purple/10 to-glam-blush/5">
            <TableRow>
              <TableHead>Client</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Last Visit</TableHead>
              <TableHead>Spent</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredClients.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  <p className="text-muted-foreground">No clients found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredClients.map((client) => (
                <TableRow
                  key={client.id}
                  className="hover:bg-gradient-to-r hover:from-white hover:to-glam-purple/5 transition-all"
                >
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-9 w-9 ring-2 ring-glam-purple/20 shadow-sm">
                        <AvatarImage src={client.avatar || "/placeholder.svg"} alt={client.name} />
                        <AvatarFallback className="bg-gradient-to-br from-glam-purple/80 to-glam-gold/80 text-white">
                          {client.initials}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{client.name}</p>
                        <p className="text-xs text-muted-foreground">{client.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{client.phone}</TableCell>
                  <TableCell>{client.lastVisit}</TableCell>
                  <TableCell className="font-medium">₦{client.totalSpent.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        client.status === "VIP"
                          ? "bg-glam-gold/20 text-glam-gold border-glam-gold/30"
                          : client.status === "Regular"
                            ? "bg-glam-purple/20 text-glam-purple border-glam-purple/30"
                            : "bg-glam-blush/20 text-glam-blush border-glam-blush/30"
                      }
                    >
                      {client.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Actions</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => router.push(`/clients/${client.id}`)}>
                          <Edit className="mr-2 h-4 w-4" /> View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => router.push(`/bookings/new?client=${client.id}`)}>
                          <Edit className="mr-2 h-4 w-4" /> New Booking
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => router.push(`/invoices/new?client=${client.id}`)}>
                          <Edit className="mr-2 h-4 w-4" /> Create Invoice
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDeleteClient(client.id)} className="text-destructive">
                          <Trash2 className="mr-2 h-4 w-4" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

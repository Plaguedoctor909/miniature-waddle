"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { MoreHorizontal, Check, X, Search, Filter } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  getBookings,
  updateBooking,
  deleteBooking,
  getClientNameById,
  getClientInitialsById,
  getClientAvatarById,
  type Booking,
} from "@/lib/db-service"

export function BookingList() {
  const [searchQuery, setSearchQuery] = useState("")
  const [bookings, setBookings] = useState<Booking[]>([])

  useEffect(() => {
    loadBookings()
  }, [])

  const loadBookings = () => {
    const allBookings = getBookings()
    setBookings(allBookings)
  }

  const handleStatusChange = (id: string, status: "confirmed" | "cancelled" | "completed") => {
    const updatedBooking = updateBooking(id, { status })
    if (updatedBooking) {
      loadBookings()
    }
  }

  const handleDeleteBooking = (id: string) => {
    if (confirm("Are you sure you want to delete this booking? This action cannot be undone.")) {
      const success = deleteBooking(id)
      if (success) {
        loadBookings()
      }
    }
  }

  const filteredBookings = bookings.filter(
    (booking) =>
      getClientNameById(booking.clientId).toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.service.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Card className="border-glam-purple/20 shadow-md overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search bookings..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>

        <Table>
          <TableCaption>A list of your bookings.</TableCaption>
          <TableHeader className="bg-gradient-to-r from-glam-purple/10 to-transparent">
            <TableRow>
              <TableHead>Client</TableHead>
              <TableHead>Service</TableHead>
              <TableHead>Date & Time</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredBookings.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8">
                  <p className="text-muted-foreground">No bookings found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredBookings.map((booking) => (
                <TableRow
                  key={booking.id}
                  className={`transition-colors hover:bg-gradient-to-r hover:from-white hover:to-glam-purple/5 ${
                    booking.status === "cancelled" ? "bg-gray-50/50" : ""
                  }`}
                >
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-8 w-8 ring-2 ring-glam-purple/20 shadow-sm">
                        <AvatarImage
                          src={getClientAvatarById(booking.clientId) || "/placeholder.svg"}
                          alt={getClientNameById(booking.clientId)}
                        />
                        <AvatarFallback className="bg-gradient-to-br from-glam-purple/80 to-glam-blush/80 text-white">
                          {getClientInitialsById(booking.clientId)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{getClientNameById(booking.clientId)}</p>
                        <p className="text-xs text-muted-foreground">{booking.service}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{booking.service}</TableCell>
                  <TableCell>
                    {booking.date}, {booking.time}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        booking.status === "confirmed"
                          ? "default"
                          : booking.status === "cancelled"
                            ? "destructive"
                            : "secondary"
                      }
                      className={
                        booking.status === "confirmed"
                          ? "bg-gradient-to-r from-glam-purple to-glam-purple/80 text-white shadow-sm"
                          : booking.status === "cancelled"
                            ? "bg-gradient-to-r from-red-500 to-red-400 text-white shadow-sm"
                            : "bg-gradient-to-r from-green-500 to-green-400 text-white shadow-sm"
                      }
                    >
                      {booking.status === "confirmed"
                        ? "Confirmed"
                        : booking.status === "cancelled"
                          ? "Cancelled"
                          : "Completed"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Actions</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={() => handleStatusChange(booking.id, "confirmed")}
                          className="flex items-center"
                        >
                          <Check className="mr-2 h-4 w-4" /> Confirm
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleStatusChange(booking.id, "completed")}
                          className="flex items-center"
                        >
                          <Check className="mr-2 h-4 w-4" /> Mark as Completed
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleStatusChange(booking.id, "cancelled")}
                          className="flex items-center text-destructive"
                        >
                          <X className="mr-2 h-4 w-4" /> Cancel
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleDeleteBooking(booking.id)}
                          className="flex items-center text-destructive"
                        >
                          <X className="mr-2 h-4 w-4" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

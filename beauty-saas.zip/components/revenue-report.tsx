"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Bar, BarChart, Legend } from "recharts"

interface RevenueReportProps {
  className?: string
}

export function RevenueReport({ className }: RevenueReportProps) {
  return (
    <Card className={`${className} border border-beauty-orange/20 shadow-lg`}>
      <CardHeader className="bg-gradient-to-r from-beauty-orange/10 to-beauty-yellow/10 rounded-t-lg">
        <CardTitle className="text-beauty-orange">Revenue Report</CardTitle>
        <CardDescription>Track your business revenue over time</CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <Tabs defaultValue="overview">
          <TabsList className="mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="services">By Service</TabsTrigger>
            <TabsTrigger value="daily">Daily</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-4 gap-4">
              <Card className="col-span-1">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">₦3,245,000</div>
                  <p className="text-xs text-beauty-green">+18% from last month</p>
                </CardContent>
              </Card>
              <Card className="col-span-1">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Average Sale</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">₦12,500</div>
                  <p className="text-xs text-beauty-green">+5% from last month</p>
                </CardContent>
              </Card>
              <Card className="col-span-1">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Transactions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">259</div>
                  <p className="text-xs text-beauty-green">+12% from last month</p>
                </CardContent>
              </Card>
              <Card className="col-span-1">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Profit Margin</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">42%</div>
                  <p className="text-xs text-beauty-green">+3% from last month</p>
                </CardContent>
              </Card>
            </div>

            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueData}>
                  <XAxis dataKey="month" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis
                    stroke="#888888"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `₦${value / 1000}k`}
                  />
                  <Tooltip
                    formatter={(value: number) => [`₦${value.toLocaleString()}`, "Revenue"]}
                    labelFormatter={(label) => `Month: ${label}`}
                  />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="#ff6b9d"
                    strokeWidth={3}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="services" className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={serviceRevenueData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis
                  stroke="#888888"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `₦${value / 1000}k`}
                />
                <Tooltip
                  formatter={(value: number) => [`₦${value.toLocaleString()}`, "Revenue"]}
                  labelFormatter={(label) => `Service: ${label}`}
                />
                <Legend />
                <Bar dataKey="revenue" name="Revenue" fill="#7c4dff" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>

          <TabsContent value="daily" className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dailyRevenueData}>
                <XAxis dataKey="day" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis
                  stroke="#888888"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `₦${value / 1000}k`}
                />
                <Tooltip
                  formatter={(value: number) => [`₦${value.toLocaleString()}`, "Revenue"]}
                  labelFormatter={(label) => `Day: ${label}`}
                />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#00d2d3"
                  strokeWidth={2}
                  dot={{ r: 3 }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

const revenueData = [
  { month: "Jan", revenue: 120000 },
  { month: "Feb", revenue: 190000 },
  { month: "Mar", revenue: 230000 },
  { month: "Apr", revenue: 280000 },
  { month: "May", revenue: 350000 },
  { month: "Jun", revenue: 420000 },
  { month: "Jul", revenue: 480000 },
  { month: "Aug", revenue: 520000 },
  { month: "Sep", revenue: 490000 },
  { month: "Oct", revenue: 540000 },
  { month: "Nov", revenue: 580000 },
  { month: "Dec", revenue: 650000 },
]

const serviceRevenueData = [
  { name: "Haircut & Styling", revenue: 850000 },
  { name: "Hair Coloring", revenue: 720000 },
  { name: "Manicure & Pedicure", revenue: 450000 },
  { name: "Facial Treatments", revenue: 380000 },
  { name: "Massage", revenue: 320000 },
  { name: "Waxing", revenue: 280000 },
  { name: "Hair Extensions", revenue: 245000 },
]

const dailyRevenueData = [
  { day: "Mon", revenue: 45000 },
  { day: "Tue", revenue: 38000 },
  { day: "Wed", revenue: 42000 },
  { day: "Thu", revenue: 55000 },
  { day: "Fri", revenue: 78000 },
  { day: "Sat", revenue: 95000 },
  { day: "Sun", revenue: 65000 },
]

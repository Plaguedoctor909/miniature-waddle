"use client"

import { useState, useEffect } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, MapPin, MoreHorizontal, Check, X, Plus } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { format } from "date-fns"
import {
  getBookingsByDate,
  updateBooking,
  deleteBooking,
  getClientNameById,
  getClientInitialsById,
  getClientAvatarById,
} from "@/lib/db-service"
import Link from "next/link"

export function BookingCalendar() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [bookings, setBookings] = useState<any[]>([])

  useEffect(() => {
    if (date) {
      loadBookings(format(date, "yyyy-MM-dd"))
    }
  }, [date])

  const loadBookings = (dateStr: string) => {
    const bookingsForDate = getBookingsByDate(dateStr)
    setBookings(bookingsForDate)
  }

  const handleStatusChange = (id: string, status: "confirmed" | "cancelled" | "completed") => {
    const updatedBooking = updateBooking(id, { status })
    if (updatedBooking && date) {
      loadBookings(format(date, "yyyy-MM-dd"))
    }
  }

  const handleDeleteBooking = (id: string) => {
    const success = deleteBooking(id)
    if (success && date) {
      loadBookings(format(date, "yyyy-MM-dd"))
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
      <Card className="md:col-span-2 shadow-md border-glam-purple/20">
        <CardContent className="p-4">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-md border shadow-sm mx-auto max-w-[350px]"
            classNames={{
              day_selected: "bg-glam-purple text-white hover:bg-glam-purple/90",
              day_today: "bg-glam-blush/20 text-glam-purple font-bold",
              day_outside: "text-muted-foreground opacity-50",
            }}
          />
        </CardContent>
      </Card>

      <Card className="md:col-span-5 border-glam-purple/20 shadow-md">
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">{date ? format(date, "EEEE, MMMM d, yyyy") : "Select a date"}</h3>
            <Link href="/bookings/new">
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" /> Add Booking
              </Button>
            </Link>
          </div>

          {bookings.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-16 h-16 mb-4 rounded-full bg-gradient-to-br from-glam-blush/20 to-glam-purple/20 flex items-center justify-center">
                <Calendar className="h-8 w-8 text-glam-purple" />
              </div>
              <p className="text-sm text-muted-foreground mb-4">No bookings scheduled for this date</p>
              <Link href="/bookings/new">
                <Button variant="outline" className="border-glam-purple text-glam-purple hover:bg-glam-purple/10">
                  Add New Booking
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.map((booking) => (
                <div
                  key={booking.id}
                  className={`flex items-start justify-between p-4 border rounded-lg shadow-sm transition-all duration-200 hover:shadow-md ${
                    booking.status === "cancelled" ? "opacity-60 bg-gray-50" : "bg-white"
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className="text-center min-w-[60px]">
                      <div className="text-sm font-medium">{booking.time}</div>
                      <Badge variant="outline" className="mt-1">
                        {booking.duration}
                      </Badge>
                    </div>

                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10 ring-2 ring-glam-purple/20 shadow-sm">
                        <AvatarImage
                          src={getClientAvatarById(booking.clientId) || "/placeholder.svg"}
                          alt={getClientNameById(booking.clientId)}
                        />
                        <AvatarFallback className="bg-gradient-to-br from-glam-purple/80 to-glam-blush/80 text-white">
                          {getClientInitialsById(booking.clientId)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{getClientNameById(booking.clientId)}</p>
                        <p className="text-sm text-muted-foreground">{booking.service}</p>
                        <div className="flex items-center gap-4 mt-1">
                          <div className="flex items-center text-xs text-muted-foreground">
                            <Clock className="mr-1 h-3 w-3" />
                            {booking.duration}
                          </div>
                          {booking.location && (
                            <div className="flex items-center text-xs text-muted-foreground">
                              <MapPin className="mr-1 h-3 w-3" />
                              {booking.location}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        booking.status === "confirmed"
                          ? "default"
                          : booking.status === "cancelled"
                            ? "destructive"
                            : "secondary"
                      }
                      className={
                        booking.status === "confirmed"
                          ? "bg-gradient-to-r from-glam-purple to-glam-purple/80 text-white shadow-sm hover:shadow-md"
                          : booking.status === "cancelled"
                            ? "bg-gradient-to-r from-red-500 to-red-400 text-white shadow-sm"
                            : "bg-gradient-to-r from-green-500 to-green-400 text-white shadow-sm"
                      }
                    >
                      {booking.status === "confirmed"
                        ? "Confirmed"
                        : booking.status === "cancelled"
                          ? "Cancelled"
                          : "Completed"}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Actions</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={() => handleStatusChange(booking.id, "confirmed")}
                          className="flex items-center"
                        >
                          <Check className="mr-2 h-4 w-4" /> Confirm
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleStatusChange(booking.id, "completed")}
                          className="flex items-center"
                        >
                          <Check className="mr-2 h-4 w-4" /> Mark as Completed
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleStatusChange(booking.id, "cancelled")}
                          className="flex items-center text-destructive"
                        >
                          <X className="mr-2 h-4 w-4" /> Cancel
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleDeleteBooking(booking.id)}
                          className="flex items-center text-destructive"
                        >
                          <X className="mr-2 h-4 w-4" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

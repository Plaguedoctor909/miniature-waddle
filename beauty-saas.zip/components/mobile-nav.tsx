"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Menu, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"

function getCookie(name: string): string | undefined {
  if (typeof document === "undefined") return undefined
  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) return parts.pop()?.split(";").shift()
  return undefined
}

export function MobileNav() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const [userRole, setUserRole] = useState<string>("")
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    const role = getCookie("user_role")
    if (role) setUserRole(role)
  }, [])

  if (!isClient) return null

  // Base navigation items for all roles
  const items = [
    {
      href: "/",
      label: "Dashboard",
    },
    {
      href: "/bookings",
      label: "Bookings",
    },
    {
      href: "/clients",
      label: "Clients",
    },
    {
      href: "/orders",
      label: "Orders",
    },
    {
      href: "/invoices",
      label: "Invoices",
    },
    {
      href: "/reports",
      label: "Reports",
    },
  ]

  // Add role-specific navigation items
  if (userRole === "wig_vendor") {
    items.push({
      href: "/wig-catalog",
      label: "Wig Catalog",
    })
  } else if (userRole === "makeup_artist") {
    items.push({
      href: "/makeup-looks",
      label: "Makeup Looks",
    })
  } else if (userRole === "nail_tech") {
    items.push({
      href: "/nail-designs",
      label: "Nail Designs",
    })
  } else if (userRole === "hairstylist") {
    items.push({
      href: "/hair-services",
      label: "Hair Services",
    })
  } else if (userRole === "skincare_spa") {
    items.push({
      href: "/treatments",
      label: "Treatments",
    })
  } else if (userRole === "brow_lash_tech") {
    items.push({
      href: "/lash-brow-designs",
      label: "Lash & Brow Designs",
    })
  } else if (userRole === "bridal_glam") {
    items.push({
      href: "/bridal-packages",
      label: "Bridal Packages",
    })
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden relative w-10 h-10 overflow-hidden">
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-glam-purple/10 to-glam-gold/10 opacity-70" />
          <Menu className="h-5 w-5 text-glam-purple" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="pr-0 bg-gradient-to-br from-white to-glam-purple/5">
        <div className="flex items-center gap-3 mb-8">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-glam-purple to-glam-gold flex items-center justify-center shadow-sm">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
          <span className="font-serif font-bold text-xl bg-gradient-to-r from-glam-purple to-glam-gold bg-clip-text text-transparent">
            GlamTrack
          </span>
        </div>
        <nav className="flex flex-col gap-4">
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className={cn(
                "text-sm font-medium transition-colors hover:text-glam-purple",
                pathname === item.href || pathname?.startsWith(item.href + "/")
                  ? "text-glam-purple"
                  : "text-muted-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </SheetContent>
    </Sheet>
  )
}

import Link from "next/link"
import { Sparkles, Heart } from "lucide-react"

export function GlamFooter() {
  return (
    <footer className="border-t border-glam-purple/10 py-8 text-center text-sm bg-gradient-to-b from-white/50 to-glam-purple/5 backdrop-blur-sm">
      <div className="container">
        <div className="flex flex-col items-center justify-center">
          <Link href="/" className="flex items-center gap-2 mb-4">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-glam-purple/90 to-glam-gold/90 flex items-center justify-center shadow-sm">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <span className="font-serif font-bold text-lg bg-gradient-to-r from-glam-purple to-glam-gold bg-clip-text text-transparent">
              GlamTrack
            </span>
          </Link>

          <nav className="flex justify-center space-x-8 mb-4">
            <Link href="/terms" className="text-glam-purple/70 hover:text-glam-purple transition-colors">
              Terms
            </Link>
            <Link href="/privacy" className="text-glam-purple/70 hover:text-glam-purple transition-colors">
              Privacy
            </Link>
            <Link href="/help" className="text-glam-purple/70 hover:text-glam-purple transition-colors">
              Help
            </Link>
          </nav>

          <div className="flex items-center justify-center text-glam-purple/70">
            Made with <Heart className="h-3 w-3 mx-1 fill-glam-blush text-glam-blush" /> for beauty professionals
          </div>

          <p className="mt-2 text-glam-purple/70">© 2023 GlamTrack. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

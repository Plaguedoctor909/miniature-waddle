"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ClientDemographicsProps {
  className?: string
}

export function ClientDemographics({ className }: ClientDemographicsProps) {
  return (
    <Card className={`${className} border border-beauty-teal/20 shadow-lg`}>
      <CardHeader className="bg-gradient-to-r from-beauty-teal/10 to-beauty-green/10 rounded-t-lg">
        <CardTitle className="text-beauty-teal">Client Demographics</CardTitle>
        <CardDescription>Understand your client base better</CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <Tabs defaultValue="age">
          <TabsList className="mb-4">
            <TabsTrigger value="age">Age Groups</TabsTrigger>
            <TabsTrigger value="gender">Gender</TabsTrigger>
            <TabsTrigger value="loyalty">Loyalty</TabsTrigger>
          </TabsList>

          <TabsContent value="age" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ageData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  formatter={(value: number) => [`${value} clients`, "Count"]}
                  labelFormatter={(label) => `Age Group: ${label}`}
                />
                <Bar dataKey="value" name="Clients" fill="#00d2d3" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>

          <TabsContent value="gender" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={genderData} layout="vertical">
                <XAxis type="number" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis
                  dataKey="name"
                  type="category"
                  stroke="#888888"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  formatter={(value: number) => [`${value} clients (${((value / 248) * 100).toFixed(1)}%)`, "Count"]}
                />
                <Bar dataKey="value" name="Clients" fill="#7c4dff" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>

          <TabsContent value="loyalty" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={loyaltyData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip formatter={(value: number) => [`${value} clients`, "Count"]} />
                <Bar dataKey="value" name="Clients" fill="#ff6b9d" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

const ageData = [
  { name: "18-24", value: 35 },
  { name: "25-34", value: 84 },
  { name: "35-44", value: 65 },
  { name: "45-54", value: 42 },
  { name: "55+", value: 22 },
]

const genderData = [
  { name: "Female", value: 175 },
  { name: "Male", value: 68 },
  { name: "Other", value: 5 },
]

const loyaltyData = [
  { name: "New (0-3 mo)", value: 45 },
  { name: "Regular (3-12 mo)", value: 78 },
  { name: "Loyal (1-2 yrs)", value: 65 },
  { name: "VIP (2+ yrs)", value: 60 },
]

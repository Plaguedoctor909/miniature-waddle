"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, Filter, SlidersHorizontal } from "lucide-react"

// Mock wig data
const wigData = [
  {
    id: "1",
    name: "Elegant Bob",
    type: "Synthetic",
    length: "12 inches",
    color: "Jet Black",
    price: 129.99,
    stock: 5,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "2",
    name: "Curly Volume",
    type: "Human Hair",
    length: "16 inches",
    color: "Dark Brown",
    price: 249.99,
    stock: 3,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "3",
    name: "Long Straight",
    type: "Synthetic",
    length: "24 inches",
    color: "Blonde",
    price: 159.99,
    stock: 7,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "4",
    name: "Pixie Cut",
    type: "Human Hair",
    length: "6 inches",
    color: "Auburn",
    price: 189.99,
    stock: 2,
    image: "/placeholder.svg?height=200&width=200",
  },
]

export function WigCatalog() {
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  const filteredWigs = wigData.filter((wig) => {
    if (activeTab === "synthetic" && wig.type !== "Synthetic") return false
    if (activeTab === "human" && wig.type !== "Human Hair") return false
    if (activeTab === "low-stock" && wig.stock > 3) return false

    return (
      wig.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      wig.color.toLowerCase().includes(searchTerm.toLowerCase()) ||
      wig.type.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search wigs..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <SlidersHorizontal className="mr-2 h-4 w-4" />
            Sort
          </Button>
          <Button size="sm" className="bg-beauty-pink hover:bg-beauty-pink/90">
            <Plus className="mr-2 h-4 w-4" />
            Add Wig
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Wigs</TabsTrigger>
          <TabsTrigger value="synthetic">Synthetic</TabsTrigger>
          <TabsTrigger value="human">Human Hair</TabsTrigger>
          <TabsTrigger value="low-stock">Low Stock</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredWigs.map((wig) => (
              <WigCard key={wig.id} wig={wig} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="synthetic" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredWigs.map((wig) => (
              <WigCard key={wig.id} wig={wig} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="human" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredWigs.map((wig) => (
              <WigCard key={wig.id} wig={wig} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="low-stock" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredWigs.map((wig) => (
              <WigCard key={wig.id} wig={wig} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function WigCard({ wig }) {
  return (
    <Card className="overflow-hidden">
      <div className="aspect-square relative">
        <img src={wig.image || "/placeholder.svg"} alt={wig.name} className="object-cover w-full h-full" />
        <div className="absolute top-2 right-2">
          <span
            className={`px-2 py-1 text-xs font-medium rounded-full ${
              wig.stock <= 2
                ? "bg-red-100 text-red-800"
                : wig.stock <= 5
                  ? "bg-yellow-100 text-yellow-800"
                  : "bg-green-100 text-green-800"
            }`}
          >
            {wig.stock} in stock
          </span>
        </div>
      </div>
      <CardHeader className="p-4 pb-0">
        <CardTitle className="text-lg">{wig.name}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-2">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>
            <span className="text-muted-foreground">Type:</span> {wig.type}
          </div>
          <div>
            <span className="text-muted-foreground">Length:</span> {wig.length}
          </div>
          <div>
            <span className="text-muted-foreground">Color:</span> {wig.color}
          </div>
          <div>
            <span className="text-muted-foreground">Price:</span> ${wig.price}
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between">
        <Button variant="outline" size="sm">
          Edit
        </Button>
        <Button size="sm">View Details</Button>
      </CardFooter>
    </Card>
  )
}

"use client"

import { useState } from "react"
import type { User } from "@/types/auth"
import { getRoleFeatures } from "@/lib/role-features"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Crown, Palette, Hand, Scissors, Flower, Eye, Heart, Check } from "lucide-react"

const roleIcons = {
  wig_vendor: Crown,
  makeup_artist: Palette,
  nail_tech: Hand,
  hairstylist: Scissors,
  skincare_spa: Flower,
  brow_lash_tech: Eye,
  bridal_glam: Heart,
}

interface WelcomePageProps {
  user: User
  onComplete: () => void
}

export function WelcomePage({ user, onComplete }: WelcomePageProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const roleFeature = getRoleFeatures(user.role)
  const Icon = roleIcons[user.role]

  const steps = [
    {
      title: "Welcome to GlamTrack",
      description: `We're excited to have you join as a ${roleFeature.label}!`,
      content: (
        <div className="space-y-4">
          <div className="flex justify-center">
            <div className={`p-4 rounded-full bg-${roleFeature.primaryColor}/20`}>
              <Icon className={`h-12 w-12 text-${roleFeature.primaryColor}`} />
            </div>
          </div>
          <p>
            GlamTrack is tailored specifically for your needs as a {roleFeature.label}. We've customized your experience
            to help you manage your business efficiently.
          </p>
        </div>
      ),
    },
    {
      title: "Your Specialized Features",
      description: "Explore tools designed specifically for you",
      content: (
        <div className="space-y-4">
          <ul className="space-y-2">
            {roleFeature.features.map((feature, index) => (
              <li key={index} className="flex items-start space-x-2">
                <Check className={`h-5 w-5 text-${roleFeature.primaryColor} mt-0.5`} />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>
      ),
    },
    {
      title: "Get Started",
      description: "You're all set to begin using GlamTrack",
      content: (
        <div className="space-y-4 text-center">
          <p>Your dashboard is ready! Start by adding your clients, inventory, or scheduling appointments.</p>
          <div className="flex justify-center">
            <Button
              onClick={onComplete}
              className={`bg-${roleFeature.primaryColor} hover:bg-${roleFeature.primaryColor}/90`}
            >
              Go to Dashboard
            </Button>
          </div>
        </div>
      ),
    },
  ]

  const currentStepData = steps[currentStep]

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-beauty-pink/10 to-beauty-purple/10 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>{currentStepData.title}</CardTitle>
          <CardDescription>{currentStepData.description}</CardDescription>
        </CardHeader>
        <CardContent>{currentStepData.content}</CardContent>
        <CardFooter className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => setCurrentStep((prev) => Math.max(0, prev - 1))}
            disabled={currentStep === 0}
          >
            Previous
          </Button>
          <div className="flex space-x-1">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-2 w-2 rounded-full ${
                  index === currentStep ? `bg-${roleFeature.primaryColor}` : "bg-gray-300"
                }`}
              />
            ))}
          </div>
          <Button
            onClick={() => {
              if (currentStep < steps.length - 1) {
                setCurrentStep((prev) => prev + 1)
              } else {
                onComplete()
              }
            }}
          >
            {currentStep < steps.length - 1 ? "Next" : "Finish"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface StaffPerformanceProps {
  className?: string
}

export function StaffPerformance({ className }: StaffPerformanceProps) {
  return (
    <Card className={`${className} border border-beauty-pink/20 shadow-lg`}>
      <CardHeader className="bg-gradient-to-r from-beauty-pink/10 to-beauty-purple/10 rounded-t-lg">
        <CardTitle className="text-beauty-pink">Staff Performance</CardTitle>
        <CardDescription>Track your team's performance metrics</CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <Table>
          <TableHeader className="bg-beauty-pink/5">
            <TableRow>
              <TableHead>Staff Member</TableHead>
              <TableHead>Services</TableHead>
              <TableHead>Revenue</TableHead>
              <TableHead>Client Rating</TableHead>
              <TableHead>Rebooking Rate</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {staffData.map((staff) => (
              <TableRow key={staff.id} className="hover:bg-beauty-pink/5">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9 ring-2 ring-beauty-pink/20">
                      <AvatarImage src={staff.avatar || "/placeholder.svg"} alt={staff.name} />
                      <AvatarFallback className="bg-beauty-pink/20 text-beauty-pink">{staff.initials}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{staff.name}</p>
                      <p className="text-xs text-muted-foreground">{staff.role}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>{staff.services}</TableCell>
                <TableCell className="font-medium">₦{staff.revenue.toLocaleString()}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{staff.rating}/5</span>
                    <Progress
                      value={staff.rating * 20}
                      className={`h-2 w-16 ${
                        staff.rating >= 4.5
                          ? "bg-beauty-green/20"
                          : staff.rating >= 4.0
                            ? "bg-beauty-yellow/20"
                            : "bg-red-100"
                      }`}
                    />
                  </div>
                </TableCell>
                <TableCell>{staff.rebookingRate}%</TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={
                      staff.performance === "Excellent"
                        ? "bg-beauty-green/20 text-beauty-green border-beauty-green/30"
                        : staff.performance === "Good"
                          ? "bg-beauty-yellow/20 text-beauty-orange border-beauty-yellow/30"
                          : "bg-beauty-purple/20 text-beauty-purple border-beauty-purple/30"
                    }
                  >
                    {staff.performance}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

const staffData = [
  {
    id: "1",
    name: "Jennifer Lopez",
    initials: "JL",
    role: "Senior Stylist",
    avatar: "/placeholder.svg?height=36&width=36",
    services: 85,
    revenue: 950000,
    rating: 4.9,
    rebookingRate: 78,
    performance: "Excellent",
  },
  {
    id: "2",
    name: "Michael Chen",
    initials: "MC",
    role: "Hair Colorist",
    avatar: "/placeholder.svg?height=36&width=36",
    services: 62,
    revenue: 780000,
    rating: 4.7,
    rebookingRate: 72,
    performance: "Excellent",
  },
  {
    id: "3",
    name: "Sophia Williams",
    initials: "SW",
    role: "Nail Technician",
    avatar: "/placeholder.svg?height=36&width=36",
    services: 94,
    revenue: 520000,
    rating: 4.5,
    rebookingRate: 65,
    performance: "Good",
  },
  {
    id: "4",
    name: "David Johnson",
    initials: "DJ",
    role: "Barber",
    avatar: "/placeholder.svg?height=36&width=36",
    services: 78,
    revenue: 680000,
    rating: 4.6,
    rebookingRate: 70,
    performance: "Good",
  },
  {
    id: "5",
    name: "Aisha Patel",
    initials: "AP",
    role: "Esthetician",
    avatar: "/placeholder.svg?height=36&width=36",
    services: 56,
    revenue: 490000,
    rating: 4.8,
    rebookingRate: 75,
    performance: "Excellent",
  },
  {
    id: "6",
    name: "Carlos Rodriguez",
    initials: "CR",
    role: "Junior Stylist",
    avatar: "/placeholder.svg?height=36&width=36",
    services: 45,
    revenue: 320000,
    rating: 4.2,
    rebookingRate: 58,
    performance: "Good",
  },
]

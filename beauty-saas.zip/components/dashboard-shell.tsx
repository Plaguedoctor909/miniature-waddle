import type React from "react"
import { cn } from "@/lib/utils"
import { GlamHeader } from "@/components/glam-header"
import { GlamFooter } from "@/components/glam-footer"

interface DashboardShellProps {
  children: React.ReactNode
  className?: string
}

export function DashboardShell({ children, className }: DashboardShellProps) {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-white via-glam-blush/5 to-glam-purple/10">
      <GlamHeader />
      <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className={cn("mx-auto max-w-7xl", className)}>{children}</div>
      </main>
      <GlamFooter />
    </div>
  )
}

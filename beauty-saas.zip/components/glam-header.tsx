"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"
import { UserNav } from "@/components/user-nav"
import { MobileNav } from "@/components/mobile-nav"

export function GlamHeader() {
  const [scrolled, setScrolled] = useState(false)

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 20
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [scrolled])

  return (
    <header
      className={cn(
        "sticky top-0 z-40 transition-all duration-300",
        scrolled ? "border-b border-glam-purple/10 bg-white/90 backdrop-blur-md shadow-sm" : "bg-transparent",
      )}
    >
      <div className="container flex h-16 items-center justify-between py-4">
        <Link href="/" className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-glam-purple to-glam-gold flex items-center justify-center shadow-sm">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
          <span className="font-serif font-bold text-2xl bg-gradient-to-r from-glam-purple to-glam-gold bg-clip-text text-transparent">
            GlamTrack
          </span>
        </Link>

        <div className="flex items-center gap-4">
          <UserNav />
          <MobileNav />
        </div>
      </div>
    </header>
  )
}

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import type { ButtonProps } from "@/components/ui/button"

interface GlamButtonProps extends ButtonProps {
  variant?: "purple" | "nude" | "blush" | "gold"
}

export function GlamButton({ className, variant = "purple", children, ...props }: GlamButtonProps) {
  return (
    <Button
      className={cn(
        "shadow-sm font-medium transition-all duration-300",
        variant === "purple" &&
          "bg-gradient-to-r from-glam-purple to-glam-purple/90 hover:from-glam-purple/90 hover:to-glam-purple/80 text-white hover:shadow",
        variant === "nude" &&
          "bg-gradient-to-r from-glam-nude to-glam-nude/90 hover:from-glam-nude/90 hover:to-glam-nude/80 text-glam-purple hover:shadow",
        variant === "blush" &&
          "bg-gradient-to-r from-glam-blush to-glam-blush/90 hover:from-glam-blush/90 hover:to-glam-blush/80 text-glam-purple hover:shadow",
        variant === "gold" &&
          "bg-gradient-to-r from-glam-gold to-glam-gold/90 hover:from-glam-gold/90 hover:to-glam-gold/80 text-white hover:shadow",
        className,
      )}
      {...props}
    >
      {children}
    </Button>
  )
}

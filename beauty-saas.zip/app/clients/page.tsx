import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { ClientList } from "@/components/client-list"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Clients | GlamTrack",
  description: "Manage your client database",
}

export default function ClientsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Clients" text="Manage your client database and history.">
        <Link href="/clients/new">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" /> Add Client
          </Button>
        </Link>
      </DashboardHeader>
      <div className="grid gap-4">
        <ClientList />
      </div>
    </DashboardShell>
  )
}

import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { NewClientForm } from "@/components/new-client-form"

export const metadata = {
  title: "New Client | GlamTrack",
  description: "Add a new client to your database",
}

export default function NewClientPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="New Client" text="Add a new client to your database." />
      <NewClientForm />
    </DashboardShell>
  )
}

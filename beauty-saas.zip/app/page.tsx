"use client"

import { useEffect, useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, Users, CreditCard, ShoppingBag } from "lucide-react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { format } from "date-fns"
import Link from "next/link"
import { getBookings, getClients, getWeeklyRevenue } from "@/lib/db-service"

export default function DashboardPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [bookings, setBookings] = useState<any[]>([])
  const [clientCount, setClientCount] = useState(0)
  const [weeklyRevenue, setWeeklyRevenue] = useState(0)
  const [revenueData, setRevenueData] = useState<any[]>([])

  useEffect(() => {
    // Load data from our database service
    const loadData = () => {
      const allBookings = getBookings()
      const clients = getClients()
      const weekly = getWeeklyRevenue()

      // Get today's bookings
      const today = new Date().toISOString().split("T")[0]
      const todaysBookings = allBookings.filter((booking) => booking.date === today)

      // Format bookings for display
      const formattedBookings = todaysBookings.map((booking) => ({
        id: booking.id,
        client: clients.find((c) => c.id === booking.clientId)?.name || "Unknown Client",
        service: booking.service,
        time: booking.time,
      }))

      // Generate revenue data for the chart
      const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
      const todayDate = new Date()
      const chartData = []

      for (let i = 6; i >= 0; i--) {
        const date = new Date()
        date.setDate(todayDate.getDate() - i)
        const dayName = days[date.getDay()]
        const dateString = date.toISOString().split("T")[0]

        // Sum revenue for this date
        const dailyRevenue =
          allBookings
            .filter(
              (booking) =>
                booking.date === dateString && (booking.status === "confirmed" || booking.status === "completed"),
            )
            .reduce((sum, booking) => sum + booking.price, 0) * 1000 // Multiply by 1000 for display purposes

        chartData.push({
          name: dayName,
          total: dailyRevenue,
        })
      }

      setBookings(formattedBookings)
      setClientCount(clients.length)
      setWeeklyRevenue(weekly)
      setRevenueData(chartData)
      setIsLoading(false)
    }

    loadData()

    // Set up interval to refresh data every minute
    const interval = setInterval(loadData, 60000)

    return () => clearInterval(interval)
  }, [])

  if (isLoading) {
    return (
      <DashboardShell>
        <div className="flex items-center justify-center h-[80vh]">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-glam-purple border-t-transparent"></div>
        </div>
      </DashboardShell>
    )
  }

  const today = new Date()
  const formattedDate = format(today, "EEEE, MMMM d, yyyy")

  // Count completed and upcoming bookings
  const completedBookings = bookings.filter((b) => b.status === "completed").length
  const upcomingBookings = bookings.filter((b) => b.status !== "completed" && b.status !== "cancelled").length

  return (
    <DashboardShell>
      <DashboardHeader heading={`Welcome to GlamTrack`} text={`Here's your business overview for ${formattedDate}`} />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-t-4 border-glam-purple overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)] transition-all duration-300 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-glam-purple/10 to-transparent">
            <CardTitle className="text-sm font-medium">Today's Bookings</CardTitle>
            <div className="h-8 w-8 rounded-full bg-glam-purple/10 flex items-center justify-center">
              <Calendar className="h-4 w-4 text-glam-purple" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-glam-purple">{bookings.length}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-glam-purple font-medium">{completedBookings}</span> completed,
              <span className="text-glam-gold font-medium"> {upcomingBookings}</span> upcoming
            </p>
          </CardContent>
        </Card>

        <Card className="border-t-4 border-glam-nude overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)] transition-all duration-300 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-glam-nude/10 to-transparent">
            <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
            <div className="h-8 w-8 rounded-full bg-glam-nude/10 flex items-center justify-center">
              <Users className="h-4 w-4 text-glam-nude" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-glam-nude">{clientCount}</div>
            <p className="text-xs text-muted-foreground">Lifetime beauty clientele</p>
          </CardContent>
        </Card>

        <Card className="border-t-4 border-glam-blush overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)] transition-all duration-300 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-glam-blush/10 to-transparent">
            <CardTitle className="text-sm font-medium">Pending Orders</CardTitle>
            <div className="h-8 w-8 rounded-full bg-glam-blush/10 flex items-center justify-center">
              <ShoppingBag className="h-4 w-4 text-glam-blush" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-glam-blush">7</div>
            <p className="text-xs text-muted-foreground">3 require immediate attention</p>
          </CardContent>
        </Card>

        <Card className="border-t-4 border-glam-gold overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)] transition-all duration-300 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-glam-gold/10 to-transparent">
            <CardTitle className="text-sm font-medium">Weekly Revenue</CardTitle>
            <div className="h-8 w-8 rounded-full bg-glam-gold/10 flex items-center justify-center">
              <CreditCard className="h-4 w-4 text-glam-gold" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-glam-gold">₦{(weeklyRevenue / 1000).toLocaleString()}K</div>
            <p className="text-xs text-muted-foreground">This week's beauty earnings</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-7 mt-4">
        <Card className="col-span-4 shadow-md border-glam-purple/20 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
          <CardHeader className="bg-gradient-to-r from-glam-purple/10 to-glam-gold/10 rounded-t-lg border-b border-glam-purple/10">
            <CardTitle className="text-glam-purple font-serif">Revenue Overview</CardTitle>
            <CardDescription>Your revenue trends for the past week</CardDescription>
          </CardHeader>
          <CardContent className="pl-2 pt-6">
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={revenueData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis
                  stroke="#888888"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `₦${value / 1000}K`}
                />
                <Bar dataKey="total" radius={[6, 6, 0, 0]} fill="url(#colorGradient)" />
                <defs>
                  <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8A4FFF" stopOpacity={1} />
                    <stop offset="100%" stopColor="#D4AF37" stopOpacity={0.8} />
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card className="col-span-3 shadow-md border-glam-blush/20 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
          <CardHeader className="bg-gradient-to-r from-glam-blush/10 to-glam-purple/10 rounded-t-lg border-b border-glam-blush/10">
            <CardTitle className="text-glam-blush font-serif">Upcoming Bookings</CardTitle>
            <CardDescription>Your beauty schedule for today</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              {bookings.length > 0 ? (
                bookings.map((booking, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-lg border border-glam-purple/10 shadow-sm hover:shadow transition-all bg-gradient-to-r from-white to-glam-blush/5"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-glam-purple/20 to-glam-blush/20 shadow-sm">
                        <Clock className="h-4 w-4 text-glam-purple" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{booking.client}</p>
                        <p className="text-xs text-muted-foreground">{booking.service}</p>
                      </div>
                    </div>
                    <div className="text-sm font-medium text-glam-purple">{booking.time}</div>
                  </div>
                ))
              ) : (
                <div className="text-center py-6">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-glam-blush/20 to-glam-purple/20 flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-glam-purple" />
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">No bookings for today</p>
                </div>
              )}
              <div className="mt-4 text-center">
                <Link href="/bookings">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-glam-purple/50 text-glam-purple hover:bg-glam-purple/10"
                  >
                    View All Bookings
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-4">
        <Tabs defaultValue="quick-actions">
          <TabsList>
            <TabsTrigger value="quick-actions">Quick Actions</TabsTrigger>
            <TabsTrigger value="recent-activity">Recent Activity</TabsTrigger>
          </TabsList>
          <TabsContent value="quick-actions" className="mt-4">
            <div className="grid gap-4 md:grid-cols-3">
              <Link href="/bookings/new" className="block">
                <Card className="hover:bg-gradient-to-r hover:from-white hover:to-glam-purple/5 transition-all duration-300 cursor-pointer h-full shadow-sm hover:shadow-md border-glam-purple/20 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-r from-glam-purple/20 to-glam-purple/10 flex items-center justify-center">
                        <Calendar className="h-5 w-5 text-glam-purple" />
                      </div>
                      <span className="bg-gradient-to-r from-glam-purple to-glam-purple/80 bg-clip-text text-transparent">
                        New Booking
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">Schedule a new appointment with a client</p>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/clients/new" className="block">
                <Card className="hover:bg-gradient-to-r hover:from-white hover:to-glam-nude/5 transition-all duration-300 cursor-pointer h-full shadow-sm hover:shadow-md border-glam-nude/20 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-r from-glam-nude/20 to-glam-nude/10 flex items-center justify-center">
                        <Users className="h-5 w-5 text-glam-nude" />
                      </div>
                      <span className="bg-gradient-to-r from-glam-nude to-glam-nude/80 bg-clip-text text-transparent">
                        Add Client
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">Create a new client profile</p>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/invoices/new" className="block">
                <Card className="hover:bg-gradient-to-r hover:from-white hover:to-glam-gold/5 transition-all duration-300 cursor-pointer h-full shadow-sm hover:shadow-md border-glam-gold/20 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-r from-glam-gold/20 to-glam-gold/10 flex items-center justify-center">
                        <CreditCard className="h-5 w-5 text-glam-gold" />
                      </div>
                      <span className="bg-gradient-to-r from-glam-gold to-glam-gold/80 bg-clip-text text-transparent">
                        Create Invoice
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">Generate a new invoice for a client</p>
                  </CardContent>
                </Card>
              </Link>
            </div>
          </TabsContent>
          <TabsContent value="recent-activity" className="mt-4">
            <Card className="shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-center gap-4 pb-4 border-b last:border-0">
                      <div className={`w-2 h-2 rounded-full bg-glam-${activity.color}`}></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.description}</p>
                        <p className="text-xs text-muted-foreground">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardShell>
  )
}

const recentActivity = [
  { description: "New booking from Jessica Wilson", time: "10 minutes ago", color: "purple" },
  { description: "Invoice #1234 paid", time: "1 hour ago", color: "gold" },
  { description: "New client registered", time: "3 hours ago", color: "blush" },
  { description: "Order #5678 completed", time: "Yesterday", color: "nude" },
]

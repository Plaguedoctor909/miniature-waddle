import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { WigCatalog } from "@/components/wig-catalog"
import { requireAuth } from "@/lib/auth-service"

export const metadata = {
  title: "Wig Catalog | GlamTrack",
  description: "Manage your wig inventory and catalog",
}

export default async function WigCatalogPage() {
  const user = await requireAuth()

  // Redirect if not a wig vendor
  if (user.role !== "wig_vendor") {
    return {
      redirect: {
        destination: "/",
        permanent: false,
      },
    }
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Wig Catalog" text="Manage your wig inventory, styles, and pricing." />
      <WigCatalog />
    </DashboardShell>
  )
}

import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { NewBookingForm } from "@/components/new-booking-form"

export const metadata = {
  title: "New Booking | GlamTrack",
  description: "Create a new booking for a client",
}

export default function NewBookingPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="New Booking" text="Create a new booking for a client." />
      <NewBookingForm />
    </DashboardShell>
  )
}

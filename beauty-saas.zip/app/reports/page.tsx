import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { RevenueReport } from "@/components/revenue-report"
import { ServicePopularity } from "@/components/service-popularity"
import { ClientDemographics } from "@/components/client-demographics"
import { StaffPerformance } from "@/components/staff-performance"
import { DateRangePicker } from "@/components/date-range-picker"

export const metadata: Metadata = {
  title: "Reports | BeautyPro",
  description: "View analytics and reports for your beauty business",
}

export default function ReportsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Reports" text="View analytics and insights for your beauty business.">
        <DateRangePicker />
      </DashboardHeader>

      <div className="grid gap-4 md:grid-cols-2">
        <RevenueReport className="md:col-span-2" />
        <ServicePopularity />
        <ClientDemographics />
      </div>

      <div className="mt-4">
        <StaffPerformance />
      </div>
    </DashboardShell>
  )
}

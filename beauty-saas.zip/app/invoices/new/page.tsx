import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { NewInvoiceForm } from "@/components/new-invoice-form"

export const metadata = {
  title: "New Invoice | GlamTrack",
  description: "Create a new invoice for a client",
}

export default function NewInvoicePage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="New Invoice" text="Create a new invoice for a client." />
      <NewInvoiceForm />
    </DashboardShell>
  )
}

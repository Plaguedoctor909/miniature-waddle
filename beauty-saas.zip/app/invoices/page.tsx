import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { InvoiceList } from "@/components/invoice-list"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Invoices | GlamTrack",
  description: "Manage your client invoices",
}

export default function InvoicesPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Invoices" text="Manage your client invoices and payments.">
        <Link href="/invoices/new">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" /> Create Invoice
          </Button>
        </Link>
      </DashboardHeader>
      <div className="grid gap-4">
        <InvoiceList />
      </div>
    </DashboardShell>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Sparkles } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function LoginPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsLoading(true)
    setError("")

    const formData = new FormData(event.currentTarget)
    const usernameOrEmail = formData.get("usernameOrEmail") as string
    const password = formData.get("password") as string

    try {
      // For demo purposes, we'll just simulate a successful login
      // In a real app, you would validate credentials against a database

      // Simulate successful login with demo users
      let isValidUser = false
      let userRole = ""

      if ((usernameOrEmail === "wigmaster" || usernameOrEmail === "wigs@example.com") && password === "password123") {
        isValidUser = true
        userRole = "wig_vendor"
      } else if (
        (usernameOrEmail === "makeupqueen" || usernameOrEmail === "makeup@example.com") &&
        password === "password123"
      ) {
        isValidUser = true
        userRole = "makeup_artist"
      } else if (
        (usernameOrEmail === "nailpro" || usernameOrEmail === "nails@example.com") &&
        password === "password123"
      ) {
        isValidUser = true
        userRole = "nail_tech"
      }

      if (!isValidUser) {
        setError("Invalid username/email or password")
        setIsLoading(false)
        return
      }

      // Set cookies directly
      document.cookie = `auth_token=demo-token-${Date.now()}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Lax`
      document.cookie = `user_role=${userRole}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Lax`
      document.cookie = `user_name=${usernameOrEmail}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Lax`

      // Redirect to dashboard
      router.push("/")
      router.refresh()
    } catch (err) {
      console.error(err)
      setError("An error occurred during login")
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-beauty-pink/10 to-beauty-purple/10 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-2">
            <Sparkles className="h-10 w-10 text-beauty-pink" />
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-beauty-pink to-beauty-purple bg-clip-text text-transparent">
            GlamTrack
          </CardTitle>
          <CardDescription>Enter your credentials to access your account</CardDescription>
        </CardHeader>
        <form onSubmit={onSubmit}>
          <CardContent className="space-y-4">
            {error && <div className="p-3 text-sm text-white bg-red-500 rounded-md">{error}</div>}
            <div className="space-y-2">
              <Label htmlFor="usernameOrEmail">Username or Email</Label>
              <Input id="usernameOrEmail" name="usernameOrEmail" placeholder="Enter your username or email" required />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link href="/forgot-password" className="text-sm text-beauty-purple hover:underline">
                  Forgot password?
                </Link>
              </div>
              <Input id="password" name="password" type="password" placeholder="Enter your password" required />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <Button type="submit" className="w-full bg-beauty-pink hover:bg-beauty-pink/90" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Sign in"}
            </Button>
            <div className="text-center text-sm">
              Don&apos;t have an account?{" "}
              <Link href="/signup" className="text-beauty-purple hover:underline">
                Sign up
              </Link>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

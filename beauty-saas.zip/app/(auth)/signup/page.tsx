"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Sparkles, Crown, Palette, Hand, Scissors, Flower, Eye, Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { createUser } from "@/lib/auth-service"
import type { UserRole } from "@/types/auth"
import { getAllRoles } from "@/lib/role-features"
import { cn } from "@/lib/utils"

const roleIcons = {
  wig_vendor: Crown,
  makeup_artist: Palette,
  nail_tech: Hand,
  hairstylist: Scissors,
  skincare_spa: Flower,
  brow_lash_tech: Eye,
  bridal_glam: Heart,
}

export default function SignupPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null)
  const roles = getAllRoles()

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!selectedRole) {
      setError("Please select your profession")
      return
    }

    setIsLoading(true)
    setError("")

    const formData = new FormData(event.currentTarget)
    const username = formData.get("username") as string
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const name = formData.get("name") as string
    const businessName = formData.get("businessName") as string

    try {
      const user = await createUser(username, email, password, selectedRole, name, businessName)

      if (!user) {
        setError("Username or email already exists")
        setIsLoading(false)
        return
      }

      // Redirect to login
      router.push("/login?registered=true")
    } catch (err) {
      console.error(err)
      setError("An error occurred during registration")
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-beauty-pink/10 to-beauty-purple/10 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-2">
            <Sparkles className="h-10 w-10 text-beauty-pink" />
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-beauty-pink to-beauty-purple bg-clip-text text-transparent">
            Join GlamTrack
          </CardTitle>
          <CardDescription>Create an account to manage your beauty business</CardDescription>
        </CardHeader>

        {/* Floating profession selector */}
        <div className="px-6 py-3">
          <Label className="block mb-2">Select your profession</Label>
          <div className="flex overflow-x-auto pb-2 space-x-2 scrollbar-thin scrollbar-thumb-beauty-pink scrollbar-track-gray-100">
            {roles.map((role) => {
              const Icon = roleIcons[role.role]
              return (
                <button
                  key={role.role}
                  type="button"
                  onClick={() => setSelectedRole(role.role)}
                  className={cn(
                    "flex flex-col items-center justify-center p-3 rounded-lg border min-w-[100px] transition-all",
                    selectedRole === role.role
                      ? `border-${role.primaryColor} bg-${role.primaryColor}/10 text-${role.primaryColor}`
                      : "border-gray-200 hover:border-gray-300",
                  )}
                >
                  <Icon
                    className={cn(
                      "h-6 w-6 mb-1",
                      selectedRole === role.role ? `text-${role.primaryColor}` : "text-gray-500",
                    )}
                  />
                  <span className="text-xs font-medium">{role.label}</span>
                </button>
              )
            })}
          </div>
        </div>

        <form onSubmit={onSubmit}>
          <CardContent className="space-y-4">
            {error && <div className="p-3 text-sm text-white bg-red-500 rounded-md">{error}</div>}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" name="name" placeholder="Your name" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" name="username" placeholder="Choose a username" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" placeholder="your@email.com" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="businessName">Business Name (Optional)</Label>
              <Input id="businessName" name="businessName" placeholder="Your business name" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                placeholder="Create a password"
                required
                minLength={8}
              />
              <p className="text-xs text-gray-500">Password must be at least 8 characters long</p>
            </div>
          </CardContent>

          <CardFooter className="flex flex-col space-y-4">
            <Button
              type="submit"
              className="w-full bg-beauty-pink hover:bg-beauty-pink/90"
              disabled={isLoading || !selectedRole}
            >
              {isLoading ? "Creating account..." : "Create account"}
            </Button>
            <div className="text-center text-sm">
              Already have an account?{" "}
              <Link href="/login" className="text-beauty-purple hover:underline">
                Sign in
              </Link>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

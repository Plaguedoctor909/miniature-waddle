"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { v4 as uuidv4 } from "uuid"
import bcrypt from "bcryptjs"
import type { User, UserRole } from "@/types/auth"

// In a real app, this would be a database connection
// For this demo, we'll use an in-memory store
const users: User[] = []
const credentials: { userId: string; passwordHash: string }[] = []
let sessions: { userId: string; token: string; expires: Date }[] = []

export async function createUser(
  username: string,
  email: string,
  password: string,
  role: UserRole,
  name: string,
  businessName?: string,
): Promise<User | null> {
  // Check if user already exists
  const existingUser = users.find((u) => u.username === username || u.email === email)

  if (existingUser) {
    return null
  }

  // Create new user
  const userId = uuidv4()
  const passwordHash = await bcrypt.hash(password, 10)

  const newUser: User = {
    id: userId,
    username,
    email,
    role,
    name,
    businessName,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastLogin: null,
    isActive: true,
    profileImage: `/placeholder.svg?height=100&width=100`,
  }

  users.push(newUser)
  credentials.push({
    id: uuidv4(),
    userId,
    passwordHash,
    createdAt: new Date(),
    updatedAt: new Date(),
  })

  return newUser
}

export async function authenticateUser(
  usernameOrEmail: string,
  password: string,
): Promise<{ user: User; token: string } | null> {
  // Find user
  const user = users.find((u) => u.username === usernameOrEmail || u.email === usernameOrEmail)

  if (!user) {
    return null
  }

  // Find credentials
  const userCreds = credentials.find((c) => c.userId === user.id)

  if (!userCreds) {
    return null
  }

  // Verify password
  const passwordMatch = await bcrypt.compare(password, userCreds.passwordHash)

  if (!passwordMatch) {
    return null
  }

  // Create session
  const token = uuidv4()
  const expires = new Date()
  expires.setDate(expires.getDate() + 7) // 7 days from now

  sessions.push({
    userId: user.id,
    token,
    expires,
  })

  // Update last login
  user.lastLogin = new Date()
  user.updatedAt = new Date()

  return { user, token }
}

export async function getCurrentUser(): Promise<User | null> {
  const cookieStore = cookies()
  const token = cookieStore.get("auth_token")?.value

  if (!token) {
    return null
  }

  const session = sessions.find((s) => s.token === token && s.expires > new Date())

  if (!session) {
    return null
  }

  return users.find((u) => u.id === session.userId) || null
}

export async function logout() {
  const cookieStore = cookies()
  const token = cookieStore.get("auth_token")?.value

  if (token) {
    sessions = sessions.filter((s) => s.token !== token)
    cookies().delete("auth_token")
  }

  redirect("/login")
}

export async function requireAuth() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/login")
  }

  return user
}

// Add some demo users
createUser("wigmaster", "wigs@example.com", "password123", "wig_vendor", "Wig Master", "Wig Wonderland")

createUser("makeupqueen", "makeup@example.com", "password123", "makeup_artist", "Makeup Queen", "Flawless Face Studio")

createUser("nailpro", "nails@example.com", "password123", "nail_tech", "Nail Pro", "Perfect Polish")

import type { RoleFeatures, UserRole } from "@/types/auth"

export const roleFeatures: Record<UserRole, RoleFeatures> = {
  wig_vendor: {
    role: "wig_vendor",
    label: "Wig Vendor",
    description: "Manage your wig inventory, sales, and client fittings",
    icon: "crown",
    primaryColor: "beauty-pink",
    secondaryColor: "beauty-purple",
    features: [
      "Wig inventory management",
      "Client measurements tracking",
      "Fitting appointments",
      "Custom wig orders",
      "Maintenance reminders",
    ],
    specializedModules: ["Wig Catalog", "Measurement Profiles", "Styling Services"],
  },
  makeup_artist: {
    role: "makeup_artist",
    label: "Makeup Artist",
    description: "Track clients, bookings, and your makeup inventory",
    icon: "palette",
    primaryColor: "beauty-purple",
    secondaryColor: "beauty-pink",
    features: [
      "Client face charts",
      "Product inventory",
      "Look galleries",
      "Booking management",
      "Product usage tracking",
    ],
    specializedModules: ["Look Books", "Face Charts", "Product Kits"],
  },
  nail_tech: {
    role: "nail_tech",
    label: "Nail Technician",
    description: "Manage appointments, designs, and nail products",
    icon: "hand",
    primaryColor: "beauty-teal",
    secondaryColor: "beauty-yellow",
    features: [
      "Design catalog",
      "Client nail health tracking",
      "Product inventory",
      "Appointment scheduling",
      "Service packages",
    ],
    specializedModules: ["Design Gallery", "Nail Health Records", "Polish Inventory"],
  },
  hairstylist: {
    role: "hairstylist",
    label: "Hairstylist",
    description: "Track client hair history, appointments, and products",
    icon: "scissors",
    primaryColor: "beauty-orange",
    secondaryColor: "beauty-yellow",
    features: [
      "Client hair profiles",
      "Color formulas",
      "Appointment scheduling",
      "Before/after gallery",
      "Product recommendations",
    ],
    specializedModules: ["Color Formulas", "Hair Portfolios", "Treatment Tracking"],
  },
  skincare_spa: {
    role: "skincare_spa",
    label: "Skincare & Spa",
    description: "Manage treatments, client skin profiles, and products",
    icon: "flower",
    primaryColor: "beauty-green",
    secondaryColor: "beauty-teal",
    features: [
      "Skin assessments",
      "Treatment tracking",
      "Product recommendations",
      "Spa scheduling",
      "Client progress photos",
    ],
    specializedModules: ["Skin Analysis", "Treatment Plans", "Product Regimens"],
  },
  brow_lash_tech: {
    role: "brow_lash_tech",
    label: "Brow & Lash Tech",
    description: "Track lash extensions, brow services, and client records",
    icon: "eye",
    primaryColor: "beauty-yellow",
    secondaryColor: "beauty-orange",
    features: [
      "Lash mapping",
      "Brow shaping records",
      "Before/after photos",
      "Product inventory",
      "Appointment scheduling",
    ],
    specializedModules: ["Lash Maps", "Brow Designs", "Aftercare Tracking"],
  },
  bridal_glam: {
    role: "bridal_glam",
    label: "Bridal Glam Squad",
    description: "Coordinate bridal beauty services, trials, and day-of scheduling",
    icon: "heart",
    primaryColor: "beauty-pink",
    secondaryColor: "beauty-teal",
    features: [
      "Bridal party management",
      "Trial appointments",
      "Day-of scheduling",
      "Location logistics",
      "Service packages",
    ],
    specializedModules: ["Bridal Parties", "Wedding Timelines", "Location Management"],
  },
}

export function getRoleFeatures(role: UserRole): RoleFeatures {
  return roleFeatures[role]
}

export function getAllRoles(): RoleFeatures[] {
  return Object.values(roleFeatures)
}

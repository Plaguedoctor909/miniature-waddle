"use client"

// Types for our database entities
export interface Client {
  id: string
  name: string
  email: string
  phone: string
  avatar?: string
  initials: string
  lastVisit: string
  totalSpent: number
  status: "VIP" | "Regular" | "New"
}

export interface Booking {
  id: string
  date: string
  time: string
  duration: string
  clientId: string
  service: string
  status: "confirmed" | "cancelled" | "completed"
  location?: string
  notes?: string
  price: number
}

export interface Invoice {
  id: string
  clientId: string
  date: string
  dueDate: string
  items: {
    description: string
    quantity: number
    price: number
  }[]
  status: "paid" | "pending" | "overdue"
  notes?: string
}

export interface Revenue {
  date: string
  amount: number
  source: string
}

// Helper function to generate a unique ID
function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
}

// Initialize database with sample data if it doesn't exist
function initializeDatabase() {
  if (typeof window === "undefined") return

  // Initialize clients
  if (!localStorage.getItem("glamtrack_clients")) {
    const sampleClients: Client[] = [
      {
        id: generateId(),
        name: "Sarah Johnson",
        email: "sarah@example.com",
        phone: "(555) 123-4567",
        avatar: "/placeholder.svg?height=36&width=36",
        initials: "SJ",
        lastVisit: "2 days ago",
        totalSpent: 485,
        status: "Regular",
      },
      {
        id: generateId(),
        name: "Emily Davis",
        email: "emily@example.com",
        phone: "(555) 234-5678",
        avatar: "/placeholder.svg?height=36&width=36",
        initials: "ED",
        lastVisit: "1 week ago",
        totalSpent: 320,
        status: "Regular",
      },
      {
        id: generateId(),
        name: "Michael Brown",
        email: "michael@example.com",
        phone: "(555) 345-6789",
        avatar: "/placeholder.svg?height=36&width=36",
        initials: "MB",
        lastVisit: "Today",
        totalSpent: 35,
        status: "Regular",
      },
    ]
    localStorage.setItem("glamtrack_clients", JSON.stringify(sampleClients))
  }

  // Initialize bookings
  if (!localStorage.getItem("glamtrack_bookings")) {
    const clients = JSON.parse(localStorage.getItem("glamtrack_clients") || "[]")
    const today = new Date().toISOString().split("T")[0]

    const sampleBookings: Booking[] = [
      {
        id: generateId(),
        date: today,
        time: "9:00 AM",
        duration: "45 min",
        clientId: clients[0]?.id || generateId(),
        service: "Haircut & Styling",
        status: "confirmed",
        location: "In-studio",
        price: 85,
      },
      {
        id: generateId(),
        date: today,
        time: "10:30 AM",
        duration: "60 min",
        clientId: clients[1]?.id || generateId(),
        service: "Manicure & Pedicure",
        status: "confirmed",
        location: "In-studio",
        price: 65,
      },
      {
        id: generateId(),
        date: today,
        time: "12:00 PM",
        duration: "30 min",
        clientId: clients[2]?.id || generateId(),
        service: "Beard Trim",
        status: "cancelled",
        location: "In-studio",
        price: 35,
      },
    ]
    localStorage.setItem("glamtrack_bookings", JSON.stringify(sampleBookings))
  }

  // Initialize invoices
  if (!localStorage.getItem("glamtrack_invoices")) {
    const clients = JSON.parse(localStorage.getItem("glamtrack_clients") || "[]")
    const today = new Date().toISOString().split("T")[0]
    const dueDate = new Date()
    dueDate.setDate(dueDate.getDate() + 7)

    const sampleInvoices: Invoice[] = [
      {
        id: generateId(),
        clientId: clients[0]?.id || generateId(),
        date: today,
        dueDate: dueDate.toISOString().split("T")[0],
        items: [
          { description: "Haircut & Styling", quantity: 1, price: 85 },
          { description: "Hair Products", quantity: 2, price: 25 },
        ],
        status: "paid",
      },
      {
        id: generateId(),
        clientId: clients[1]?.id || generateId(),
        date: today,
        dueDate: dueDate.toISOString().split("T")[0],
        items: [{ description: "Manicure & Pedicure", quantity: 1, price: 65 }],
        status: "pending",
      },
    ]
    localStorage.setItem("glamtrack_invoices", JSON.stringify(sampleInvoices))
  }

  // Initialize revenue data
  if (!localStorage.getItem("glamtrack_revenue")) {
    const today = new Date()
    const sampleRevenue: Revenue[] = [
      {
        date: new Date(today.setDate(today.getDate() - 6)).toISOString().split("T")[0],
        amount: 120000,
        source: "Services",
      },
      {
        date: new Date(today.setDate(today.getDate() + 1)).toISOString().split("T")[0],
        amount: 95000,
        source: "Services",
      },
      {
        date: new Date(today.setDate(today.getDate() + 1)).toISOString().split("T")[0],
        amount: 157000,
        source: "Services",
      },
      {
        date: new Date(today.setDate(today.getDate() + 1)).toISOString().split("T")[0],
        amount: 139000,
        source: "Services",
      },
      {
        date: new Date(today.setDate(today.getDate() + 1)).toISOString().split("T")[0],
        amount: 185000,
        source: "Services",
      },
      {
        date: new Date(today.setDate(today.getDate() + 1)).toISOString().split("T")[0],
        amount: 210000,
        source: "Services",
      },
      {
        date: new Date(today.setDate(today.getDate() + 1)).toISOString().split("T")[0],
        amount: 120000,
        source: "Services",
      },
    ]
    localStorage.setItem("glamtrack_revenue", JSON.stringify(sampleRevenue))
  }
}

// Client operations
export function getClients(): Client[] {
  if (typeof window === "undefined") return []
  initializeDatabase()
  return JSON.parse(localStorage.getItem("glamtrack_clients") || "[]")
}

export function getClient(id: string): Client | null {
  const clients = getClients()
  return clients.find((client) => client.id === id) || null
}

export function addClient(client: Omit<Client, "id">): Client {
  const clients = getClients()
  const newClient = { ...client, id: generateId() }
  clients.push(newClient)
  localStorage.setItem("glamtrack_clients", JSON.stringify(clients))
  return newClient
}

export function updateClient(id: string, updates: Partial<Client>): Client | null {
  const clients = getClients()
  const index = clients.findIndex((client) => client.id === id)
  if (index === -1) return null

  clients[index] = { ...clients[index], ...updates }
  localStorage.setItem("glamtrack_clients", JSON.stringify(clients))
  return clients[index]
}

export function deleteClient(id: string): boolean {
  const clients = getClients()
  const filteredClients = clients.filter((client) => client.id !== id)
  if (filteredClients.length === clients.length) return false

  localStorage.setItem("glamtrack_clients", JSON.stringify(filteredClients))
  return true
}

// Booking operations
export function getBookings(): Booking[] {
  if (typeof window === "undefined") return []
  initializeDatabase()
  return JSON.parse(localStorage.getItem("glamtrack_bookings") || "[]")
}

export function getBooking(id: string): Booking | null {
  const bookings = getBookings()
  return bookings.find((booking) => booking.id === id) || null
}

export function getBookingsByDate(date: string): Booking[] {
  const bookings = getBookings()
  return bookings.filter((booking) => booking.date === date)
}

export function getBookingsByClient(clientId: string): Booking[] {
  const bookings = getBookings()
  return bookings.filter((booking) => booking.clientId === clientId)
}

export function addBooking(booking: Omit<Booking, "id">): Booking {
  const bookings = getBookings()
  const newBooking = { ...booking, id: generateId() }
  bookings.push(newBooking)
  localStorage.setItem("glamtrack_bookings", JSON.stringify(bookings))

  // Update revenue if booking is confirmed
  if (booking.status === "confirmed" || booking.status === "completed") {
    addRevenue({
      date: booking.date,
      amount: booking.price,
      source: booking.service,
    })
  }

  return newBooking
}

export function updateBooking(id: string, updates: Partial<Booking>): Booking | null {
  const bookings = getBookings()
  const index = bookings.findIndex((booking) => booking.id === id)
  if (index === -1) return null

  const oldBooking = bookings[index]
  bookings[index] = { ...oldBooking, ...updates }
  localStorage.setItem("glamtrack_bookings", JSON.stringify(bookings))

  // Update revenue if status changed
  if (updates.status && oldBooking.status !== updates.status) {
    if (updates.status === "cancelled" && (oldBooking.status === "confirmed" || oldBooking.status === "completed")) {
      // Remove revenue if booking was cancelled
      removeRevenueForBooking(oldBooking)
    } else if (
      (updates.status === "confirmed" || updates.status === "completed") &&
      oldBooking.status === "cancelled"
    ) {
      // Add revenue if booking was confirmed after being cancelled
      addRevenue({
        date: oldBooking.date,
        amount: oldBooking.price,
        source: oldBooking.service,
      })
    }
  }

  return bookings[index]
}

export function deleteBooking(id: string): boolean {
  const bookings = getBookings()
  const bookingToDelete = bookings.find((booking) => booking.id === id)
  if (!bookingToDelete) return false

  const filteredBookings = bookings.filter((booking) => booking.id !== id)
  localStorage.setItem("glamtrack_bookings", JSON.stringify(filteredBookings))

  // Remove revenue if booking was confirmed or completed
  if (bookingToDelete.status === "confirmed" || bookingToDelete.status === "completed") {
    removeRevenueForBooking(bookingToDelete)
  }

  return true
}

// Invoice operations
export function getInvoices(): Invoice[] {
  if (typeof window === "undefined") return []
  initializeDatabase()
  return JSON.parse(localStorage.getItem("glamtrack_invoices") || "[]")
}

export function getInvoice(id: string): Invoice | null {
  const invoices = getInvoices()
  return invoices.find((invoice) => invoice.id === id) || null
}

export function getInvoicesByClient(clientId: string): Invoice[] {
  const invoices = getInvoices()
  return invoices.filter((invoice) => invoice.clientId === clientId)
}

export function addInvoice(invoice: Omit<Invoice, "id">): Invoice {
  const invoices = getInvoices()
  const newInvoice = { ...invoice, id: generateId() }
  invoices.push(newInvoice)
  localStorage.setItem("glamtrack_invoices", JSON.stringify(invoices))

  // Add revenue if invoice is paid
  if (invoice.status === "paid") {
    const totalAmount = invoice.items.reduce((sum, item) => sum + item.price * item.quantity, 0)
    addRevenue({
      date: invoice.date,
      amount: totalAmount,
      source: "Invoice",
    })
  }

  return newInvoice
}

export function updateInvoice(id: string, updates: Partial<Invoice>): Invoice | null {
  const invoices = getInvoices()
  const index = invoices.findIndex((invoice) => invoice.id === id)
  if (index === -1) return null

  const oldInvoice = invoices[index]
  invoices[index] = { ...oldInvoice, ...updates }
  localStorage.setItem("glamtrack_invoices", JSON.stringify(invoices))

  // Update revenue if status changed to paid
  if (updates.status && oldInvoice.status !== "paid" && updates.status === "paid") {
    const totalAmount = oldInvoice.items.reduce((sum, item) => sum + item.price * item.quantity, 0)
    addRevenue({
      date: oldInvoice.date,
      amount: totalAmount,
      source: "Invoice",
    })
  }

  return invoices[index]
}

export function deleteInvoice(id: string): boolean {
  const invoices = getInvoices()
  const filteredInvoices = invoices.filter((invoice) => invoice.id !== id)
  if (filteredInvoices.length === invoices.length) return false

  localStorage.setItem("glamtrack_invoices", JSON.stringify(filteredInvoices))
  return true
}

// Revenue operations
export function getRevenue(): Revenue[] {
  if (typeof window === "undefined") return []
  initializeDatabase()
  return JSON.parse(localStorage.getItem("glamtrack_revenue") || "[]")
}

export function getRevenueByDate(date: string): Revenue[] {
  const revenue = getRevenue()
  return revenue.filter((r) => r.date === date)
}

export function getRevenueByDateRange(startDate: string, endDate: string): Revenue[] {
  const revenue = getRevenue()
  return revenue.filter((r) => r.date >= startDate && r.date <= endDate)
}

export function addRevenue(revenue: Revenue): void {
  const revenueData = getRevenue()

  // Check if there's already revenue for this date and source
  const existingIndex = revenueData.findIndex((r) => r.date === revenue.date && r.source === revenue.source)

  if (existingIndex !== -1) {
    // Update existing revenue
    revenueData[existingIndex].amount += revenue.amount
  } else {
    // Add new revenue entry
    revenueData.push(revenue)
  }

  localStorage.setItem("glamtrack_revenue", JSON.stringify(revenueData))
}

export function removeRevenueForBooking(booking: Booking): void {
  const revenueData = getRevenue()

  // Find revenue entry for this date and service
  const existingIndex = revenueData.findIndex((r) => r.date === booking.date && r.source === booking.service)

  if (existingIndex !== -1) {
    // Subtract booking price from revenue
    revenueData[existingIndex].amount -= booking.price

    // Remove entry if amount is zero or negative
    if (revenueData[existingIndex].amount <= 0) {
      revenueData.splice(existingIndex, 1)
    }

    localStorage.setItem("glamtrack_revenue", JSON.stringify(revenueData))
  }
}

export function getTotalRevenue(): number {
  const revenue = getRevenue()
  return revenue.reduce((sum, r) => sum + r.amount, 0)
}

export function getWeeklyRevenue(): number {
  const today = new Date()
  const oneWeekAgo = new Date()
  oneWeekAgo.setDate(today.getDate() - 7)

  const revenue = getRevenue()
  return revenue
    .filter((r) => {
      const date = new Date(r.date)
      return date >= oneWeekAgo && date <= today
    })
    .reduce((sum, r) => sum + r.amount, 0)
}

// Helper function to get client name by ID
export function getClientNameById(clientId: string): string {
  const client = getClient(clientId)
  return client ? client.name : "Unknown Client"
}

// Helper function to get client initials by ID
export function getClientInitialsById(clientId: string): string {
  const client = getClient(clientId)
  return client ? client.initials : "UC"
}

// Helper function to get client avatar by ID
export function getClientAvatarById(clientId: string): string {
  const client = getClient(clientId)
  return client ? client.avatar || "/placeholder.svg" : "/placeholder.svg"
}

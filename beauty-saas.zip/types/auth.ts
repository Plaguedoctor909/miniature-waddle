export type UserRole =
  | "wig_vendor"
  | "makeup_artist"
  | "nail_tech"
  | "hairstylist"
  | "skincare_spa"
  | "brow_lash_tech"
  | "bridal_glam"

export interface User {
  id: string
  username: string
  email: string
  role: UserRole
  name: string
  createdAt: Date
  updatedAt: Date
  lastLogin: Date | null
  isActive: boolean
  businessName?: string
  profileImage?: string
}

export interface UserCredentials {
  id: string
  userId: string
  passwordHash: string
  createdAt: Date
  updatedAt: Date
}

export interface RoleFeatures {
  role: UserRole
  label: string
  description: string
  icon: string
  primaryColor: string
  secondaryColor: string
  features: string[]
  specializedModules: string[]
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, Database, Loader2 } from "lucide-react"

export function DatabaseInitializer() {
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)

  const handleSeedDatabase = async () => {
    if (
      !confirm(
        "Are you sure you want to seed the database with sample products? This should only be done once on a fresh installation.",
      )
    ) {
      return
    }

    setIsLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/seed", {
        method: "POST",
      })

      const data = await response.json()

      setResult({
        success: response.ok,
        message: data.message,
      })
    } catch (error) {
      setResult({
        success: false,
        message: `An error occurred: ${error instanceof Error ? error.message : String(error)}`,
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="elegant-card">
      <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100 border-b border-pink-100">
        <CardTitle className="flex items-center gap-2 text-purple-dark">
          <Database className="h-5 w-5 text-purple" />
          Database Initialization
        </CardTitle>
        <CardDescription>Seed your database with sample products to get started quickly</CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <p className="text-sm text-gray-600 mb-4">
          This will populate your database with sample products across all categories. Use this feature only once when
          setting up your store.
        </p>

        {result && (
          <Alert
            variant={result.success ? "default" : "destructive"}
            className={`mb-4 ${result.success ? "bg-purple-100 border-purple" : ""}`}
          >
            {result.success ? (
              <CheckCircle2 className="h-4 w-4 text-purple-dark" />
            ) : (
              <AlertCircle className="h-4 w-4" />
            )}
            <AlertTitle>{result.success ? "Success" : "Error"}</AlertTitle>
            <AlertDescription>{result.message}</AlertDescription>
          </Alert>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={handleSeedDatabase} disabled={isLoading} className="elegant-button">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Seeding Database...
            </>
          ) : (
            "Seed Database with Sample Products"
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

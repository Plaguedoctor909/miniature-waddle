"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, ArrowLeft, Upload, ImageIcon, Loader2 } from "lucide-react"
import { upload } from "@vercel/blob/client"
import type { Product } from "@/lib/products"

interface ProductFormProps {
  product?: Product
  isEditing?: boolean
}

const categories = ["Kitchen", "Bedroom", "Clothing", "Women", "Men", "Boys", "Girls", "Accessories"]

const sections = ["Featured", "New Arrivals", "Best Sellers", "Trending", "Popular", "Sale"]

export function ProductForm({ product, isEditing = false }: ProductFormProps) {
  const router = useRouter()
  const [name, setName] = useState(product?.name || "")
  const [description, setDescription] = useState(product?.description || "")
  const [price, setPrice] = useState(product?.price || "")
  const [category, setCategory] = useState(product?.category || "")
  const [section, setSection] = useState(product?.section || "")
  const [featured, setFeatured] = useState(product?.featured || false)
  const [image, setImage] = useState(product?.image || "/placeholder.svg?height=500&width=500")
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      // Create a preview URL
      const previewUrl = URL.createObjectURL(file)
      setImage(previewUrl)
    }
  }

  // Update the handleSubmit function to better handle image upload failures
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setIsSubmitting(true)

    try {
      // Default to placeholder if no image is provided
      let finalImageUrl = image

      // Upload image if a new one is selected
      if (imageFile) {
        setIsUploading(true)
        try {
          // For development or when Blob upload might fail, use a fallback approach
          try {
            const newBlob = await upload(imageFile.name, imageFile, {
              access: "public",
              handleUploadUrl: "/api/upload",
            })
            finalImageUrl = newBlob.url
          } catch (uploadError) {
            console.error("Image upload error:", uploadError)

            // If we're editing a product and have an existing image, keep using it
            if (isEditing && product?.image && !product.image.includes("placeholder")) {
              finalImageUrl = product.image
              console.log("Keeping existing image:", finalImageUrl)
            } else {
              // Fall back to placeholder
              finalImageUrl = "/placeholder.svg?height=500&width=500"
              console.log("Using placeholder image due to upload failure")
            }
          }
        } finally {
          setIsUploading(false)
        }
      }

      const productData = {
        name,
        description,
        price,
        category,
        section,
        featured,
        image: finalImageUrl,
      }

      console.log("Submitting product data:", productData)

      const url = isEditing ? `/api/products/${product?.id}` : "/api/products"
      const method = isEditing ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(productData),
        cache: "no-store", // Ensure we don't use cached responses
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Failed to save product")
      }

      // Force revalidation of all pages that might display this product
      router.refresh()

      // Add a small delay to ensure the server has time to update
      await new Promise((resolve) => setTimeout(resolve, 300))

      // Successfully saved - redirect to products page
      router.push("/admin/products")
    } catch (err) {
      console.error("Form submission error:", err)
      setError(err instanceof Error ? err.message : "An error occurred while saving the product")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="max-w-2xl mx-auto elegant-card">
      <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100 border-b border-pink-100">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => router.push("/admin/products")}
            className="elegant-button-outline"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <CardTitle className="text-purple-dark">{isEditing ? "Edit Product" : "Add New Product"}</CardTitle>
        </div>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4 pt-6">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="name" className="text-purple-dark">
              Product Name
            </Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="elegant-input"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-purple-dark">
              Description
            </Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              required
              className="elegant-input"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="price" className="text-purple-dark">
              Price
            </Label>
            <Input
              id="price"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="$99.99"
              required
              className="elegant-input"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category" className="text-purple-dark">
                Category
              </Label>
              <Select value={category} onValueChange={setCategory} required>
                <SelectTrigger className="elegant-input">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="section" className="text-purple-dark">
                Section
              </Label>
              <Select value={section} onValueChange={setSection} required>
                <SelectTrigger className="elegant-input">
                  <SelectValue placeholder="Select section" />
                </SelectTrigger>
                <SelectContent>
                  {sections.map((sec) => (
                    <SelectItem key={sec} value={sec}>
                      {sec}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="featured"
              checked={featured}
              onCheckedChange={(checked) => setFeatured(checked as boolean)}
              className="border-purple data-[state=checked]:bg-purple data-[state=checked]:text-white"
            />
            <Label htmlFor="featured" className="text-purple-dark">
              Featured Product
            </Label>
          </div>

          <div className="space-y-2">
            <Label htmlFor="image" className="text-purple-dark">
              Product Image
            </Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="relative">
                  <Input
                    id="image"
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="elegant-input pl-9"
                  />
                  <ImageIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-purple" />
                </div>
                {!imageFile && product?.image && (
                  <div className="flex items-center gap-2 p-2 bg-pink-100/30 rounded-md border border-pink-100">
                    <span className="text-sm text-purple-dark">Current image:</span>
                    <span className="text-xs text-gray-500 truncate flex-1">{product.image}</span>
                  </div>
                )}
                {!isEditing && !imageFile && (
                  <p className="text-sm text-purple-dark">
                    {image === "/placeholder.svg?height=500&width=500"
                      ? "No image selected. A placeholder will be used."
                      : "Please upload a product image"}
                  </p>
                )}

                {/* Gold accent for premium products */}
                {featured && (
                  <div className="mt-2 p-1.5 rounded-md bg-gradient-to-r from-gold-light/20 to-nude-light/20 border border-gold/20">
                    <p className="text-xs text-gold-dark">Featured products should have high-quality images</p>
                  </div>
                )}
              </div>
              {image && (
                <div className="relative aspect-square w-full max-w-[200px] overflow-hidden rounded-md border border-pink-100">
                  <img src={image || "/placeholder.svg"} alt="Product preview" className="object-cover w-full h-full" />
                  {image.includes("/placeholder.svg") && (
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                      <span className="text-white text-xs font-medium">Placeholder</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t border-pink-100 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => router.push("/admin/products")}
            className="elegant-button-outline"
          >
            Cancel
          </Button>
          <Button type="submit" className="elegant-button" disabled={isSubmitting || isUploading}>
            {isSubmitting || isUploading ? (
              isUploading ? (
                <>
                  <Upload className="mr-2 h-4 w-4 animate-spin" /> Uploading Image...
                </>
              ) : (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...
                </>
              )
            ) : isEditing ? (
              "Update Product"
            ) : (
              "Add Product"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

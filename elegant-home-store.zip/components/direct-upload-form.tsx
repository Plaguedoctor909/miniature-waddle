"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function DirectUploadForm() {
  const [imageUrl, setImageUrl] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!imageUrl) {
      setError("Please enter an image URL")
      return
    }

    // Copy the URL to clipboard
    navigator.clipboard
      .writeText(imageUrl)
      .then(() => {
        setSuccess(true)
        setTimeout(() => setSuccess(false), 3000)
      })
      .catch(() => {
        setError("Failed to copy URL to clipboard")
      })
  }

  return (
    <Card className="elegant-card">
      <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100 border-b border-pink-100">
        <CardTitle className="text-purple-dark">Direct Image URL</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="pt-6 space-y-4">
          <p className="text-sm text-purple-dark">
            Enter an image URL to use for your product if direct upload isn't working.
          </p>

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="bg-green-50 border-green-200 text-green-700">
              <AlertDescription>URL copied to clipboard!</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="imageUrl" className="text-purple-dark">
              Image URL
            </Label>
            <Input
              id="imageUrl"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://example.com/image.jpg"
              className="elegant-input"
            />
          </div>
        </CardContent>
        <CardFooter className="border-t border-pink-100 pt-4">
          <Button type="submit" className="elegant-button">
            Copy URL to Clipboard
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

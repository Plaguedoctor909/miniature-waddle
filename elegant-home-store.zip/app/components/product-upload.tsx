"use client"

import type React from "react"

import { useState } from "react"
import { upload } from "@vercel/blob/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function ProductImageUpload() {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [uploadedUrl, setUploadedUrl] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!file) return

    setUploading(true)
    try {
      const newBlob = await upload(file.name, file, {
        access: "public",
        handleUploadUrl: "/api/upload",
      })

      setUploadedUrl(newBlob.url)
    } catch (error) {
      console.error("Error uploading file:", error)
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="p-6 border rounded-lg bg-white">
      <h2 className="text-xl font-bold mb-4 text-primary">Product Image Upload</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="file">Select Product Image</Label>
          <Input id="file" type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
        </div>

        <Button type="submit" disabled={!file || uploading} className="bg-primary hover:bg-primary/90">
          {uploading ? "Uploading..." : "Upload Image"}
        </Button>
      </form>

      {uploadedUrl && (
        <div className="mt-6 space-y-4">
          <h3 className="font-medium">Uploaded Image URL:</h3>
          <div className="p-2 bg-gray-50 rounded border break-all">
            <code className="text-sm">{uploadedUrl}</code>
          </div>
          <div className="border rounded-md overflow-hidden">
            <img src={uploadedUrl || "/placeholder.svg"} alt="Uploaded product" className="w-full h-auto" />
          </div>
        </div>
      )}
    </div>
  )
}

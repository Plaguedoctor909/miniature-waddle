import Link from "next/link"
import Image from "next/image"
import { ChevronRight, Filter, SlidersHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { getCategoryProducts } from "@/lib/category-utils"

export default async function WomenPage() {
  const womenProducts = await getCategoryProducts("Women")

  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex items-center px-4 py-6 md:px-6 border-b">
        <nav className="flex items-center space-x-2 text-sm">
          <Link href="/" className="text-gray-500 hover:text-primary">
            Home
          </Link>
          <ChevronRight className="h-4 w-4 text-gray-500" />
          <span className="font-medium text-primary">Women/Girls</span>
        </nav>
      </div>
      <div className="grid md:grid-cols-5 gap-6 p-4 md:p-6">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" className="flex items-center gap-2 md:hidden">
              <Filter className="h-4 w-4" />
              Filters
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-full sm:max-w-sm">
            <div className="grid gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Categories</h3>
                <div className="grid gap-2">
                  {womenCategories.map((category) => (
                    <div key={category} className="flex items-center gap-2">
                      <Checkbox id={`category-${category}`} />
                      <label htmlFor={`category-${category}`} className="text-sm">
                        {category}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Age Group</h3>
                <div className="grid gap-2">
                  {ageGroups.map((age) => (
                    <div key={age} className="flex items-center gap-2">
                      <Checkbox id={`age-${age}`} />
                      <label htmlFor={`age-${age}`} className="text-sm">
                        {age}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Size</h3>
                <div className="grid grid-cols-4 gap-2">
                  {womenSizes.map((size) => (
                    <div key={size} className="flex items-center justify-center">
                      <label
                        htmlFor={`size-${size}`}
                        className="flex h-10 w-10 items-center justify-center rounded-md border text-sm cursor-pointer hover:bg-primary hover:text-white"
                      >
                        <input type="checkbox" id={`size-${size}`} className="sr-only" />
                        {size}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </SheetContent>
        </Sheet>
        <div className="hidden md:block space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Categories</h3>
            <div className="grid gap-2">
              {womenCategories.map((category) => (
                <div key={category} className="flex items-center gap-2">
                  <Checkbox id={`desktop-category-${category}`} />
                  <label htmlFor={`desktop-category-${category}`} className="text-sm">
                    {category}
                  </label>
                </div>
              ))}
            </div>
          </div>
          <Separator />
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Age Group</h3>
            <div className="grid gap-2">
              {ageGroups.map((age) => (
                <div key={age} className="flex items-center gap-2">
                  <Checkbox id={`desktop-age-${age}`} />
                  <label htmlFor={`desktop-age-${age}`} className="text-sm">
                    {age}
                  </label>
                </div>
              ))}
            </div>
          </div>
          <Separator />
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Size</h3>
            <div className="grid grid-cols-4 gap-2">
              {womenSizes.map((size) => (
                <div key={size} className="flex items-center justify-center">
                  <label
                    htmlFor={`desktop-size-${size}`}
                    className="flex h-10 w-10 items-center justify-center rounded-md border text-sm cursor-pointer hover:bg-primary hover:text-white"
                  >
                    <input type="checkbox" id={`desktop-size-${size}`} className="sr-only" />
                    {size}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="md:col-span-4 space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold tracking-tight">Women & Girls</h1>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="hidden md:flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" />
                Sort
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {womenProducts.length > 0 ? (
              womenProducts.map((product) => (
                <Card key={product.id} className="overflow-hidden">
                  <div className="relative aspect-square">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      fill
                      className="object-cover transition-transform hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-4">
                    <div className="space-y-1">
                      <h3 className="font-medium">{product.name}</h3>
                      <p className="text-sm text-gray-500">{product.category}</p>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-primary">{product.price}</span>
                        <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs">
                          Add to Cart
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-gray-500">No women's products found.</p>
                <p className="text-sm text-gray-400 mt-2">Add products from the admin dashboard.</p>
              </div>
            )}
          </div>
          {womenProducts.length > 0 && (
            <div className="flex justify-center">
              <Button variant="outline" className="w-full sm:w-auto">
                Load More
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

const womenCategories = ["Dresses", "Tops", "Bottoms", "Outerwear", "Activewear", "Accessories", "Footwear"]

const ageGroups = ["Women", "Teens", "Girls 7-12", "Girls 2-6"]

const womenSizes = ["XS", "S", "M", "L", "XL", "XXL", "4", "6", "8", "10", "12", "14"]

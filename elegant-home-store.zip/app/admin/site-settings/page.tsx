"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft } from "lucide-react"

export default function SiteSettingsPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)

  // In a  {

  // In a real application, you would fetch these settings from your database
  const [heroTitle, setHeroTitle] = useState("Elegant Living, Stylish Fashion")
  const [heroDescription, setHeroDescription] = useState(
    "Discover our curated collection of home essentials and fashion for the whole family.",
  )
  const [featuredTitle, setFeaturedTitle] = useState("Featured Products")
  const [featuredDescription, setFeaturedDescription] = useState("Our most popular items across all categories")

  const handleSaveSettings = async () => {
    setIsSubmitting(true)

    // In a real application, you would save these settings to your database
    // For now, we'll just simulate a delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsSubmitting(false)
    router.refresh()
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.push("/admin/dashboard")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold text-primary">Site Content Management</h1>
      </div>

      <Tabs defaultValue="homepage">
        <TabsList className="mb-4">
          <TabsTrigger value="homepage">Homepage</TabsTrigger>
          <TabsTrigger value="categories">Category Pages</TabsTrigger>
          <TabsTrigger value="footer">Footer</TabsTrigger>
        </TabsList>

        <TabsContent value="homepage">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Hero Section</CardTitle>
                <CardDescription>Edit the main hero section content</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="heroTitle">Hero Title</Label>
                  <Input id="heroTitle" value={heroTitle} onChange={(e) => setHeroTitle(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="heroDescription">Hero Description</Label>
                  <Textarea
                    id="heroDescription"
                    value={heroDescription}
                    onChange={(e) => setHeroDescription(e.target.value)}
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Featured Products Section</CardTitle>
                <CardDescription>Edit the featured products section content</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="featuredTitle">Section Title</Label>
                  <Input id="featuredTitle" value={featuredTitle} onChange={(e) => setFeaturedTitle(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="featuredDescription">Section Description</Label>
                  <Textarea
                    id="featuredDescription"
                    value={featuredDescription}
                    onChange={(e) => setFeaturedDescription(e.target.value)}
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="categories">
          <Card>
            <CardHeader>
              <CardTitle>Category Pages</CardTitle>
              <CardDescription>Edit category page content and settings</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500">
                Category pages are dynamically generated based on your products. Add products to specific categories to
                populate these pages.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="footer">
          <Card>
            <CardHeader>
              <CardTitle>Footer Content</CardTitle>
              <CardDescription>Edit footer links and information</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500">Footer content management will be available in a future update.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-6 flex justify-end">
        <Button onClick={handleSaveSettings} className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
          {isSubmitting ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </div>
  )
}

"use client"

import type React from "react"
import { Inter } from "next/font/google"
import { usePathname } from "next/navigation"
import Link from "next/link"
import "../globals.css"
import { LayoutDashboard, Package, Upload, ShoppingBag, Users, Settings, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"

const inter = Inter({ subsets: ["latin"] })

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path || pathname.startsWith(`${path}/`)
  }

  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="flex min-h-screen">
          {/* Admin Sidebar */}
          <div className="hidden md:flex flex-col w-64 bg-gray-50 border-r">
            <div className="p-4 border-b">
              <Link href="/admin/dashboard">
                <h1 className="text-xl font-bold text-primary">Admin Panel</h1>
              </Link>
            </div>
            <nav className="flex-1 p-4 space-y-1">
              <Link href="/admin/dashboard">
                <Button variant={isActive("/admin/dashboard") ? "secondary" : "ghost"} className="w-full justify-start">
                  <LayoutDashboard className="mr-2 h-4 w-4" />
                  Dashboard
                </Button>
              </Link>
              <Link href="/admin/products">
                <Button variant={isActive("/admin/products") ? "secondary" : "ghost"} className="w-full justify-start">
                  <Package className="mr-2 h-4 w-4" />
                  Products
                </Button>
              </Link>
              <Link href="/admin/upload">
                <Button variant={isActive("/admin/upload") ? "secondary" : "ghost"} className="w-full justify-start">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Images
                </Button>
              </Link>
              <Link href="/admin/orders">
                <Button variant={isActive("/admin/orders") ? "secondary" : "ghost"} className="w-full justify-start">
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Orders
                </Button>
              </Link>
              <Link href="/admin/customers">
                <Button variant={isActive("/admin/customers") ? "secondary" : "ghost"} className="w-full justify-start">
                  <Users className="mr-2 h-4 w-4" />
                  Customers
                </Button>
              </Link>
              <Link href="/admin/site-settings">
                <Button
                  variant={isActive("/admin/site-settings") ? "secondary" : "ghost"}
                  className="w-full justify-start"
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Site Settings
                </Button>
              </Link>
            </nav>
            <div className="p-4 border-t">
              <Link href="/">
                <Button variant="outline" className="w-full justify-start">
                  <LogOut className="mr-2 h-4 w-4" />
                  Back to Store
                </Button>
              </Link>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 flex flex-col">{children}</div>
        </div>
      </body>
    </html>
  )
}

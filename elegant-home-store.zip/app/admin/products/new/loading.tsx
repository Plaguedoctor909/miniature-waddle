import { Loader2 } from "lucide-react"

export default function Loading() {
  return (
    <div className="container mx-auto p-6 flex justify-center items-center h-[50vh]">
      <div className="flex items-center gap-2">
        <Loader2 className="h-6 w-6 animate-spin text-purple" />
        <p className="text-purple-dark">Loading form...</p>
      </div>
    </div>
  )
}

import { ProductForm } from "@/components/product-form"

export default function NewProductPage() {
  return (
    <div className="container mx-auto p-6">
      <ProductForm />
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, AlertCircle, CheckCircle2, Loader2, Upload, Search, Filter } from "lucide-react"
import { upload } from "@vercel/blob/client"
import type { Product } from "@/lib/products"

export default function BulkEditProductsPage() {
  const router = useRouter()
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedProducts, setSelectedProducts] = useState<Set<string>>(new Set())
  const [isUploading, setIsUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<{
    success: boolean
    message: string
  } | null>(null)
  const [activeTab, setActiveTab] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  // Fetch all products
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch("/api/products", {
          cache: "no-store",
          headers: {
            "Cache-Control": "no-cache",
            Pragma: "no-cache",
          },
        })
        if (response.ok) {
          const data = await response.json()
          setProducts(data)
          setFilteredProducts(data)
        } else {
          console.error("Failed to fetch products")
        }
      } catch (error) {
        console.error("Error fetching products:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchProducts()
  }, [])

  // Filter products based on search term and active tab
  useEffect(() => {
    let filtered = products

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.section.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filter by tab
    if (activeTab === "placeholder") {
      filtered = filtered.filter((product) => product.image.includes("/placeholder.svg"))
    } else if (activeTab === "category" && selectedCategory) {
      filtered = filtered.filter((product) => product.category === selectedCategory)
    }

    setFilteredProducts(filtered)
  }, [searchTerm, products, activeTab, selectedCategory])

  // Get unique categories
  const categories = [...new Set(products.map((product) => product.category))].sort()

  // Toggle product selection
  const toggleProductSelection = (productId: string) => {
    const newSelected = new Set(selectedProducts)
    if (newSelected.has(productId)) {
      newSelected.delete(productId)
    } else {
      newSelected.add(productId)
    }
    setSelectedProducts(newSelected)
  }

  // Select all visible products
  const selectAllVisible = () => {
    const allIds = filteredProducts.map((product) => product.id)
    const newSelected = new Set(selectedProducts)

    // Check if all visible products are already selected
    const allSelected = allIds.every((id) => newSelected.has(id))

    if (allSelected) {
      // Deselect all visible products
      allIds.forEach((id) => newSelected.delete(id))
    } else {
      // Select all visible products
      allIds.forEach((id) => newSelected.add(id))
    }

    setSelectedProducts(newSelected)
  }

  // Handle image upload for a single product
  const handleSingleImageUpload = async (productId: string, file: File) => {
    try {
      setIsUploading(true)

      // Upload image to Vercel Blob
      const newBlob = await upload(file.name, file, {
        access: "public",
        handleUploadUrl: "/api/upload",
      })

      // Update product with new image URL
      const response = await fetch(`/api/products/${productId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ image: newBlob.url }),
      })

      if (!response.ok) {
        throw new Error("Failed to update product image")
      }

      // Update local state
      setProducts((prevProducts) =>
        prevProducts.map((product) => (product.id === productId ? { ...product, image: newBlob.url } : product)),
      )

      setUploadStatus({
        success: true,
        message: "Image uploaded successfully",
      })

      return true
    } catch (error) {
      console.error("Error uploading image:", error)
      setUploadStatus({
        success: false,
        message: `Error uploading image: ${error instanceof Error ? error.message : String(error)}`,
      })
      return false
    } finally {
      setIsUploading(false)
    }
  }

  // Handle bulk edit of selected products
  const handleBulkEdit = async (field: string, value: any) => {
    if (selectedProducts.size === 0) {
      setUploadStatus({
        success: false,
        message: "No products selected",
      })
      return
    }

    setIsUploading(true)
    setUploadStatus(null)

    try {
      let successCount = 0
      let failCount = 0

      // Update each selected product
      for (const productId of selectedProducts) {
        const response = await fetch(`/api/products/${productId}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache",
          },
          body: JSON.stringify({ [field]: value }),
        })

        if (response.ok) {
          successCount++
        } else {
          failCount++
        }
      }

      // Refresh product list with fresh data
      const response = await fetch("/api/products", {
        cache: "no-store",
        headers: {
          "Cache-Control": "no-cache",
          Pragma: "no-cache",
        },
      })

      if (response.ok) {
        const data = await response.json()
        setProducts(data)

        // Also update filtered products based on current filters
        let filtered = data

        // Apply current filters
        if (searchTerm) {
          filtered = filtered.filter(
            (product) =>
              product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
              product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
              product.section.toLowerCase().includes(searchTerm.toLowerCase()),
          )
        }

        if (activeTab === "placeholder") {
          filtered = filtered.filter((product) => product.image.includes("/placeholder.svg"))
        } else if (activeTab === "category" && selectedCategory) {
          filtered = filtered.filter((product) => product.category === selectedCategory)
        }

        setFilteredProducts(filtered)
      }

      setUploadStatus({
        success: successCount > 0,
        message: `Updated ${successCount} products${failCount > 0 ? `, failed to update ${failCount} products` : ""}`,
      })

      // Clear selection if all successful
      if (failCount === 0) {
        setSelectedProducts(new Set())
      }

      // Force revalidation of all pages
      router.refresh()
    } catch (error) {
      setUploadStatus({
        success: false,
        message: `Error updating products: ${error instanceof Error ? error.message : String(error)}`,
      })
    } finally {
      setIsUploading(false)
    }
  }

  const placeholderCount = products.filter((p) => p.image.includes("/placeholder.svg")).length

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          size="icon"
          onClick={() => router.push("/admin/products")}
          className="elegant-button-outline"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold text-purple-dark">Product Editor</h1>
      </div>

      {uploadStatus && (
        <Alert
          variant={uploadStatus.success ? "default" : "destructive"}
          className={`mb-6 ${uploadStatus.success ? "bg-purple-100 border-purple" : ""}`}
        >
          {uploadStatus.success ? (
            <CheckCircle2 className="h-4 w-4 text-purple-dark" />
          ) : (
            <AlertCircle className="h-4 w-4" />
          )}
          <AlertTitle>{uploadStatus.success ? "Success" : "Error"}</AlertTitle>
          <AlertDescription>{uploadStatus.message}</AlertDescription>
        </Alert>
      )}

      <Card className="mb-6 elegant-card">
        <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100 border-b border-pink-100">
          <CardTitle className="text-lg text-purple-dark flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filter Products
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 elegant-input"
              />
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full md:w-auto">
              <TabsList className="bg-pink-100">
                <TabsTrigger value="all" className="data-[state=active]:bg-purple data-[state=active]:text-white">
                  All Products
                </TabsTrigger>
                <TabsTrigger
                  value="placeholder"
                  className="data-[state=active]:bg-purple data-[state=active]:text-white"
                >
                  Placeholders {placeholderCount > 0 && `(${placeholderCount})`}
                </TabsTrigger>
                <TabsTrigger value="category" className="data-[state=active]:bg-purple data-[state=active]:text-white">
                  By Category
                </TabsTrigger>
              </TabsList>
            </Tabs>
            {activeTab === "category" && (
              <div className="w-full md:w-64">
                <select
                  className="w-full h-10 px-3 rounded-md border border-input bg-background elegant-input"
                  value={selectedCategory || ""}
                  onChange={(e) => setSelectedCategory(e.target.value || null)}
                >
                  <option value="">Select Category</option>
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="elegant-card">
        <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100 border-b border-pink-100">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg text-purple-dark">Products ({filteredProducts.length})</CardTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={selectAllVisible}
                disabled={filteredProducts.length === 0}
                className="elegant-button-outline text-xs"
              >
                {filteredProducts.every((p) => selectedProducts.has(p.id)) ? "Deselect All" : "Select All"}
              </Button>
              <Button
                variant="default"
                size="sm"
                onClick={() => router.push("/admin/products/new")}
                className="elegant-button text-xs"
              >
                Add New Product
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-6 w-6 text-purple animate-spin mr-2" />
              <p>Loading products...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No products found</p>
              {products.length > 0 && searchTerm && (
                <p className="text-sm text-gray-400 mt-2">Try adjusting your search term</p>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-pink-100/50">
                    <TableHead className="w-12">
                      <span className="sr-only">Select</span>
                    </TableHead>
                    <TableHead className="w-16">Image</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Section</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map((product) => (
                    <TableRow key={product.id} className="hover:bg-pink-100/20">
                      <TableCell>
                        <Checkbox
                          checked={selectedProducts.has(product.id)}
                          onCheckedChange={() => toggleProductSelection(product.id)}
                          className="border-purple data-[state=checked]:bg-purple data-[state=checked]:text-white"
                        />
                      </TableCell>
                      <TableCell>
                        <div className="w-12 h-12 relative overflow-hidden rounded-md border border-pink-100">
                          <img
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            className="object-cover w-full h-full"
                          />
                          {product.image.includes("/placeholder.svg") && (
                            <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                              <span className="text-white text-xs font-medium">Placeholder</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{product.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-pink-100/50 text-purple-dark border-pink-100">
                          {product.category}
                        </Badge>
                      </TableCell>
                      <TableCell>{product.section}</TableCell>
                      <TableCell className="font-medium text-purple-dark">{product.price}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => router.push(`/admin/products/edit/${product.id}`)}
                            className="elegant-button-outline text-xs"
                          >
                            Edit
                          </Button>
                          <div className="relative">
                            <Input
                              type="file"
                              accept="image/*"
                              className="absolute inset-0 opacity-0 cursor-pointer"
                              onChange={async (e) => {
                                const file = e.target.files?.[0]
                                if (file) {
                                  await handleSingleImageUpload(product.id, file)
                                }
                              }}
                            />
                            <Button variant="outline" size="sm" className="elegant-button-outline text-xs">
                              <Upload className="h-3 w-3 mr-1" />
                              Image
                            </Button>
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {selectedProducts.size > 0 && (
            <div className="m-4 p-4 border rounded-md bg-purple-100/20 border-purple-100">
              <h3 className="font-medium mb-2 text-purple-dark">
                Bulk Actions ({selectedProducts.size} products selected)
              </h3>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkEdit("featured", true)}
                  disabled={isUploading}
                  className="elegant-button-outline text-xs"
                >
                  Mark as Featured
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkEdit("featured", false)}
                  disabled={isUploading}
                  className="elegant-button-outline text-xs"
                >
                  Remove Featured
                </Button>
                <div className="flex items-center gap-2">
                  <select
                    className="h-8 rounded-md border border-input bg-background px-3 text-xs elegant-input"
                    onChange={(e) => {
                      if (e.target.value) {
                        handleBulkEdit("section", e.target.value)
                      }
                    }}
                    disabled={isUploading}
                  >
                    <option value="">Change Section...</option>
                    <option value="Featured">Featured</option>
                    <option value="New Arrivals">New Arrivals</option>
                    <option value="Best Sellers">Best Sellers</option>
                    <option value="Trending">Trending</option>
                    <option value="Popular">Popular</option>
                    <option value="Sale">Sale</option>
                  </select>
                </div>
                {isUploading && (
                  <div className="flex items-center">
                    <Loader2 className="h-4 w-4 animate-spin mr-2 text-purple" />
                    <span className="text-sm text-purple-dark">Processing...</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

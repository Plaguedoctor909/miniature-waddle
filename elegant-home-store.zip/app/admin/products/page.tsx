"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Pencil, Trash2, Plus, ArrowLeft, Search } from "lucide-react"
import type { Product } from "@/lib/products"

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const router = useRouter()

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setIsLoading(true)
        const response = await fetch("/api/products", {
          cache: "no-store",
          headers: {
            "Cache-Control": "no-cache",
            Pragma: "no-cache",
          },
        })
        if (response.ok) {
          const data = await response.json()
          setProducts(data)
        } else {
          console.error("Failed to fetch products")
        }
      } catch (error) {
        console.error("Error fetching products:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchProducts()

    // Listen for route changes to refresh data
    const handleRouteChange = () => {
      fetchProducts()
    }

    router.events?.on("routeChangeComplete", handleRouteChange)

    return () => {
      router.events?.off("routeChangeComplete", handleRouteChange)
    }
  }, [router])

  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Are you sure you want to delete this product?")) {
      return
    }

    try {
      const response = await fetch(`/api/products/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setProducts(products.filter((product) => product.id !== id))
      } else {
        console.error("Failed to delete product")
      }
    } catch (error) {
      console.error("Error deleting product:", error)
    }
  }

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.section.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const placeholderCount = products.filter((p) => p.image.includes("/placeholder.svg")).length

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => router.push("/admin/dashboard")}
            className="elegant-button-outline"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold text-purple-dark">Product Management</h1>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => router.push("/admin/products/bulk-edit")}
            className="elegant-button-outline"
          >
            Bulk Edit {placeholderCount > 0 && <Badge className="ml-2 bg-purple text-white">{placeholderCount}</Badge>}
          </Button>
          <Button onClick={() => router.push("/admin/products/new")} className="elegant-button">
            <Plus className="mr-2 h-4 w-4" /> Add Product
          </Button>
        </div>
      </div>

      <Card className="elegant-card">
        <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100 border-b border-pink-100">
          <CardTitle className="text-purple-dark">Products</CardTitle>
          <CardDescription>Manage your store's product catalog</CardDescription>
          <div className="mt-4 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm pl-9 elegant-input"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-spin h-6 w-6 border-2 border-purple border-t-transparent rounded-full mr-2"></div>
              <p>Loading products...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No products found</p>
              {products.length > 0 && searchTerm && (
                <p className="text-sm text-gray-400 mt-2">Try adjusting your search term</p>
              )}
              {products.length === 0 && (
                <Button onClick={() => router.push("/admin/products/new")} variant="link" className="mt-2 text-purple">
                  Add your first product
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-pink-100/50">
                    <TableHead className="w-16">Image</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Section</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map((product) => (
                    <TableRow key={product.id} className="hover:bg-pink-100/20">
                      <TableCell>
                        <div className="w-12 h-12 relative overflow-hidden rounded-md border border-pink-100">
                          <img
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            className="object-cover w-full h-full"
                          />
                          {product.image.includes("/placeholder.svg") && (
                            <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                              <span className="text-white text-xs font-medium">Placeholder</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{product.name}</TableCell>
                      <TableCell className="font-medium text-purple-dark">{product.price}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-pink-100/50 text-purple-dark border-pink-100">
                          {product.category}
                        </Badge>
                      </TableCell>
                      <TableCell>{product.section}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => router.push(`/admin/products/edit/${product.id}`)}
                            className="elegant-button-outline"
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600"
                            onClick={() => handleDeleteProduct(product.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

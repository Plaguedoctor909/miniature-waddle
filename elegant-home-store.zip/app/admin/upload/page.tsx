import ProductImageUpload from "@/app/components/product-upload"
import { DirectUploadForm } from "@/components/direct-upload-form"

export default function UploadPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Product Image Management</h1>
      <div className="grid md:grid-cols-2 gap-6">
        <ProductImageUpload />
        <DirectUploadForm />
      </div>
    </div>
  )
}

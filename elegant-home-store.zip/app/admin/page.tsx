"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function AdminLoginPage() {
  const router = useRouter()

  // Immediately redirect to dashboard without any authentication
  useEffect(() => {
    router.push("/admin/dashboard")
  }, [router])

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-r from-purple-50 to-pink-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center text-primary">Admin Access</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-6">Redirecting to admin dashboard...</CardContent>
      </Card>
    </div>
  )
}

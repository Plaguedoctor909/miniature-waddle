import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, ShoppingBag, Settings, Users, LayoutDashboard, Package, ImageIcon } from "lucide-react"
import { DatabaseInitializer } from "@/components/database-initializer"
import { getProducts } from "@/lib/products"
import { Badge } from "@/components/ui/badge"

export default async function AdminDashboard() {
  const products = await getProducts()
  const hasProducts = products.length > 0
  const placeholderCount = products.filter((p) => p.image.includes("/placeholder.svg")).length

  return (
    <div className="min-h-screen bg-gradient-to-r from-purple-50 to-pink-50">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-purple-dark">Admin Dashboard</h1>
          <Link href="/">
            <Button variant="outline" className="elegant-button-outline">
              Back to Store
            </Button>
          </Link>
        </div>

        {!hasProducts && (
          <div className="mb-8">
            <DatabaseInitializer />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link href="/admin/products">
            <Card className="elegant-card h-full">
              <CardHeader className="pb-2 bg-gradient-to-r from-purple-100 to-pink-100">
                <CardTitle className="text-lg flex items-center gap-2 text-purple-dark">
                  <Package className="h-5 w-5 text-purple" />
                  Products
                </CardTitle>
                <CardDescription>Manage your product catalog</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600">Add, edit, and remove products</p>
                {hasProducts && <p className="text-xs text-purple-dark mt-1">{products.length} products in database</p>}
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/products/bulk-edit">
            <Card className="elegant-card h-full">
              <CardHeader className="pb-2 bg-gradient-to-r from-purple-100 to-pink-100">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg flex items-center gap-2 text-purple-dark">
                    <ImageIcon className="h-5 w-5 text-purple" />
                    Replace Placeholders
                  </CardTitle>
                  {placeholderCount > 0 && <Badge className="bg-purple text-white">{placeholderCount}</Badge>}
                </div>
                <CardDescription>Update placeholder images</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600">Replace placeholder images with real product photos</p>
                {hasProducts && placeholderCount > 0 && (
                  <p className="text-xs text-purple-dark mt-1">{placeholderCount} products using placeholders</p>
                )}
                {/* Gold accent for special emphasis */}
                {placeholderCount > 5 && (
                  <div className="mt-2 p-1.5 rounded-md bg-gradient-to-r from-gold-light/20 to-nude-light/20 border border-gold/20">
                    <p className="text-xs text-gold-dark">High number of placeholders - consider updating</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/upload">
            <Card className="elegant-card h-full">
              <CardHeader className="pb-2 bg-gradient-to-r from-purple-100 to-pink-100">
                <CardTitle className="text-lg flex items-center gap-2 text-purple-dark">
                  <Upload className="h-5 w-5 text-purple" />
                  Product Images
                </CardTitle>
                <CardDescription>Upload and manage product images</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600">Use Vercel Blob to store product images</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/orders">
            <Card className="elegant-card h-full">
              <CardHeader className="pb-2 bg-gradient-to-r from-purple-100 to-pink-100">
                <CardTitle className="text-lg flex items-center gap-2 text-purple-dark">
                  <ShoppingBag className="h-5 w-5 text-purple" />
                  Orders
                </CardTitle>
                <CardDescription>Manage customer orders</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600">View and process customer orders</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/customers">
            <Card className="elegant-card h-full">
              <CardHeader className="pb-2 bg-gradient-to-r from-purple-100 to-pink-100">
                <CardTitle className="text-lg flex items-center gap-2 text-purple-dark">
                  <Users className="h-5 w-5 text-purple" />
                  Customers
                </CardTitle>
                <CardDescription>View customer information</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600">Manage customer accounts and orders</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/site-settings">
            <Card className="elegant-card h-full">
              <CardHeader className="pb-2 bg-gradient-to-r from-purple-100 to-pink-100">
                <CardTitle className="text-lg flex items-center gap-2 text-purple-dark">
                  <LayoutDashboard className="h-5 w-5 text-purple" />
                  Site Content
                </CardTitle>
                <CardDescription>Manage site content and layout</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600">Edit homepage sections and category pages</p>
                {/* Nude accent for subtle emphasis */}
                <div className="mt-2 p-1.5 rounded-md bg-nude-light/20 border border-nude/20">
                  <p className="text-xs text-nude-dark">Update your site content for better engagement</p>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/settings">
            <Card className="elegant-card h-full">
              <CardHeader className="pb-2 bg-gradient-to-r from-purple-100 to-pink-100">
                <CardTitle className="text-lg flex items-center gap-2 text-purple-dark">
                  <Settings className="h-5 w-5 text-purple" />
                  Settings
                </CardTitle>
                <CardDescription>Configure store settings</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600">Update store information and preferences</p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  )
}

import Link from "next/link"
import Image from "next/image"
import { ChevronRight, Filter, SlidersHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { getCategoryProducts } from "@/lib/category-utils"

export default async function BedroomPage() {
  const bedroomProducts = await getCategoryProducts("Bedroom")

  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex items-center px-4 py-6 md:px-6 border-b">
        <nav className="flex items-center space-x-2 text-sm">
          <Link href="/" className="text-gray-500 hover:text-primary">
            Home
          </Link>
          <ChevronRight className="h-4 w-4 text-gray-500" />
          <span className="font-medium text-primary">Bedroom</span>
        </nav>
      </div>
      <div className="grid md:grid-cols-5 gap-6 p-4 md:p-6">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" className="flex items-center gap-2 md:hidden">
              <Filter className="h-4 w-4" />
              Filters
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-full sm:max-w-sm">
            <div className="grid gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Categories</h3>
                <div className="grid gap-2">
                  {bedroomCategories.map((category) => (
                    <div key={category} className="flex items-center gap-2">
                      <Checkbox id={`category-${category}`} />
                      <label htmlFor={`category-${category}`} className="text-sm">
                        {category}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Price Range</h3>
                <div className="grid gap-2">
                  <div className="flex items-center gap-2">
                    <Checkbox id="price-under-50" />
                    <label htmlFor="price-under-50" className="text-sm">
                      Under $50
                    </label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="price-50-100" />
                    <label htmlFor="price-50-100" className="text-sm">
                      $50 - $100
                    </label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="price-100-200" />
                    <label htmlFor="price-100-200" className="text-sm">
                      $100 - $200
                    </label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="price-over-200" />
                    <label htmlFor="price-over-200" className="text-sm">
                      Over $200
                    </label>
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Materials</h3>
                <div className="grid gap-2">
                  {materials.map((material) => (
                    <div key={material} className="flex items-center gap-2">
                      <Checkbox id={`material-${material}`} />
                      <label htmlFor={`material-${material}`} className="text-sm">
                        {material}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </SheetContent>
        </Sheet>
        <div className="hidden md:block space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Categories</h3>
            <div className="grid gap-2">
              {bedroomCategories.map((category) => (
                <div key={category} className="flex items-center gap-2">
                  <Checkbox id={`desktop-category-${category}`} />
                  <label htmlFor={`desktop-category-${category}`} className="text-sm">
                    {category}
                  </label>
                </div>
              ))}
            </div>
          </div>
          <Separator />
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Price Range</h3>
            <div className="grid gap-2">
              <div className="flex items-center gap-2">
                <Checkbox id="desktop-price-under-50" />
                <label htmlFor="desktop-price-under-50" className="text-sm">
                  Under $50
                </label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox id="desktop-price-50-100" />
                <label htmlFor="desktop-price-50-100" className="text-sm">
                  $50 - $100
                </label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox id="desktop-price-100-200" />
                <label htmlFor="desktop-price-100-200" className="text-sm">
                  $100 - $200
                </label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox id="desktop-price-over-200" />
                <label htmlFor="desktop-price-over-200" className="text-sm">
                  Over $200
                </label>
              </div>
            </div>
          </div>
          <Separator />
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Materials</h3>
            <div className="grid gap-2">
              {materials.map((material) => (
                <div key={material} className="flex items-center gap-2">
                  <Checkbox id={`desktop-material-${material}`} />
                  <label htmlFor={`desktop-material-${material}`} className="text-sm">
                    {material}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="md:col-span-4 space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold tracking-tight">Bedroom</h1>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="hidden md:flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" />
                Sort
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {bedroomProducts.length > 0 ? (
              bedroomProducts.map((product) => (
                <Card key={product.id} className="overflow-hidden">
                  <div className="relative aspect-square">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      fill
                      className="object-cover transition-transform hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-4">
                    <div className="space-y-1">
                      <h3 className="font-medium">{product.name}</h3>
                      <p className="text-sm text-gray-500">{product.category}</p>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-primary">{product.price}</span>
                        <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs">
                          Add to Cart
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-gray-500">No bedroom products found.</p>
                <p className="text-sm text-gray-400 mt-2">Add products from the admin dashboard.</p>
              </div>
            )}
          </div>
          {bedroomProducts.length > 0 && (
            <div className="flex justify-center">
              <Button variant="outline" className="w-full sm:w-auto">
                Load More
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

const bedroomCategories = ["Bedding", "Pillows", "Duvets", "Furniture", "Decor", "Lighting"]

const materials = ["Cotton", "Linen", "Silk", "Polyester", "Wood", "Metal"]

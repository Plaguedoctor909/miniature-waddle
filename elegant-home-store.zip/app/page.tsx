import Link from "next/link"
import Image from "next/image"
import { ShoppingBag, Heart, Search, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserNav } from "@/components/user-nav"
import { getProducts, getFeaturedProducts } from "@/lib/products"

export default async function HomePage() {
  const allProducts = await getProducts()
  const featuredProducts = await getFeaturedProducts()

  // Get products for different tabs
  const trendingProducts = allProducts.filter((p) => p.section === "Trending").slice(0, 4)
  const newArrivals = allProducts.filter((p) => p.section === "New Arrivals").slice(0, 4)
  const bestSellers = allProducts.filter((p) => p.section === "Best Sellers").slice(0, 4)

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-xl font-bold text-primary">Elegant Home & Style</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link href="/kitchen" className="text-sm font-medium transition-colors hover:text-primary">
                Kitchen
              </Link>
              <Link href="/bedroom" className="text-sm font-medium transition-colors hover:text-primary">
                Bedroom
              </Link>
              <Link href="/clothing" className="text-sm font-medium transition-colors hover:text-primary">
                Clothing
              </Link>
              <Link href="/women" className="text-sm font-medium transition-colors hover:text-primary">
                Women/Girls
              </Link>
              <Link href="/men" className="text-sm font-medium transition-colors hover:text-primary">
                Men
              </Link>
              <Link href="/boys" className="text-sm font-medium transition-colors hover:text-primary">
                Boys
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <form className="hidden items-center lg:flex">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search products..."
                  className="w-64 pl-8 rounded-lg border-purple-200 focus-visible:ring-purple-300"
                />
              </div>
            </form>
            <Button variant="ghost" size="icon" className="relative">
              <Heart className="h-5 w-5" />
              <span className="sr-only">Wishlist</span>
              <Badge className="absolute -right-1 -top-1 h-5 w-5 rounded-full p-0 text-xs bg-secondary text-secondary-foreground">
                0
              </Badge>
            </Button>
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingBag className="h-5 w-5" />
              <span className="sr-only">Cart</span>
              <Badge className="absolute -right-1 -top-1 h-5 w-5 rounded-full p-0 text-xs bg-secondary text-secondary-foreground">
                0
              </Badge>
            </Button>
            <UserNav />
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-purple-100 to-pink-100">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl md:text-6xl text-primary">
                  Elegant Living, Stylish Fashion
                </h1>
                <p className="max-w-[600px] text-gray-600 md:text-xl">
                  Discover our curated collection of home essentials and fashion for the whole family.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Shop Now</Button>
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary/10">
                    View Collections
                  </Button>
                </div>
              </div>
              <div className="relative h-[300px] lg:h-[400px] overflow-hidden rounded-xl">
                <Image
                  src="/placeholder.svg?height=800&width=1200"
                  alt="Hero Image"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-primary">
                  Shop by Category
                </h2>
                <p className="max-w-[700px] text-gray-600 md:text-xl">
                  Explore our wide range of products for your home and wardrobe
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-8">
              {categories.map((category) => (
                <Link
                  key={category.name}
                  href={category.href}
                  className="group relative overflow-hidden rounded-lg shadow-md transition-all hover:shadow-lg"
                >
                  <div className="aspect-square relative">
                    <Image
                      src={category.image || "/placeholder.svg"}
                      alt={category.name}
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-0 left-0 p-4">
                      <h3 className="text-lg font-medium text-white">{category.name}</h3>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-gradient-to-r from-purple-50 to-pink-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-primary">Featured Products</h2>
                <p className="max-w-[700px] text-gray-600 md:text-xl">Our most popular items across all categories</p>
              </div>
            </div>
            <Tabs defaultValue="trending" className="mt-8">
              <div className="flex justify-center">
                <TabsList className="bg-purple-100">
                  <TabsTrigger
                    value="trending"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    Trending
                  </TabsTrigger>
                  <TabsTrigger
                    value="new-arrivals"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    New Arrivals
                  </TabsTrigger>
                  <TabsTrigger
                    value="best-sellers"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    Best Sellers
                  </TabsTrigger>
                </TabsList>
              </div>
              <TabsContent value="trending" className="mt-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {trendingProducts.length > 0 ? (
                    trendingProducts.map((product) => <ProductCard key={product.id} product={product} />)
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-gray-500">No trending products found.</p>
                      <p className="text-sm text-gray-400 mt-2">Add products from the admin dashboard.</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              <TabsContent value="new-arrivals" className="mt-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {newArrivals.length > 0 ? (
                    newArrivals.map((product) => <ProductCard key={product.id} product={product} />)
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-gray-500">No new arrivals found.</p>
                      <p className="text-sm text-gray-400 mt-2">Add products from the admin dashboard.</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              <TabsContent value="best-sellers" className="mt-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {bestSellers.length > 0 ? (
                    bestSellers.map((product) => <ProductCard key={product.id} product={product} />)
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-gray-500">No best sellers found.</p>
                      <p className="text-sm text-gray-400 mt-2">Add products from the admin dashboard.</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        <section className="w-full py-12 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="relative h-[300px] lg:h-[500px] overflow-hidden rounded-xl">
                <Image
                  src="/placeholder.svg?height=1000&width=800"
                  alt="Special Collection"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-primary">New Season Collection</h2>
                <p className="max-w-[600px] text-gray-600 md:text-xl">
                  Discover our latest arrivals for the new season. Refresh your wardrobe and home with our stylish new
                  pieces.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Explore Collection</Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-gradient-to-r from-purple-100 to-pink-100">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-primary">Popular Categories</h2>
                <p className="max-w-[700px] text-gray-600 md:text-xl">Shop our most popular categories</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <CategoryFeature
                title="Kitchen Essentials"
                description="Transform your kitchen with our stylish and functional essentials"
                image="/placeholder.svg?height=600&width=800"
                href="/kitchen"
              />
              <CategoryFeature
                title="Women's Fashion"
                description="Discover the latest trends in women's clothing and accessories"
                image="/placeholder.svg?height=600&width=800"
                href="/women"
                bgColor="from-pink-200 to-purple-100"
              />
              <CategoryFeature
                title="Men's Collection"
                description="Elevate your style with our curated men's collection"
                image="/placeholder.svg?height=600&width=800"
                href="/men"
              />
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-primary">Join Our Newsletter</h2>
                <p className="max-w-[700px] text-gray-600 md:text-xl">
                  Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals
                </p>
              </div>
              <div className="w-full max-w-md space-y-2">
                <form className="flex space-x-2">
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    className="flex-1 border-purple-200 focus-visible:ring-purple-300"
                  />
                  <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                    Subscribe
                  </Button>
                </form>
                <p className="text-xs text-gray-500">
                  By subscribing you agree to our Terms of Service and Privacy Policy
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-background">
        <div className="container px-4 md:px-6 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8">
            <div className="col-span-2">
              <Link href="/" className="flex items-center space-x-2">
                <span className="text-xl font-bold text-primary">Elegant Home & Style</span>
              </Link>
              <p className="mt-2 text-sm text-gray-500">
                Your one-stop shop for home essentials and fashion for the whole family.
              </p>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Shop</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/kitchen" className="text-gray-500 hover:text-primary">
                    Kitchen
                  </Link>
                </li>
                <li>
                  <Link href="/bedroom" className="text-gray-500 hover:text-primary">
                    Bedroom
                  </Link>
                </li>
                <li>
                  <Link href="/clothing" className="text-gray-500 hover:text-primary">
                    Clothing
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Categories</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/women" className="text-gray-500 hover:text-primary">
                    Women/Girls
                  </Link>
                </li>
                <li>
                  <Link href="/men" className="text-gray-500 hover:text-primary">
                    Men
                  </Link>
                </li>
                <li>
                  <Link href="/boys" className="text-gray-500 hover:text-primary">
                    Boys
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Company</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/about" className="text-gray-500 hover:text-primary">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-500 hover:text-primary">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="text-gray-500 hover:text-primary">
                    Careers
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Legal</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/privacy" className="text-gray-500 hover:text-primary">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-gray-500 hover:text-primary">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/returns" className="text-gray-500 hover:text-primary">
                    Returns Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">
              © {new Date().getFullYear()} Elegant Home & Style. All rights reserved.
              <Button variant="link" size="sm" className="text-xs text-gray-400 p-0 h-auto ml-2" asChild>
                <Link href="/admin">Admin</Link>
              </Button>
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Button variant="ghost" size="icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-primary"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
                <span className="sr-only">Facebook</span>
              </Button>
              <Button variant="ghost" size="icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-primary"
                >
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                </svg>
                <span className="sr-only">Instagram</span>
              </Button>
              <Button variant="ghost" size="icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-primary"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                </svg>
                <span className="sr-only">Twitter</span>
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

function ProductCard({ product }) {
  return (
    <Card className="overflow-hidden group">
      <div className="relative aspect-square">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          fill
          className="object-cover transition-transform group-hover:scale-105"
        />
        <Button
          variant="secondary"
          size="icon"
          className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <Heart className="h-4 w-4" />
          <span className="sr-only">Add to wishlist</span>
        </Button>
      </div>
      <CardContent className="p-4">
        <div className="space-y-1">
          <h3 className="font-medium">{product.name}</h3>
          <p className="text-sm text-gray-500">{product.category}</p>
          <div className="flex items-center justify-between">
            <span className="font-bold text-primary">{product.price}</span>
            <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs">
              Add to Cart
              <ShoppingBag className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function CategoryFeature({ title, description, image, href, bgColor = "from-purple-100 to-pink-100" }) {
  return (
    <div className={`relative overflow-hidden rounded-lg shadow-md group`}>
      <div className="aspect-[4/3] relative">
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform group-hover:scale-105"
        />
        <div className={`absolute inset-0 bg-gradient-to-t ${bgColor} opacity-70`} />
        <div className="absolute inset-0 p-6 flex flex-col justify-end">
          <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
          <p className="text-sm text-gray-700 mb-4">{description}</p>
          <Link href={href}>
            <Button variant="secondary" className="w-full justify-between group-hover:bg-white/90">
              Shop Now
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

const categories = [
  {
    name: "Kitchen",
    href: "/kitchen",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    name: "Bedroom",
    href: "/bedroom",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    name: "Clothing",
    href: "/clothing",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    name: "Women/Girls",
    href: "/women",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    name: "Men",
    href: "/men",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    name: "Boys",
    href: "/boys",
    image: "/placeholder.svg?height=400&width=400",
  },
]

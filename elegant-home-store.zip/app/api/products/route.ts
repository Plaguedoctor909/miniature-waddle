import { type NextRequest, NextResponse } from "next/server"
import { getProducts, addProduct } from "@/lib/products"

// Get all products
export async function GET() {
  try {
    const products = await getProducts()
    return NextResponse.json(products)
  } catch (error) {
    console.error("Error fetching products:", error)
    return NextResponse.json({ message: "Error fetching products" }, { status: 500 })
  }
}

// Add a new product
export async function POST(request: NextRequest) {
  try {
    const productData = await request.json()
    console.log("Received product data:", productData)

    // Validate required fields
    if (!productData.name || !productData.price || !productData.category || !productData.section) {
      return NextResponse.json({ message: "Name, price, category, and section are required" }, { status: 400 })
    }

    // Ensure image has a default value if not provided
    if (!productData.image) {
      productData.image = "/placeholder.svg?height=500&width=500"
    }

    const newProduct = await addProduct(productData)

    // Return with cache control headers
    return NextResponse.json(newProduct, {
      status: 201,
      headers: {
        "Cache-Control": "no-store, must-revalidate",
        Pragma: "no-cache",
      },
    })
  } catch (error) {
    console.error("Error adding product:", error)
    return NextResponse.json(
      { message: `Error adding product: ${error instanceof Error ? error.message : String(error)}` },
      { status: 500 },
    )
  }
}

import { handleUpload } from "@vercel/blob/client"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    if (!process.env.BLOB_READ_WRITE_TOKEN) {
      console.error("BLOB_READ_WRITE_TOKEN is not defined")
      return NextResponse.json({ error: "Configuration error" }, { status: 500 })
    }

    const response = await handleUpload({
      request,
      token: process.env.BLOB_READ_WRITE_TOKEN,
    })

    return NextResponse.json(response)
  } catch (error) {
    console.error("Error in upload route:", error)
    return NextResponse.json(
      { error: `Upload failed: ${error instanceof Error ? error.message : String(error)}` },
      { status: 500 },
    )
  }
}

export const runtime = "nodejs"

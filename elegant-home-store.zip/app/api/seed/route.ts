import { NextResponse } from "next/server"
import { seedDatabase } from "@/lib/seed-data"

export async function POST() {
  try {
    const result = await seedDatabase()

    if (result.success) {
      return NextResponse.json({ message: result.message }, { status: 200 })
    } else {
      return NextResponse.json({ message: result.message }, { status: 400 })
    }
  } catch (error) {
    console.error("Error in seed API:", error)
    return NextResponse.json(
      { message: `Error seeding database: ${error instanceof Error ? error.message : String(error)}` },
      { status: 500 },
    )
  }
}

// Simple admin auth that always returns true for testing purposes
export async function ensureAdminAuthenticated() {
  return true
}

export async function getAdminSession() {
  return "admin_authenticated"
}

export async function isAdminAuthenticated() {
  return true
}

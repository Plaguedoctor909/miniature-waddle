import { cookies } from "next/headers"
import { list, put } from "@vercel/blob"
import { redirect } from "next/navigation"

export type User = {
  id: string
  email: string
  name: string
  password: string // In a real app, this would be hashed
  createdAt: string
}

const USER_COOKIE_NAME = "auth_token"
const USERS_BLOB_PATH = "users/users.json"

// Load users from Blob storage
export async function getUsers(): Promise<User[]> {
  try {
    const blobs = await list({ prefix: "users/" })
    const userBlob = blobs.blobs.find((blob) => blob.pathname === USERS_BLOB_PATH)

    if (userBlob) {
      const response = await fetch(userBlob.url)
      const users = await response.json()
      return users
    }

    // If no users file exists yet, create an empty one
    await saveUsers([])
    return []
  } catch (error) {
    console.error("Error loading users:", error)
    return []
  }
}

// Save users to Blob storage
export async function saveUsers(users: User[]): Promise<void> {
  try {
    const usersJson = JSON.stringify(users, null, 2)
    const buffer = Buffer.from(usersJson)
    await put(USERS_BLOB_PATH, buffer, {
      access: "public",
      contentType: "application/json",
    })
  } catch (error) {
    console.error("Error saving users:", error)
  }
}

// Register a new user
export async function registerUser(userData: Omit<User, "id" | "createdAt">): Promise<User | null> {
  const users = await getUsers()

  // Check if user already exists
  if (users.some((user) => user.email === userData.email)) {
    return null
  }

  const newUser: User = {
    ...userData,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  }

  users.push(newUser)
  await saveUsers(users)

  return newUser
}

// Login a user
export async function loginUser(email: string, password: string): Promise<User | null> {
  const users = await getUsers()
  const user = users.find((user) => user.email === email && user.password === password)

  if (user) {
    // Set auth cookie
    cookies().set({
      name: USER_COOKIE_NAME,
      value: user.id,
      httpOnly: true,
      path: "/",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 7, // 1 week
    })

    return user
  }

  return null
}

// Logout a user
export async function logoutUser() {
  cookies().delete(USER_COOKIE_NAME)
}

// Get the current user
export async function getCurrentUser(): Promise<User | null> {
  const userId = cookies().get(USER_COOKIE_NAME)?.value

  if (!userId) {
    return null
  }

  const users = await getUsers()
  return users.find((user) => user.id === userId) || null
}

// Check if user is authenticated
export async function isAuthenticated(): Promise<boolean> {
  const user = await getCurrentUser()
  return !!user
}

// Require authentication middleware
export async function requireAuth() {
  const isAuthed = await isAuthenticated()

  if (!isAuthed) {
    redirect("/auth/login")
  }
}

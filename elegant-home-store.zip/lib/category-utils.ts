// Create a utility function for fetching category products with cache busting
import { getProductsByCategory } from "./products"

export async function getCategoryProducts(category: string) {
  // Add a timestamp to force fresh data on each request
  const timestamp = Date.now()
  return getProductsByCategory(category)
}

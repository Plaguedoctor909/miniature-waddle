import { list, put } from "@vercel/blob"

export type Product = {
  id: string
  name: string
  description: string
  price: string
  category: string
  section: string
  image: string
  featured?: boolean
  createdAt: string
  updatedAt: string
}

const PRODUCTS_BLOB_PATH = "products/products.json"

// Load products from Blob storage
export async function getProducts(): Promise<Product[]> {
  try {
    const blobs = await list({ prefix: "products/" })
    const productBlob = blobs.blobs.find((blob) => blob.pathname === PRODUCTS_BLOB_PATH)

    if (productBlob) {
      const response = await fetch(productBlob.url)
      const products = await response.json()
      return products
    }

    // If no products file exists yet, create an empty one
    await saveProducts([])
    return []
  } catch (error) {
    console.error("Error loading products:", error)
    return []
  }
}

// Save products to Blob storage
export async function saveProducts(products: Product[]): Promise<void> {
  try {
    const productsJson = JSON.stringify(products, null, 2)
    const buffer = Buffer.from(productsJson)
    await put(PRODUCTS_BLOB_PATH, buffer, {
      access: "public",
      contentType: "application/json",
      allowOverwrite: true, // Add this option to allow overwriting existing blob
    })
  } catch (error) {
    console.error("Error saving products:", error)
    throw new Error(`Failed to save products: ${error instanceof Error ? error.message : String(error)}`)
  }
}

// Add a new product
export async function addProduct(productData: Omit<Product, "id" | "createdAt" | "updatedAt">): Promise<Product> {
  try {
    const products = await getProducts()

    // Ensure image has a default value
    if (!productData.image) {
      productData.image = "/placeholder.svg?height=500&width=500"
    }

    const newProduct: Product = {
      ...productData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    products.push(newProduct)
    await saveProducts(products)

    return newProduct
  } catch (error) {
    console.error("Error adding product:", error)
    throw new Error(`Failed to add product: ${error instanceof Error ? error.message : String(error)}`)
  }
}

// Update an existing product
export async function updateProduct(id: string, productData: Partial<Product>): Promise<Product | null> {
  const products = await getProducts()
  const index = products.findIndex((product) => product.id === id)

  if (index === -1) {
    return null
  }

  products[index] = {
    ...products[index],
    ...productData,
    updatedAt: new Date().toISOString(),
  }

  await saveProducts(products)
  return products[index]
}

// Delete a product
export async function deleteProduct(id: string): Promise<boolean> {
  const products = await getProducts()
  const filteredProducts = products.filter((product) => product.id !== id)

  if (filteredProducts.length === products.length) {
    return false
  }

  await saveProducts(filteredProducts)
  return true
}

// Get products by category
export async function getProductsByCategory(category: string): Promise<Product[]> {
  const products = await getProducts()
  return products.filter((product) => product.category === category)
}

// Get featured products
export async function getFeaturedProducts(): Promise<Product[]> {
  const products = await getProducts()
  return products.filter((product) => product.featured)
}

// Get product by ID
export async function getProductById(id: string): Promise<Product | null> {
  const products = await getProducts()
  return products.find((product) => product.id === id) || null
}

"use client"

import CryptoTradingInterface from "../crypto-trading-interface"

export default function SyntheticV0PageForDeployment() {
  return <CryptoTradingInterface />
}
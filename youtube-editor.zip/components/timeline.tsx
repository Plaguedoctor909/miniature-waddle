"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { ChevronDown, Plus, Scissors, Lock, Eye, Music } from "lucide-react"
import type { Track, Clip } from "@/hooks/use-timeline"

interface TimelineProps {
  tracks: Track[]
  currentTime: number
  onTimelineClick: (position: number) => void
  onClipSelect: (clipId: string | null) => void
  selectedClipId: string | null
  onClipMove: (clipId: string, trackId: string, newStart: number) => void
  onClipResize: (clipId: string, newDuration: number) => void
  onAddTrack: () => void
}

export default function Timeline({
  tracks,
  currentTime,
  onTimelineClick,
  onClipSelect,
  selectedClipId,
  onClipMove,
  onClipResize,
  onAddTrack,
}: TimelineProps) {
  const [zoom, setZoom] = useState(100)
  const timelineWidth = 2000 * (zoom / 100)
  const timelineRef = useRef<HTMLDivElement>(null)
  const [dragState, setDragState] = useState<{
    clipId: string
    startX: number
    originalStart: number
    trackId: string
    resizing: boolean
    edge: "left" | "right" | null
  } | null>(null)

  const handleZoomChange = (value: number[]) => {
    setZoom(value[0])
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleTimelineAreaClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current) return

    const rect = timelineRef.current.getBoundingClientRect()
    const clickX = e.clientX - rect.left
    const timePosition = clickX / (zoom / 100)

    onTimelineClick(timePosition)
  }

  const handleClipMouseDown = (e: React.MouseEvent, clip: Clip, trackId: string) => {
    e.stopPropagation()

    // Select the clip
    onClipSelect(clip.id)

    // Check if we're clicking near the edges (for resizing)
    const target = e.currentTarget as HTMLDivElement
    const rect = target.getBoundingClientRect()
    const clickX = e.clientX - rect.left

    const edgeThreshold = 10 // pixels
    let resizing = false
    let edge: "left" | "right" | null = null

    if (clickX < edgeThreshold) {
      resizing = true
      edge = "left"
    } else if (clickX > rect.width - edgeThreshold) {
      resizing = true
      edge = "right"
    }

    setDragState({
      clipId: clip.id,
      startX: e.clientX,
      originalStart: clip.start,
      trackId,
      resizing,
      edge,
    })
  }

  const handleMouseMove = (e: MouseEvent) => {
    if (!dragState || !timelineRef.current) return

    const deltaX = e.clientX - dragState.startX
    const deltaTime = deltaX / (zoom / 100)

    if (dragState.resizing && dragState.edge) {
      // Find the clip
      let clipToResize: Clip | null = null
      let originalDuration = 0

      for (const track of tracks) {
        const clip = track.clips.find((c) => c.id === dragState.clipId)
        if (clip) {
          clipToResize = clip
          originalDuration = clip.duration
          break
        }
      }

      if (!clipToResize) return

      if (dragState.edge === "right") {
        // Resizing from right edge - change duration
        const newDuration = Math.max(10, originalDuration + deltaTime)
        onClipResize(dragState.clipId, newDuration)
      } else {
        // Resizing from left edge - change start and duration
        const maxLeftMove = clipToResize.start
        const actualMove = Math.min(maxLeftMove, deltaTime)

        const newStart = Math.max(0, dragState.originalStart - actualMove)
        const newDuration = originalDuration + (dragState.originalStart - newStart)

        onClipMove(dragState.clipId, dragState.trackId, newStart)
        onClipResize(dragState.clipId, newDuration)
      }
    } else {
      // Moving the clip
      const newStart = Math.max(0, dragState.originalStart + deltaTime)
      onClipMove(dragState.clipId, dragState.trackId, newStart)
    }
  }

  const handleMouseUp = () => {
    setDragState(null)
  }

  // Handle drag and drop from media library
  const handleTrackDrop = (e: React.DragEvent, trackId: string) => {
    e.preventDefault()

    try {
      const data = JSON.parse(e.dataTransfer.getData("application/json"))
      if (!data) return

      // Calculate drop position
      const rect = timelineRef.current?.getBoundingClientRect()
      if (!rect) return

      const dropX = e.clientX - rect.left
      const dropPosition = dropX / (zoom / 100)

      // Create a new clip from the media item
      const newClip: Clip = {
        id: `clip-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        name: data.name,
        start: dropPosition,
        duration: 100, // Default duration
        color: data.type === "video" ? "bg-blue-500" : data.type === "image" ? "bg-green-500" : "bg-purple-500",
        type: data.type,
        mediaId: data.id,
      }

      // Add the clip to the track
      onClipMove(newClip.id, trackId, newClip.start)
    } catch (error) {
      console.error("Error handling drop:", error)
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = "copy"
  }

  // Set up mouse event listeners
  useEffect(() => {
    if (dragState) {
      window.addEventListener("mousemove", handleMouseMove)
      window.addEventListener("mouseup", handleMouseUp)

      return () => {
        window.removeEventListener("mousemove", handleMouseMove)
        window.removeEventListener("mouseup", handleMouseUp)
      }
    }
  }, [dragState])

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-2 border-b">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={onAddTrack}>
            <Plus className="h-4 w-4 mr-1" />
            Add Track
          </Button>
          <Button variant="outline" size="sm">
            <Scissors className="h-4 w-4 mr-1" />
            Split
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm">Zoom:</span>
          <Slider className="w-32" value={[zoom]} min={50} max={200} step={10} onValueChange={handleZoomChange} />
          <span className="text-sm w-10">{zoom}%</span>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Track Labels */}
        <div className="w-48 border-r bg-muted/30">
          <div className="h-8 border-b flex items-center px-2 text-sm font-medium">Tracks</div>
          <ScrollArea className="h-[calc(100%-32px)]">
            {tracks.map((track) => (
              <div key={track.id} className="border-b">
                <div className="flex items-center h-12 px-2 gap-1">
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  {track.type === "video" && <div className="w-4 h-4 bg-blue-500 rounded-sm" />}
                  {track.type === "audio" && <Music className="h-4 w-4 text-purple-500" />}
                  {track.type === "text" && <div className="w-4 h-4 bg-yellow-500 rounded-sm" />}
                  <span className="text-sm truncate flex-1">{track.name}</span>
                  <Button variant="ghost" size="icon" className="h-6 w-6">
                    <Eye className={`h-4 w-4 ${track.visible ? "" : "text-muted-foreground"}`} />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-6 w-6">
                    <Lock className={`h-4 w-4 ${track.locked ? "" : "text-muted-foreground"}`} />
                  </Button>
                </div>
              </div>
            ))}
          </ScrollArea>
        </div>

        {/* Timeline */}
        <div className="flex-1 relative">
          {/* Time Ruler */}
          <div className="h-8 border-b sticky top-0 bg-background z-10">
            <div className="relative h-full" style={{ width: `${timelineWidth}px` }}>
              {Array.from({ length: Math.ceil(timelineWidth / 100) }).map((_, i) => (
                <div key={i} className="absolute top-0 h-full flex items-end pb-1" style={{ left: `${i * 100}px` }}>
                  <span className="text-xs text-muted-foreground">{formatTime(i * 10)}</span>
                </div>
              ))}
              {/* Current Time Indicator */}
              <div
                className="absolute top-0 bottom-0 w-px bg-red-500 z-20"
                style={{ left: `${currentTime * 10 * (zoom / 100)}px` }}
              >
                <div className="w-3 h-3 bg-red-500 rounded-full -translate-x-1/2" />
              </div>
            </div>
          </div>

          {/* Tracks Content */}
          <ScrollArea className="h-[calc(100%-32px)]" orientation="horizontal">
            <div
              ref={timelineRef}
              style={{ width: `${timelineWidth}px` }}
              onClick={handleTimelineAreaClick}
              onDragOver={handleDragOver}
            >
              {tracks.map((track) => (
                <div
                  key={track.id}
                  className="h-12 border-b relative"
                  onDrop={(e) => handleTrackDrop(e, track.id)}
                  onDragOver={handleDragOver}
                >
                  {track.clips.map((clip) => (
                    <div
                      key={clip.id}
                      className={`absolute top-1 h-10 ${clip.color} rounded-sm cursor-move flex items-center px-2 text-white text-xs
                        ${selectedClipId === clip.id ? "ring-2 ring-white" : ""}
                        ${dragState?.clipId === clip.id ? "opacity-70" : ""}
                      `}
                      style={{
                        left: `${clip.start * (zoom / 100)}px`,
                        width: `${clip.duration * (zoom / 100)}px`,
                      }}
                      onMouseDown={(e) => handleClipMouseDown(e, clip, track.id)}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="truncate">{clip.name}</div>

                      {/* Resize handles */}
                      <div className="absolute left-0 top-0 bottom-0 w-2 cursor-w-resize" />
                      <div className="absolute right-0 top-0 bottom-0 w-2 cursor-e-resize" />
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Current Time Indicator (vertical line) */}
          <div
            className="absolute top-8 bottom-0 w-px bg-red-500 z-20 pointer-events-none"
            style={{ left: `${currentTime * 10 * (zoom / 100)}px` }}
          />
        </div>
      </div>
    </div>
  )
}

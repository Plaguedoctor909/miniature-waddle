"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/components/ui/use-toast"
import MediaLibrary from "./media-library"
import Timeline from "./timeline"
import VideoControls from "./video-controls"
import { Volume2, Text, ImageIcon, Music, Upload, Share, Undo, Redo, Save } from "lucide-react"
import { useMediaLibrary } from "@/hooks/use-media-library"
import { useTimeline } from "@/hooks/use-timeline"
import { useVideoEditor } from "@/hooks/use-video-editor"
import { ExportDialog } from "./export-dialog"

export default function VideoEditor() {
  // State management
  const [projectName, setProjectName] = useState("Untitled Project")
  const [clipDuration, setClipDuration] = useState("00:05:30")
  const [exportDialogOpen, setExportDialogOpen] = useState(false)
  const [autoEnhance, setAutoEnhance] = useState(false)
  const [brightness, setBrightness] = useState(50)
  const [contrast, setContrast] = useState(50)
  const [saturation, setSaturation] = useState(50)
  const [speed, setSpeed] = useState(100)

  // Custom hooks for different parts of the editor
  const {
    isPlaying,
    currentTime,
    duration,
    volume,
    videoRef,
    togglePlay,
    handleTimeUpdate,
    handleVolumeChange,
    setCurrentTime,
    formatTime,
    seekTo,
  } = useVideoEditor()

  const { mediaItems, uploadMedia, handleFileUpload, fileInputRef } = useMediaLibrary()

  const {
    tracks,
    selectedClipId,
    addClipToTrack,
    moveClip,
    resizeClip,
    splitClipAt,
    deleteSelectedClip,
    selectClip,
    handleTimelineClick,
    undoAction,
    redoAction,
    canUndo,
    canRedo,
  } = useTimeline(currentTime, seekTo)

  // Apply video effects when they change
  useEffect(() => {
    if (videoRef.current) {
      // Apply effects to video element
      const filters = []
      if (brightness !== 50) filters.push(`brightness(${brightness * 2}%)`)
      if (contrast !== 50) filters.push(`contrast(${contrast * 2}%)`)
      if (saturation !== 50) filters.push(`saturate(${saturation * 2}%)`)

      videoRef.current.style.filter = filters.join(" ")

      // Apply playback speed
      videoRef.current.playbackRate = speed / 100
    }
  }, [brightness, contrast, saturation, speed, videoRef])

  // Auto-enhance effect
  useEffect(() => {
    if (autoEnhance) {
      setBrightness(60)
      setContrast(55)
      setSaturation(60)
    }
  }, [autoEnhance])

  // Handle save project
  const handleSaveProject = () => {
    // In a real app, this would save to a database or file
    const project = {
      name: projectName,
      tracks,
      mediaItems,
      settings: {
        brightness,
        contrast,
        saturation,
        speed,
      },
    }

    // For demo purposes, we'll just log and show a toast
    console.log("Saving project:", project)
    toast({
      title: "Project Saved",
      description: `${projectName} has been saved successfully.`,
    })
  }

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <header className="border-b bg-card p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold">theo's studio</h1>
            <Input
              className="w-64"
              placeholder="Project name"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={undoAction} disabled={!canUndo}>
              <Undo className="mr-2 h-4 w-4" />
              Undo
            </Button>
            <Button variant="outline" size="sm" onClick={redoAction} disabled={!canRedo}>
              <Redo className="mr-2 h-4 w-4" />
              Redo
            </Button>
            <Button variant="outline" size="sm" onClick={handleSaveProject}>
              <Save className="mr-2 h-4 w-4" />
              Save
            </Button>
            <Button variant="default" size="sm" onClick={() => setExportDialogOpen(true)}>
              <Share className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - Media Library */}
        <div className="w-64 border-r bg-card hidden md:block">
          <Tabs defaultValue="media">
            <TabsList className="w-full">
              <TabsTrigger value="media" className="flex-1">
                Media
              </TabsTrigger>
              <TabsTrigger value="effects" className="flex-1">
                Effects
              </TabsTrigger>
            </TabsList>
            <TabsContent value="media" className="p-0">
              <MediaLibrary
                mediaItems={mediaItems}
                onUpload={() => fileInputRef.current?.click()}
                onDragStart={(item) => {
                  // Set drag data for timeline drop
                  return { type: "media", item }
                }}
              />
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="video/*,image/*"
                onChange={handleFileUpload}
              />
            </TabsContent>
            <TabsContent value="effects" className="p-4">
              <div className="grid gap-4">
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    addClipToTrack("text-1", {
                      id: `text-${Date.now()}`,
                      name: "New Text",
                      start: currentTime * 10,
                      duration: 50,
                      color: "bg-yellow-500",
                      type: "text",
                      content: "Add your text here",
                    })
                  }}
                >
                  <Text className="mr-2 h-4 w-4" />
                  Add Text
                </Button>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    addClipToTrack("video-1", {
                      id: `sticker-${Date.now()}`,
                      name: "Sticker",
                      start: currentTime * 10,
                      duration: 50,
                      color: "bg-pink-500",
                      type: "sticker",
                      content: "👍",
                    })
                  }}
                >
                  <ImageIcon className="mr-2 h-4 w-4" />
                  Add Sticker
                </Button>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    addClipToTrack("audio-1", {
                      id: `audio-${Date.now()}`,
                      name: "Audio Effect",
                      start: currentTime * 10,
                      duration: 100,
                      color: "bg-purple-500",
                      type: "audio",
                      source: "/audio/effect.mp3",
                    })
                  }}
                >
                  <Music className="mr-2 h-4 w-4" />
                  Add Audio Effect
                </Button>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    // Add transition between clips
                    if (selectedClipId) {
                      addClipToTrack("video-1", {
                        id: `transition-${Date.now()}`,
                        name: "Transition",
                        start: currentTime * 10,
                        duration: 20,
                        color: "bg-indigo-500",
                        type: "transition",
                        effect: "fade",
                      })
                    }
                  }}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Add Transition
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Main Editor */}
        <div className="flex-1 flex flex-col">
          {/* Video Preview */}
          <div className="flex-1 bg-black flex items-center justify-center p-4">
            <div className="relative w-full max-w-3xl aspect-video bg-zinc-900 rounded-lg overflow-hidden">
              <video
                ref={videoRef}
                className="w-full h-full object-contain"
                src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={() => {
                  if (videoRef.current) {
                    // Duration is set in the useVideoEditor hook
                  }
                }}
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                <div className="flex items-center justify-between text-white">
                  <div className="text-sm">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </div>
                  <div className="flex items-center gap-2">
                    <Volume2 className="h-4 w-4" />
                    <Slider className="w-24" value={[volume]} max={100} step={1} onValueChange={handleVolumeChange} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Video Controls */}
          <div className="p-4 bg-card border-t">
            <VideoControls
              isPlaying={isPlaying}
              togglePlay={togglePlay}
              currentTime={currentTime}
              duration={duration}
              setCurrentTime={setCurrentTime}
              onSplit={() => splitClipAt(currentTime * 10)}
              onDeleteClip={deleteSelectedClip}
            />
          </div>

          {/* Timeline */}
          <div className="h-64 border-t bg-card">
            <Timeline
              tracks={tracks}
              currentTime={currentTime}
              onTimelineClick={handleTimelineClick}
              onClipSelect={selectClip}
              selectedClipId={selectedClipId}
              onClipMove={moveClip}
              onClipResize={resizeClip}
              onAddTrack={() => {
                // Add new track functionality
                toast({
                  title: "Track Added",
                  description: "A new track has been added to the timeline.",
                })
              }}
            />
          </div>
        </div>

        {/* Right Sidebar - Properties */}
        <div className="w-72 border-l bg-card hidden lg:block">
          <div className="p-4">
            <h3 className="font-medium mb-4">Properties</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Clip Duration</Label>
                <div className="flex items-center gap-2">
                  <Input value={clipDuration} onChange={(e) => setClipDuration(e.target.value)} className="w-24" />
                  <span>seconds</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Speed</Label>
                <div className="flex items-center gap-2">
                  <Slider
                    value={[speed]}
                    max={200}
                    min={25}
                    step={5}
                    className="flex-1"
                    onValueChange={(value) => setSpeed(value[0])}
                  />
                  <span className="w-12 text-right">{speed}%</span>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-enhance">Auto Enhance</Label>
                  <Switch id="auto-enhance" checked={autoEnhance} onCheckedChange={setAutoEnhance} />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Brightness</Label>
                <Slider value={[brightness]} max={100} step={1} onValueChange={(value) => setBrightness(value[0])} />
              </div>

              <div className="space-y-2">
                <Label>Contrast</Label>
                <Slider value={[contrast]} max={100} step={1} onValueChange={(value) => setContrast(value[0])} />
              </div>

              <div className="space-y-2">
                <Label>Saturation</Label>
                <Slider value={[saturation]} max={100} step={1} onValueChange={(value) => setSaturation(value[0])} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Export Dialog */}
      <ExportDialog open={exportDialogOpen} onOpenChange={setExportDialogOpen} projectName={projectName} />
    </div>
  )
}

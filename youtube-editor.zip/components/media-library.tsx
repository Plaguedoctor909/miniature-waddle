"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Video, ImageIcon, Music } from "lucide-react"
import { useState } from "react"
import type { MediaItem } from "@/hooks/use-media-library"

interface MediaLibraryProps {
  mediaItems: MediaItem[]
  onUpload: () => void
  onDragStart: (item: MediaItem) => any
}

export default function MediaLibrary({ mediaItems, onUpload, onDragStart }: MediaLibraryProps) {
  const [filter, setFilter] = useState<"all" | "videos" | "images" | "audio">("all")

  const filteredItems = mediaItems.filter((item) => {
    if (filter === "all") return true
    return item.type === filter.slice(0, -1) // Remove 's' from end
  })

  const handleDragStart = (e: React.DragEvent, item: MediaItem) => {
    // Set drag data
    e.dataTransfer.setData("application/json", JSON.stringify(item))
    e.dataTransfer.effectAllowed = "copy"
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-4">
        <Button className="w-full" onClick={onUpload}>
          <Upload className="mr-2 h-4 w-4" />
          Upload Media
        </Button>
      </div>

      <Tabs defaultValue="all" onValueChange={(value) => setFilter(value as any)}>
        <TabsList className="w-full">
          <TabsTrigger value="all" className="flex-1">
            All
          </TabsTrigger>
          <TabsTrigger value="videos" className="flex-1">
            Videos
          </TabsTrigger>
          <TabsTrigger value="images" className="flex-1">
            Images
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1 h-[calc(100vh-300px)]">
          <div className="p-4 grid gap-4">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="flex gap-3 p-2 rounded-md hover:bg-accent cursor-move"
                draggable
                onDragStart={(e) => handleDragStart(e, item)}
              >
                <div className="relative">
                  <img
                    src={item.thumbnail || "/placeholder.svg"}
                    alt={item.name}
                    className="w-20 h-12 object-cover rounded"
                  />
                  {item.type === "video" && item.duration && (
                    <div className="absolute bottom-1 right-1 bg-black/70 text-white text-xs px-1 rounded">
                      {item.duration}
                    </div>
                  )}
                </div>
                <div className="flex flex-col justify-center">
                  <div className="text-sm font-medium">{item.name}</div>
                  <div className="text-xs text-muted-foreground flex items-center">
                    {item.type === "video" ? (
                      <Video className="h-3 w-3 mr-1" />
                    ) : item.type === "image" ? (
                      <ImageIcon className="h-3 w-3 mr-1" />
                    ) : (
                      <Music className="h-3 w-3 mr-1" />
                    )}
                    {item.type}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </Tabs>
    </div>
  )
}

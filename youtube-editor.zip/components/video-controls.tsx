"use client"

import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { Play, Pause, SkipBack, SkipForward, Scissors, Trash2 } from "lucide-react"

interface VideoControlsProps {
  isPlaying: boolean
  togglePlay: () => void
  currentTime: number
  duration: number
  setCurrentTime: (time: number) => void
  onSplit: () => void
  onDeleteClip: () => void
}

export default function VideoControls({
  isPlaying,
  togglePlay,
  currentTime,
  duration,
  setCurrentTime,
  onSplit,
  onDeleteClip,
}: VideoControlsProps) {
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
  }

  const handleSkipBack = () => {
    setCurrentTime(Math.max(0, currentTime - 5))
  }

  const handleSkipForward = () => {
    setCurrentTime(Math.min(duration, currentTime + 5))
  }

  return (
    <div className="space-y-2">
      <Slider
        value={[currentTime]}
        max={duration}
        step={0.1}
        className="cursor-pointer"
        onValueChange={(value) => setCurrentTime(value[0])}
      />
      <div className="flex items-center justify-between">
        <div className="text-sm">
          {formatTime(currentTime)} / {formatTime(duration)}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={handleSkipBack}>
            <SkipBack className="h-4 w-4" />
          </Button>
          <Button onClick={togglePlay} variant="default" size="icon">
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button variant="outline" size="icon" onClick={handleSkipForward}>
            <SkipForward className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={onSplit}>
            <Scissors className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={onDeleteClip}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
        <div className="text-sm">Speed: 1x</div>
      </div>
    </div>
  )
}

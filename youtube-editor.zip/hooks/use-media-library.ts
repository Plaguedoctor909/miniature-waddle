"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"
import { toast } from "@/components/ui/use-toast"

export type MediaItem = {
  id: string
  type: "video" | "image" | "audio"
  name: string
  duration?: string
  thumbnail: string
  src: string
}

export function useMediaLibrary() {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([
    {
      id: "1",
      type: "video",
      name: "Intro Sequence",
      duration: "0:15",
      thumbnail: "/placeholder.svg?height=80&width=120",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    },
    {
      id: "2",
      type: "video",
      name: "Interview Clip",
      duration: "2:45",
      thumbnail: "/placeholder.svg?height=80&width=120",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: "3",
      type: "image",
      name: "Logo",
      thumbnail: "/placeholder.svg?height=80&width=120",
      src: "/placeholder.svg?height=720&width=1280",
    },
    {
      id: "4",
      type: "video",
      name: "Outro",
      duration: "0:20",
      thumbnail: "/placeholder.svg?height=80&width=120",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    },
    {
      id: "5",
      type: "image",
      name: "Background",
      thumbnail: "/placeholder.svg?height=80&width=120",
      src: "/placeholder.svg?height=720&width=1280&text=Background",
    },
  ])

  const fileInputRef = useRef<HTMLInputElement>(null)

  const uploadMedia = useCallback(() => {
    fileInputRef.current?.click()
  }, [])

  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    // Process each file
    Array.from(files).forEach((file) => {
      const isVideo = file.type.startsWith("video/")
      const isImage = file.type.startsWith("image/")
      const isAudio = file.type.startsWith("audio/")

      if (!isVideo && !isImage && !isAudio) {
        toast({
          title: "Unsupported file type",
          description: "Please upload video, image, or audio files only.",
          variant: "destructive",
        })
        return
      }

      // Create object URL for the file
      const fileUrl = URL.createObjectURL(file)

      // Create a new media item
      const newItem: MediaItem = {
        id: `upload-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: isVideo ? "video" : isImage ? "image" : "audio",
        name: file.name,
        thumbnail: isImage ? fileUrl : "/placeholder.svg?height=80&width=120",
        src: fileUrl,
      }

      // For video files, get duration
      if (isVideo) {
        const video = document.createElement("video")
        video.preload = "metadata"
        video.onloadedmetadata = () => {
          const minutes = Math.floor(video.duration / 60)
          const seconds = Math.floor(video.duration % 60)
          newItem.duration = `${minutes}:${seconds.toString().padStart(2, "0")}`

          setMediaItems((prev) => [...prev, newItem])
        }
        video.src = fileUrl
      } else {
        // For images and audio, add immediately
        setMediaItems((prev) => [...prev, newItem])
      }
    })

    // Reset the input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }

    toast({
      title: "Media uploaded",
      description: "Your media has been added to the library.",
    })
  }, [])

  return {
    mediaItems,
    setMediaItems,
    uploadMedia,
    handleFileUpload,
    fileInputRef,
  }
}

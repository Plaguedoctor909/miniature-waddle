"use client"

import { useState, useCallback } from "react"
import { toast } from "@/components/ui/use-toast"

export type Clip = {
  id: string
  name: string
  start: number
  duration: number
  color: string
  type?: string
  content?: string
  source?: string
  effect?: string
  mediaId?: string
}

export type Track = {
  id: string
  name: string
  type: "video" | "audio" | "text"
  visible: boolean
  locked: boolean
  clips: Clip[]
}

type TimelineAction = {
  type: "add" | "move" | "resize" | "split" | "delete"
  trackId?: string
  clipId?: string
  data?: any
}

export function useTimeline(currentTime: number, seekTo: (time: number) => void) {
  const [tracks, setTracks] = useState<Track[]>([
    {
      id: "video-1",
      name: "Video Track 1",
      type: "video",
      visible: true,
      locked: false,
      clips: [
        {
          id: "clip-1",
          name: "Intro",
          start: 0,
          duration: 150,
          color: "bg-blue-500",
        },
        {
          id: "clip-2",
          name: "Main Content",
          start: 160,
          duration: 300,
          color: "bg-green-500",
        },
      ],
    },
    {
      id: "audio-1",
      name: "Audio Track 1",
      type: "audio",
      visible: true,
      locked: false,
      clips: [
        {
          id: "audio-clip-1",
          name: "Background Music",
          start: 0,
          duration: 450,
          color: "bg-purple-500",
        },
      ],
    },
    {
      id: "text-1",
      name: "Text Track",
      type: "text",
      visible: true,
      locked: false,
      clips: [
        {
          id: "text-clip-1",
          name: "Title",
          start: 50,
          duration: 100,
          color: "bg-yellow-500",
        },
        {
          id: "text-clip-2",
          name: "Credits",
          start: 400,
          duration: 100,
          color: "bg-yellow-500",
        },
      ],
    },
  ])

  const [selectedClipId, setSelectedClipId] = useState<string | null>(null)
  const [actionHistory, setActionHistory] = useState<TimelineAction[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)

  // Add a clip to a track
  const addClipToTrack = useCallback((trackId: string, clip: Clip) => {
    setTracks((prevTracks) => {
      const newTracks = [...prevTracks]
      const trackIndex = newTracks.findIndex((t) => t.id === trackId)

      if (trackIndex !== -1) {
        newTracks[trackIndex] = {
          ...newTracks[trackIndex],
          clips: [...newTracks[trackIndex].clips, clip],
        }
      }

      return newTracks
    })

    // Add to history
    addToHistory({
      type: "add",
      trackId,
      clipId: clip.id,
      data: { clip },
    })

    toast({
      title: "Clip Added",
      description: `${clip.name} has been added to the timeline.`,
    })
  }, [])

  // Move a clip
  const moveClip = useCallback((clipId: string, trackId: string, newStart: number) => {
    setTracks((prevTracks) => {
      const newTracks = [...prevTracks]

      // Find the clip in all tracks
      let sourceTrackIndex = -1
      let clipIndex = -1
      let clip: Clip | null = null

      for (let i = 0; i < prevTracks.length; i++) {
        clipIndex = prevTracks[i].clips.findIndex((c) => c.id === clipId)
        if (clipIndex !== -1) {
          sourceTrackIndex = i
          clip = prevTracks[i].clips[clipIndex]
          break
        }
      }

      if (sourceTrackIndex === -1 || !clip) return prevTracks

      // Remove from source track
      newTracks[sourceTrackIndex] = {
        ...newTracks[sourceTrackIndex],
        clips: newTracks[sourceTrackIndex].clips.filter((c) => c.id !== clipId),
      }

      // Add to target track
      const targetTrackIndex = newTracks.findIndex((t) => t.id === trackId)
      if (targetTrackIndex !== -1) {
        newTracks[targetTrackIndex] = {
          ...newTracks[targetTrackIndex],
          clips: [...newTracks[targetTrackIndex].clips, { ...clip, start: Math.max(0, newStart) }],
        }
      }

      return newTracks
    })

    // Add to history
    addToHistory({
      type: "move",
      clipId,
      trackId,
      data: { newStart },
    })
  }, [])

  // Resize a clip
  const resizeClip = useCallback((clipId: string, newDuration: number) => {
    setTracks((prevTracks) => {
      return prevTracks.map((track) => {
        const clipIndex = track.clips.findIndex((c) => c.id === clipId)
        if (clipIndex === -1) return track

        const newClips = [...track.clips]
        newClips[clipIndex] = {
          ...newClips[clipIndex],
          duration: Math.max(10, newDuration), // Minimum duration of 10
        }

        return {
          ...track,
          clips: newClips,
        }
      })
    })

    // Add to history
    addToHistory({
      type: "resize",
      clipId,
      data: { newDuration },
    })
  }, [])

  // Split a clip at the current time
  const splitClipAt = useCallback(
    (timePosition: number) => {
      // Find which clip is at the current position
      let clipToSplit: Clip | null = null
      let trackId = ""

      for (const track of tracks) {
        for (const clip of track.clips) {
          const clipEnd = clip.start + clip.duration
          if (timePosition > clip.start && timePosition < clipEnd) {
            clipToSplit = clip
            trackId = track.id
            break
          }
        }
        if (clipToSplit) break
      }

      if (!clipToSplit) {
        toast({
          title: "No clip to split",
          description: "There is no clip at the current position.",
          variant: "destructive",
        })
        return
      }

      // Calculate the split point
      const splitPoint = timePosition
      const firstPartDuration = splitPoint - clipToSplit.start
      const secondPartDuration = clipToSplit.duration - firstPartDuration

      setTracks((prevTracks) => {
        return prevTracks.map((track) => {
          if (track.id !== trackId) return track

          const clipIndex = track.clips.findIndex((c) => c.id === clipToSplit?.id)
          if (clipIndex === -1) return track

          const newClips = [...track.clips]

          // Modify the original clip to be the first part
          newClips[clipIndex] = {
            ...newClips[clipIndex],
            duration: firstPartDuration,
          }

          // Create a new clip for the second part
          const newClip: Clip = {
            ...clipToSplit!,
            id: `${clipToSplit!.id}-split-${Date.now()}`,
            start: splitPoint,
            duration: secondPartDuration,
          }

          return {
            ...track,
            clips: [...newClips, newClip],
          }
        })
      })

      // Add to history
      addToHistory({
        type: "split",
        clipId: clipToSplit.id,
        trackId,
        data: { splitPoint },
      })

      toast({
        title: "Clip Split",
        description: "The clip has been split at the current position.",
      })
    },
    [tracks],
  )

  // Delete the selected clip
  const deleteSelectedClip = useCallback(() => {
    if (!selectedClipId) {
      toast({
        title: "No clip selected",
        description: "Please select a clip to delete.",
        variant: "destructive",
      })
      return
    }

    let trackWithClip: Track | null = null

    for (const track of tracks) {
      if (track.clips.some((c) => c.id === selectedClipId)) {
        trackWithClip = track
        break
      }
    }

    if (!trackWithClip) return

    setTracks((prevTracks) => {
      return prevTracks.map((track) => {
        if (track.id !== trackWithClip?.id) return track

        return {
          ...track,
          clips: track.clips.filter((c) => c.id !== selectedClipId),
        }
      })
    })

    // Add to history
    addToHistory({
      type: "delete",
      clipId: selectedClipId,
      trackId: trackWithClip.id,
    })

    setSelectedClipId(null)

    toast({
      title: "Clip Deleted",
      description: "The selected clip has been removed from the timeline.",
    })
  }, [selectedClipId, tracks])

  // Select a clip
  const selectClip = useCallback((clipId: string | null) => {
    setSelectedClipId(clipId)
  }, [])

  // Handle timeline click
  const handleTimelineClick = useCallback(
    (timePosition: number) => {
      // Convert timeline position to video time
      const videoTime = timePosition / 10
      seekTo(videoTime)
    },
    [seekTo],
  )

  // Add action to history
  const addToHistory = useCallback(
    (action: TimelineAction) => {
      setActionHistory((prev) => {
        // If we're not at the end of the history, truncate
        const newHistory = prev.slice(0, historyIndex + 1)
        return [...newHistory, action]
      })
      setHistoryIndex((prev) => prev + 1)
    },
    [historyIndex],
  )

  // Undo the last action
  const undoAction = useCallback(() => {
    if (historyIndex < 0) return

    const action = actionHistory[historyIndex]

    // Implement undo logic based on action type
    switch (action.type) {
      case "add":
        // Remove the added clip
        setTracks((prevTracks) => {
          return prevTracks.map((track) => {
            if (track.id !== action.trackId) return track

            return {
              ...track,
              clips: track.clips.filter((c) => c.id !== action.clipId),
            }
          })
        })
        break

      case "delete":
        // Restore the deleted clip
        // This would require storing the full clip data in the action
        toast({
          title: "Undo Delete",
          description: "The deleted clip has been restored.",
        })
        break

      case "move":
      case "resize":
      case "split":
        // These would require more complex state tracking
        toast({
          title: "Undo Action",
          description: `The ${action.type} action has been undone.`,
        })
        break
    }

    setHistoryIndex((prev) => prev - 1)
  }, [historyIndex, actionHistory])

  // Redo the last undone action
  const redoAction = useCallback(() => {
    if (historyIndex >= actionHistory.length - 1) return

    const action = actionHistory[historyIndex + 1]

    // Implement redo logic based on action type
    switch (action.type) {
      case "add":
        // Re-add the clip
        if (action.data?.clip && action.trackId) {
          setTracks((prevTracks) => {
            return prevTracks.map((track) => {
              if (track.id !== action.trackId) return track

              return {
                ...track,
                clips: [...track.clips, action.data.clip],
              }
            })
          })
        }
        break

      // Other action types would have similar implementations
    }

    setHistoryIndex((prev) => prev + 1)
  }, [historyIndex, actionHistory])

  return {
    tracks,
    selectedClipId,
    addClipToTrack,
    moveClip,
    resizeClip,
    splitClipAt,
    deleteSelectedClip,
    selectClip,
    handleTimelineClick,
    undoAction,
    redoAction,
    canUndo: historyIndex >= 0,
    canRedo: historyIndex < actionHistory.length - 1,
  }
}
